# -*- coding: utf-8 -*-

import routing
import logging
import xbmcaddon
import requests
import xbmcgui
import xbmc
import os
import subprocess
import json
from xbmcgui import ListItem
from resources.lib import kodiutils
from xbmcplugin import addDirectoryItem, endOfDirectory


ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo('name')
logger = logging.getLogger(ADDON.getAddonInfo('id'))
plugin = routing.Plugin()
dialog = xbmcgui.Dialog()

# steam_id = "76561198284531302"
# api_key = "051EE610043797899019EC51207F6AC5"

steam_folder = ADDON.getSetting('steam_folder')
arts_folder = ADDON.getSetting('arts_folder')
steam_id = ADDON.getSetting('steam_id')
steam_api_key = ADDON.getSetting('steam_api_key')

STEAM_ARTS_TYPES = {  # img_icon_path is provided by steam API to get the icon. https://developer.valvesoftware.com/wiki/Steam_Web_API#GetOwnedGames_.28v0001.29
    'poster': 'http://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_600x900.jpg',  # Can return 404
    'hero': 'http://cdn.akamai.steamstatic.com/steam/apps/{appid}/library_hero.jpg',  # Can return 404
    'header': 'http://cdn.akamai.steamstatic.com/steam/apps/{appid}/header.jpg',
    'generated_bg': 'http://cdn.akamai.steamstatic.com/steam/apps/{appid}/page_bg_generated_v6b.jpg',  # Auto generated background with a shade of blue.
    'icon': 'https://steamcdn-a.akamaihd.net/steamcommunity/public/images/apps/{appid}/{img_icon_path}.jpg',
    'clearlogo': 'http://cdn.akamai.steamstatic.com/steam/apps/{appid}/logo.png'  # Can return 404
}

def get_steam_games(steam_id):
    # Replace YOUR_API_KEY with your Steam API Key
    api_url = f"http://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key={steam_api_key}&steamid={steam_id}&include_appinfo=1&include_played_free_games=1&format=json"

    response = requests.get(api_url)
    if response.status_code == 200:
        data = response.json()
        return data.get("response", {}).get("games", [])
    else:
        return []
    
def check_artwork_path(path):
    return os.path.exists(path) and path or 'Y:\\artwork\\defaultgame.png'

@plugin.route('/')
def index():
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "one"), ListItem("Steam Games"), True)
    addDirectoryItem(plugin.handle, plugin.url_for(
        show_category, "two"), ListItem("Non-Steam games"), True)
    endOfDirectory(plugin.handle)

@plugin.route('/category/<category_id>/<appid>')
def show_game_details(category_id, appid):
    if category_id == "one":
        games = get_steam_games(steam_id)
        for game in games:
            if str(game['appid']) == appid:
                dialog.ok(game['name'], "AppID: " + str(game['appid']))
                subprocess.call(steam_folder + 'steam.exe -applaunch {}'.format(game['appid']))
                
@plugin.route('/category/<category_id>')
def show_category(category_id):
    game_id = None
    if category_id == "one":
        games = get_steam_games(steam_id)
        for game in games:
            game_item = ListItem(game['name'])
            game_id = game['appid']

            poster_check = STEAM_ARTS_TYPES['poster'].format(appid=game_id)
            response = requests.get(poster_check)
            banner_check = STEAM_ARTS_TYPES['hero'].format(appid=game_id)
            
            if response.status_code == 404:
                poster_art = STEAM_ARTS_TYPES['header'].format(appid=game_id)
            else:
                poster_art = STEAM_ARTS_TYPES['poster'].format(appid=game_id)
            
            if response.status_code == 404:
                hero_art = STEAM_ARTS_TYPES['header'].format(appid=game_id)
            else:
                hero_art = STEAM_ARTS_TYPES['hero'].format(appid=game_id)
            
            
            header_art = STEAM_ARTS_TYPES['header'].format(appid=game_id)
            generated_bg_art = STEAM_ARTS_TYPES['generated_bg'].format(appid=game_id)
            clearlogo_art = STEAM_ARTS_TYPES['clearlogo'].format(appid=game_id)
            
            game_item.setArt({
                'poster': poster_art,
                'banner': hero_art,
                'header': header_art,
                'fanart': generated_bg_art,
                'thumb': header_art,
                'clearlogo': clearlogo_art
            })
            
            addDirectoryItem(
                plugin.handle, 
                plugin.url_for(show_game_details, category_id, str(game_id)), 
                game_item
            )
    elif category_id == "two":
        dialog.ok("Steam Games", "Working")
    endOfDirectory(plugin.handle)

def run():
    plugin.run()
