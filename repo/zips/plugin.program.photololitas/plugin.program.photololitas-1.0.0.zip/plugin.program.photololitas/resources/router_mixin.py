# -*- coding: utf-8 -*-
# Entrada do plugin e utilidades de navegação/roteamento

# --- Utilitários do addon ---
from .utils import *

import sys
import os
import json
import time
import datetime
import urllib.parse
import re
import shutil

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import xml.etree.ElementTree as ET
from xml.dom import minidom

CATEGORIES_DIRNAME = 'categories_db'
CATEGORIES_FILENAME = 'categories.json'

class RouterMixin:
    def _loc(self, string_id, fallback=''):
        return kodi_localize(string_id, fallback)

    # =========================
    # ===== ENTRY POINT =======
    # =========================
    def run_plugin(self, args):
        addon = xbmcaddon.Addon()
        handle = int(args[1])

        # Perfil do addon e pastas necessárias
        addon_data_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        self.create_required_folders(addon_data_path)  # cria albuns_db, lolitas_db, categories_db e remove tags_db

        params = self.get_params(args)
        xbmc.log(f"DEBUG: Params = {params}")

        # ---------- AÇÕES ----------
        action = params.get('action')

        if action == 'scan_albums':
            scan_path = addon.getSetting('scan_path')
            self.scan_albums(scan_path)
            return

        elif action == 'update_album':
            scan_path = addon.getSetting('scan_path')
            set_name = urllib.parse.unquote(params.get('set', ''))
            if set_name:
                self.update_album(scan_path, set_name)
            else:
                kodi_notify_error(self._loc(30022, 'Album set not provided.'))
            return

        elif action == 'scan_lolitas':
            self.scan_lolitas()
            return

        elif action == 'edit_album':
            set_name = urllib.parse.unquote(params['set'])
            self.edit_album(set_name)
            return

        elif action == 'edit_issue':
            set_name = urllib.parse.unquote(params['set'])
            album_name = urllib.parse.unquote(params['album'])
            self.edit_issue(set_name, album_name)
            return

        elif action == 'all_from_model':
            set_name = urllib.parse.unquote(params.get('set', ''))
            album_name = urllib.parse.unquote(params.get('album', ''))
            xbmc.log(f"[photololitas] action=all_from_model set={set_name} album={album_name}", xbmc.LOGINFO)
            self.display_issues_from_same_models(handle, set_name, album_name)
            return

        elif action == 'edit_model':
            set_name = urllib.parse.unquote(params['set'])
            album_name = urllib.parse.unquote(params['album'])
            self.edit_model(set_name, album_name)
            return

        elif action == 'settings':
            xbmc.executebuiltin('Addon.OpenSettings({})'.format('plugin.program.photololitas'))

        elif action == 'save_all_issues_nfo':
            xbmc.log('[photololitas] Action received: save_all_issues_nfo', xbmc.LOGINFO)
            self.save_all_issues_nfo()

        elif action == 'save_all_albums_nfo':
            xbmc.log('[photololitas] Action received: save_all_albums_nfo', xbmc.LOGINFO)
            self.save_all_albums_nfo()

        # ---------- CATEGORIAS ----------
        elif action == 'create_category':
            self.create_category_dialog()

        elif action == 'manage_categories':
            self.manage_categories_dialog()

        elif action == 'rename_category':
            cat = urllib.parse.unquote(params.get('category', ''))
            if cat:
                self.rename_category_dialog(cat)

        elif action == 'delete_category':
            cat = urllib.parse.unquote(params.get('category', ''))
            if cat:
                self.delete_category_dialog(cat)

        elif action == 'assign_album_to_category':
            album = urllib.parse.unquote(params.get('album', ''))
            self.assign_album_to_category_dialog(album)

        elif action == 'unassign_album_from_category':
            album = urllib.parse.unquote(params.get('album', ''))
            category = urllib.parse.unquote(params.get('category', ''))
            self.unassign_album_from_category(category, album)

        elif action == 'open_pictures':
            set_name = urllib.parse.unquote(params.get('set', ''))
            m_path = urllib.parse.unquote(params.get('path', ''))

            if set_name:
                kodi_notify("{}".format(set_name))

            xbmc.executebuiltin('ActivateWindow(pictures,"{}",return)'.format(m_path))
            return
            
        if action == 'edit_category':
            self.edit_category_dialog(urllib.parse.unquote(params.get('category','')))
            return

        elif action == 'all_sets':
            self.display_all_sets(handle)
        
        elif action in ('all_albums', 'all_albuns'):
            self.display_all_albums(handle)

        # ---------- NAVEGAÇÃO ----------
        elif params.get('folder') == 'Albuns':
            if 'category' in params:
                self.display_category_albums(handle, urllib.parse.unquote(params['category']))
            elif 'set' in params:
                self.display_album_items(handle, urllib.parse.unquote(params['set']))
            else:
                self.display_album_sets(handle)

        elif params.get('folder') == 'Lolitas':
            if 'set' in params:
                self.display_model_items(handle, urllib.parse.unquote(params['set']))
            else:
                self.display_model_sets(handle)

        else:
            # Raiz do addon: Albuns e Lolitas (Tags removido)
            self.add_directory('Albuns', self._loc(30023, 'Albums'), handle)
            self.add_directory('Lolitas', self._loc(30024, 'Lolitas'), handle)
            xbmcplugin.endOfDirectory(handle)

    # =========================
    # ===== infra básica ======
    # =========================
    def get_params(self, args):
        param_string = args[2][1:]
        params = {}
        if param_string:
            for param in param_string.split('&'):
                key_value = param.split('=')
                if len(key_value) == 2:
                    params[key_value[0]] = key_value[1]
        return params

    def create_required_folders(self, addon_data_path):
        # Pastas existentes do projeto
        folders = ['albuns_db', 'lolitas_db', CATEGORIES_DIRNAME]
        for folder in folders:
            folder_path = os.path.join(addon_data_path, folder)
            if not xbmcvfs.exists(folder_path):
                xbmcvfs.mkdirs(folder_path)

        # Remover completamente a antiga base de tags (se existir)
        old_tags_path = os.path.join(addon_data_path, 'tags_db')
        if xbmcvfs.exists(old_tags_path):
            try:
                shutil.rmtree(old_tags_path)
                xbmc.log('Removed legacy tags_db directory.')
            except Exception as e:
                xbmc.log(f'Failed to remove tags_db: {e}')

        # Garantir o arquivo de categorias
        cat_json = os.path.join(addon_data_path, CATEGORIES_DIRNAME, CATEGORIES_FILENAME)
        if not xbmcvfs.exists(cat_json):
            with xbmcvfs.File(cat_json, 'w') as f:
                f.write(json.dumps({}, ensure_ascii=False, indent=4))

    def add_directory(self, folder_key, label, handle):
        url = f"plugin://plugin.program.photololitas/?folder={urllib.parse.quote(folder_key)}"
        li = xbmcgui.ListItem(label=label)

        if folder_key == 'Albuns':
            li.setArt({
                'icon': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_icon.png',
                'poster': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_poster.png',
                'clearlogo': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_clearlogo.png',
                'fanart': 'special://home/addons/plugin.program.photololitas/media/theme/_fanart.jpg',
            })
            context_menu = [
                (self._loc(30025, 'Scan Albums'), 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
                (self._loc(30026, 'Scan Lolitas'), 'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                (self._loc(30027, 'Settings'), 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
            ]
            li.addContextMenuItems(context_menu)

        elif folder_key == 'Lolitas':
            li.setArt({
                'icon': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_icon.png',
                'poster': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_poster.png',
                'clearlogo': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_clearlogo.png',
                'fanart': 'special://home/addons/plugin.program.photololitas/media/theme/_fanart.jpg',
            })
            context_menu = [
                (self._loc(30026, 'Scan Lolitas'), 'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                (self._loc(30027, 'Settings'), 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
            ]
            li.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(handle, url, li, True)
