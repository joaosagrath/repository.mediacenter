# -*- coding: utf-8 -*-
"""
scanner_mixin.py
Responsável por varreduras (scan) de álbuns/sets e indexação por modelos (lolitas).
Extrai metadados de .nfo e monta bancos JSON em albuns_db/ e lolitas_db/.
"""

from __future__ import annotations

# --- Kodi modules ---
try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:
    # Em ambientes fora do Kodi, os imports acima podem falhar.
    # O mixin continua importável para testes estáticos.
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None  # type: ignore

# --- Python stdlib ---
import os
import json
import datetime
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional

# --- Utilitários do addon ---
from .utils import *

class ScannerMixin:
    def _loc(self, string_id, fallback=''):
        return kodi_localize(string_id, fallback)

    def scan_albums(self, scan_path):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        
        # Criar diretório 'albuns_db' se não existir
        if not xbmcvfs.exists(albums_db_path):
            xbmcvfs.mkdirs(albums_db_path)

        albums_dict = {}

        # Inicializa a barra de progresso para o scan de novos álbuns
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create(self._loc(30064, 'Starting Search'), self._loc(30065, 'Collecting data from:\n{}').format(scan_path))

        total_dirs = sum([len(dirs) for _, dirs, _ in os.walk(scan_path)])
        added_count = 0
        except_scan = False
        valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']

        for root, dirs, files in os.walk(scan_path):
            for dir_name in dirs:
                progress_dialog.create(self._loc(30066, 'Scanning Albums'), self._loc(30067, 'Scanning for .issue files:\n{}').format(dir_name))
                issue_file = os.path.join(root, dir_name, f'{dir_name}.issue')
                nfo_set_file = os.path.join(root, dir_name, f'{dir_name}.nfo')

                if os.path.exists(issue_file) and dir_name:
                    album_data = {
                        "m_number": "",
                        "m_title": dir_name,
                        "m_model": "",
                        "m_others": "",
                        "m_album": "",
                        "m_tags": "",
                        "m_date": "",
                        "m_year": "",
                        "m_plot": "",
                        "m_path": os.path.join(root, dir_name),
                        "s_icon": "",
                        "s_poster": "",
                        "s_fanart": "",
                        "s_banner": ""
                    }

                    # Agora, procuramos as artes na pasta de cada set (dir_name)
                    set_path = os.path.join(root, dir_name)
                    
                    for file_name in os.listdir(set_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:
                            art_path = os.path.join(set_path, file_name)
                            if file_name == 'banner.jpg':
                                album_data['s_banner'] = art_path

                            if file_name == 'fanart.jpg':
                                album_data['s_fanart'] = art_path
 
                            if file_name == 'folder.jpg':
                                album_data['s_poster'] = art_path
  
                            if file_name == 'icon.jpg':
                                album_data['s_icon'] = art_path
 
                            if file_name == 'clearlogo.png':
                                album_data['s_clearlogo'] = art_path

                    if os.path.exists(nfo_set_file):
                    
                        # xbmc.log(f'nfo_set_file: {str(nfo_set_file)}', xbmc.LOGERROR)  
                        try:
                            tree = ET.parse(nfo_set_file)
                            root_element = tree.getroot()
                            album_data["m_number"] = root_element.find('m_number').text or ""
                            album_data["m_title"] = root_element.find('m_title').text or dir_name
                            album_data["m_album"] = root_element.find('m_album').text or ""
                            album_data["m_model"] = root_element.find('m_model').text or ""
                            album_data["m_others"] = root_element.find('m_others').text or ""
                            album_data["m_date"] = root_element.find('m_date').text or ""
                            album_data["m_year"] = root_element.find('m_year').text or ""
                            album_data["m_tags"] = root_element.find('m_tags').text or ""
                            album_data["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break

                    album_key = album_data["m_album"] if album_data["m_album"] else "[Not Set]"
                    nfo_album_file = os.path.join(root, f'{album_key}.nfo')
                    
                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Verifique se o álbum já existe no dicionário, se não, crie a entrada
                    if album_key not in albums_dict:
                        albums_dict[album_key] = {
                            "m_album": album_key,
                            "m_tags": "",
                            "m_year": "",
                            "m_plot": "",
                            "m_path": album_path,
                            "s_icon": "",
                            "s_poster": "",
                            "s_clearlogo": "",
                            "s_fanart": "",
                            "s_banner": ""
                        }

                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Atribuir as artes do cabeçalho diretamente ao álbum principal (não aos sets)
                    for file_name in os.listdir(album_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:  # Verificar se o arquivo é uma arte válida
                            art_path = os.path.join(album_path, file_name)
                            
                            if album_key != "[Not Set]":
                                if 's_banner' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_banner'] = ""
                                if 's_fanart' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_fanart'] = ""
                                if 's_poster' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_poster'] = ""
                                if 's_icon' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_icon'] = ""
                                if 's_clearlogo' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_clearlogo'] = ""

                                # Atribui as artes ao álbum principal se não for "[Not Set]"
                                if file_name == 'banner.jpg':
                                    albums_dict[album_key]['s_banner'] = art_path
                                if file_name == 'fanart.jpg':
                                    albums_dict[album_key]['s_fanart'] = art_path
                                if file_name == 'folder.jpg':
                                    albums_dict[album_key]['s_poster'] = art_path
                                if file_name == 'icon.jpg':
                                    albums_dict[album_key]['s_icon'] = art_path
                                if file_name == 'clearlogo.png':
                                    albums_dict[album_key]['s_clearlogo'] = art_path
                    
                    if os.path.exists(nfo_album_file):
                        try:
                            tree = ET.parse(nfo_album_file)
                            root_element = tree.getroot()
                            albums_dict[album_key]["m_album"] = root_element.find('m_album').text or ""
                            albums_dict[album_key]["m_tags"] = root_element.find('m_tags').text or ""
                            albums_dict[album_key]["m_year"] = root_element.find('m_year').text or ""
                            albums_dict[album_key]["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break
                    
                    # Adicionar ao dicionário principal
                    # albums_dict[album_key][f"{album_data['m_title']}"] = album_data
                    albums_dict[album_key][f"{dir_name}"] = album_data
                    added_count += 1

                    progress = int((added_count / total_dirs) * 100)
                    progress_dialog.update(progress)

                    if progress_dialog.iscanceled():
                        break

        progress_dialog.close()

        # Excluir todos os arquivos JSON no caminho albums_db_path
        for filename in os.listdir(albums_db_path):
            file_path = os.path.join(albums_db_path, filename)
            if filename.endswith('.json'):
                try:
                    os.remove(file_path)
                except Exception as e:
                    xbmc.log(f'Erro ao tentar excluir o arquivo {file_path}: {str(e)}', xbmc.LOGERROR)

        # Salvar cada conjunto de álbuns em arquivos JSON separados
        for album_key, album_content in albums_dict.items():
            album_json_path = os.path.join(albums_db_path, f'{album_key}.json')
            try:
                with open(album_json_path, 'w', encoding='utf-8') as json_file:
                    json.dump(album_content, json_file, ensure_ascii=False, indent=4)
            except Exception as e:
                kodi_notify_error(f'Error saving {album_key}.json: {str(e)}')
                return

        kodi_refresh_container()

        if added_count > 0:
            kodi_notify(f'{added_count} issue(s) localized')
            self.scan_lolitas()

        if except_scan == False:
            kodi_notify('Scan completed')
        else: 
            kodi_notify_warn('Scan completed with errors')

        # Obter o timestamp Unix atual
        timestamp_unix = int(datetime.datetime.now().timestamp())

        # Criar o dicionário com o timestamp Unix
        timestamp_data = {
            "last_scan": timestamp_unix
        }

        timestamp_json_path = os.path.join(albums_db_path, '_scan_timestamp.json')
        
        try:
            with open(timestamp_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(timestamp_data, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            kodi_notify_error(f'Error saving timestamp JSON: {str(e)}')
            
        kodi_refresh_container()
    
    def update_album(self, scan_path, set_name):
        """
        Atualiza um único álbum já existente em albuns_db/<set_name>.json.
        Faz releitura dos NFOs e artworks do cabeçalho e de todos os issues do álbum.
        """
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        albums_json_path = os.path.join(albums_db_path, f'{set_name}.json')

        if not xbmcvfs.exists(albums_json_path):
            kodi_notify_error(f'Album "{set_name}" not found in database.')
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        album_path = (albums_dict.get('m_path') or '').strip()
        if not album_path or not os.path.isdir(album_path):
            kodi_notify_error(f'Album path not found or invalid: {album_path}')
            return

        valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']
        not_keys = {
            "m_album", "m_tags", "m_year", "m_plot", "m_path",
            "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"
        }

        # Recarrega artwork do cabeçalho do álbum
        for file_name in valid_art_files:
            art_path = os.path.join(album_path, file_name)
            if os.path.exists(art_path):
                if file_name == 'banner.jpg':
                    albums_dict['s_banner'] = art_path
                elif file_name == 'fanart.jpg':
                    albums_dict['s_fanart'] = art_path
                elif file_name == 'folder.jpg':
                    albums_dict['s_poster'] = art_path
                elif file_name == 'icon.jpg':
                    albums_dict['s_icon'] = art_path
                elif file_name == 'clearlogo.png':
                    albums_dict['s_clearlogo'] = art_path

        # Recarrega metadata de álbum via NFO do cabeçalho
        album_nfo = os.path.join(album_path, f'{set_name}.nfo')
        if os.path.exists(album_nfo):
            try:
                tree = ET.parse(album_nfo)
                root_element = tree.getroot()
                albums_dict["m_album"] = (root_element.findtext('m_album') or albums_dict.get("m_album") or set_name)
                albums_dict["m_tags"] = root_element.findtext('m_tags') or ""
                albums_dict["m_year"] = root_element.findtext('m_year') or ""
                albums_dict["m_plot"] = root_element.findtext('m_plot') or ""
                albums_dict["m_path"] = album_path
            except ET.ParseError as e:
                kodi_notify_warn(f'Album NFO parse error: {str(e)}')

        # Recarrega metadata e artwork de cada issue do álbum
        issue_keys = [k for k in albums_dict.keys() if k not in not_keys and isinstance(albums_dict.get(k), dict)]
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create('Updating Album', f'Reading issues from:\n{set_name}')

        for idx, issue_key in enumerate(issue_keys, start=1):
            issue_info = albums_dict.get(issue_key, {})
            issue_path = (issue_info.get('m_path') or '').strip()
            if not issue_path:
                continue

            # Atualiza artworks do issue
            for file_name in valid_art_files:
                art_path = os.path.join(issue_path, file_name)
                if os.path.exists(art_path):
                    if file_name == 'banner.jpg':
                        issue_info['s_banner'] = art_path
                    elif file_name == 'fanart.jpg':
                        issue_info['s_fanart'] = art_path
                    elif file_name == 'folder.jpg':
                        issue_info['s_poster'] = art_path
                    elif file_name == 'icon.jpg':
                        issue_info['s_icon'] = art_path
                    elif file_name == 'clearlogo.png':
                        issue_info['s_clearlogo'] = art_path

            # Atualiza metadata do issue via NFO
            issue_dir_name = os.path.basename(os.path.normpath(issue_path))
            issue_nfo = os.path.join(issue_path, f'{issue_dir_name}.nfo')
            if os.path.exists(issue_nfo):
                try:
                    tree = ET.parse(issue_nfo)
                    root_element = tree.getroot()
                    issue_info["m_number"] = root_element.findtext('m_number') or issue_info.get("m_number") or ""
                    issue_info["m_title"] = root_element.findtext('m_title') or issue_info.get("m_title") or issue_dir_name
                    issue_info["m_album"] = root_element.findtext('m_album') or issue_info.get("m_album") or set_name
                    issue_info["m_model"] = root_element.findtext('m_model') or issue_info.get("m_model") or ""
                    issue_info["m_others"] = root_element.findtext('m_others') or issue_info.get("m_others") or ""
                    issue_info["m_date"] = root_element.findtext('m_date') or issue_info.get("m_date") or ""
                    issue_info["m_year"] = root_element.findtext('m_year') or issue_info.get("m_year") or ""
                    issue_info["m_tags"] = root_element.findtext('m_tags') or issue_info.get("m_tags") or ""
                    issue_info["m_plot"] = root_element.findtext('m_plot') or issue_info.get("m_plot") or ""
                except ET.ParseError as e:
                    kodi_notify_warn(f'Issue NFO parse error ({issue_key}): {str(e)}')

            albums_dict[issue_key] = issue_info
            progress = int((idx / max(len(issue_keys), 1)) * 100)
            progress_message = f'Updating issue {idx}/{len(issue_keys)}: {issue_key}'
            try:
                # Kodi Python API pode variar entre builds:
                # alguns aceitam apenas (percent, message).
                progress_dialog.update(progress, progress_message)
            except TypeError:
                # Fallback conservador para implementações mais restritas.
                progress_dialog.update(progress)
            if progress_dialog.iscanceled():
                break

        progress_dialog.close()

        try:
            with open(albums_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(albums_dict, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            kodi_notify_error(f'Error saving {set_name}.json: {str(e)}')
            return

        save_timestamp(albums_db_path)
        kodi_refresh_container()
        kodi_notify(f'Album "{set_name}" updated.')
    
    def get_album_data(self, album_key, scan_path, album_dict):
        for root, dirs, files in os.walk(scan_path):
            for file in files:
                if file == f"{album_key}.nfo":
                    nfo_file = os.path.join(root, file)

                    tree = ET.parse(nfo_file)
                    root_element = tree.getroot()
                    
                    album_dict["m_album"] = root_element.find('m_album').text or ""
                    album_dict["m_tags"] = root_element.find('m_tags').text or ""
                    album_dict["m_year"] = root_element.find('m_year').text or ""
                    album_dict["m_plot"] = root_element.find('m_plot').text or ""
                    album_dict["m_path"] = root or ""
                    album_dict["s_icon"] = root_element.find('s_icon').text or ""
                    album_dict["s_poster"] = root_element.find('s_poster').text or ""
                    album_dict["s_clearlogo"] = root_element.find('s_clearlogo').text or ""
                    album_dict["s_fanart"] = root_element.find('s_fanart').text or ""
                    album_dict["s_banner"] = root_element.find('s_banner').text or ""
                    
                    return album_dict
        
        return album_dict
        
    def scan_lolitas(self):
        addon = xbmcaddon.Addon()
        lolitas_arts = addon.getSetting('lolitas_arts_dir')
        fanarts_arts = addon.getSetting('fanarts_arts_dir')
    
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')
        
        # Dicionário para armazenar os dados organizados por modelo
        lolitas_data = {}
        unique_lolitas = set()
        
        # Inicializa a barra de progresso para o scan de novas modelos
        progress_dialog = xbmcgui.DialogProgress()
        
        # Percorrer todos os arquivos JSON no diretório
        json_files = [filename for filename in os.listdir(albums_db_path) if filename.endswith('.json')]

        # Primeira passagem para contar os modelos únicos
        for json_file in json_files:
            json_path = os.path.join(albums_db_path, json_file)
            
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Verificar se o JSON contém itens de álbum
            album_items = {key: value for key, value in data.items() if isinstance(value, dict)}
            
            # Adicionar cada modelo ao conjunto unique_lolitas
            for item_key, item_info in album_items.items():
                m_model = item_info.get("m_model", "").strip()
                m_others = item_info.get("m_others", "").strip()
                if m_model == "":
                    m_model = "[Not Set]"
                unique_lolitas.add(m_model)

                if m_others:
                    others_list = [model.strip() for model in m_others.split(",")]
                    for other_model in others_list:
                        unique_lolitas.add(other_model)

        # Número total de modelos
        total_lolitas = len(unique_lolitas)
        model_count = 0
        
        # Segunda passagem para atualizar lolitas_data e mostrar progresso
        for json_file in json_files:
            json_path = os.path.join(albums_db_path, json_file)
            
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Verificar se o JSON contém itens de álbum
            album_items = {key: value for key, value in data.items() if isinstance(value, dict)}
            
            # Adicionar cada item ao dicionário lolitas_data
            for item_key, item_info in album_items.items():
                m_model = item_info.get("m_model", "").strip()
                m_others = item_info.get("m_others", "").strip()
                if m_model == "":
                    m_model = "[Not Set]"
                
                if m_others == "":
                    if m_model not in lolitas_data:
                        lolitas_data[m_model] = {}
                    lolitas_data[m_model][item_key] = item_info
                
                else:
                    others_list = [model.strip() for model in m_others.split(",")]
                    for other_model in others_list:
                        if other_model not in lolitas_data:
                            lolitas_data[other_model] = {}
                        lolitas_data[other_model][item_key] = item_info
                
                model_count = len(lolitas_data)
                
                # Mostrar progresso
                progress_dialog.create('Scanning Albums', 'Updating Lolitas DB:\n{}/{}: {}'.format(model_count, total_lolitas, m_model))
                progress = int((model_count / total_lolitas) * 100)
                progress_dialog.update(progress)
                
                # time.sleep(0.05)
            
                if progress_dialog.iscanceled():
                    break
        
        progress_dialog.close()
        
        # Excluir todos os arquivos JSON no caminho lolitas_db_path
        for filename in os.listdir(lolitas_db_path):
            file_path = os.path.join(lolitas_db_path, filename)
            if filename.endswith('.json'):
                try:
                    os.remove(file_path)
                except Exception as e:
                    xbmc.log(f'Erro ao tentar excluir o arquivo {file_path}: {str(e)}', xbmc.LOGERROR)
        
        # Criar arquivos JSON para cada modelo
        for model, items in lolitas_data.items():
            model_json_path = os.path.join(lolitas_db_path, f"{model}.json")
            model_poster_dir = os.path.join(lolitas_arts, f"{model}.jpg")
            fanarts_dir = os.path.join(fanarts_arts, f"{model}.jpg")
            
            if os.path.exists(model_poster_dir):
                s_poster = model_poster_dir
            else:
                s_poster = ""
                
            if os.path.exists(fanarts_dir):
                s_fanart = fanarts_dir
            else:
                s_fanart = ""
            
            # Adicionar metadados do modelo se necessário
            model_data = {
                "m_model": model,
                "m_type": "",
                "s_icon": "",
                "s_poster": s_poster,
                "s_fanart": s_fanart,
                "s_banner": "",
            }
            model_data.update(items)

            with open(model_json_path, 'w', encoding='utf-8') as f:
                json.dump(model_data, f, ensure_ascii=False, indent=4)
                
        # Obter o timestamp Unix atual
        timestamp_unix = int(datetime.datetime.now().timestamp())

        # Criar o dicionário com o timestamp Unix
        timestamp_data = {
            "last_scan": timestamp_unix
        }

        timestamp_json_path = os.path.join(lolitas_db_path, '_scan_timestamp.json')

        try:
            with open(timestamp_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(timestamp_data, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            kodi_notify_error(f'Error saving timestamp JSON: {str(e)}')
        
    
