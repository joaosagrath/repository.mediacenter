# --- Modules/packages in this plugin ---
from .utils import *

# main.py (refactor with Categories)
from xml.dom import minidom
import datetime
import json
import os
import shutil
import sys
import time
import urllib.parse
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import xml.etree.ElementTree as ET

CATEGORIES_DIRNAME = 'categories_db'
CATEGORIES_FILENAME = 'categories.json'

class Main:

    # =========================
    # ===== ENTRY POINT =======
    # =========================
    def run_plugin(self, args):
        addon = xbmcaddon.Addon()
        handle = int(args[1])

        # Perfil do addon e pastas necessárias
        addon_data_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        self.create_required_folders(addon_data_path)  # cria albuns_db, lolitas_db, categories_db e remove tags_db

        params = self.get_params(args)
        xbmc.log(f"DEBUG: Params = {params}")

        # ---------- AÇÕES ----------
        action = params.get('action')

        if action == 'scan_albums':
            scan_path = addon.getSetting('scan_path')
            self.scan_albums(scan_path)

        elif action == 'update_album':
            scan_path = addon.getSetting('scan_path')
            album_name = params.get('album_name')
            if album_name:
                self.update_album(scan_path, album_name)
            else:
                kodi_notify_error('Album path not provided.')

        elif action == 'scan_lolitas':
            self.scan_lolitas()

        elif action == 'edit_album':
            set_name = urllib.parse.unquote(params['set'])
            self.edit_album(set_name)

        elif action == 'edit_issue':
            set_name = urllib.parse.unquote(params['set'])
            album_name = urllib.parse.unquote(params['album'])
            self.edit_issue(set_name, album_name)

        elif action == 'edit_model':
            set_name = urllib.parse.unquote(params['set'])
            album_name = urllib.parse.unquote(params['album'])
            self.edit_model(set_name, album_name)

        elif action == 'settings':
            xbmc.executebuiltin('Addon.OpenSettings({})'.format('plugin.program.photololitas'))

        # ---------- CATEGORIAS ----------
        elif action == 'create_category':
            self.create_category_dialog()

        elif action == 'manage_categories':
            self.manage_categories_dialog()

        elif action == 'rename_category':
            cat = urllib.parse.unquote(params.get('category', ''))
            if cat:
                self.rename_category_dialog(cat)

        elif action == 'delete_category':
            cat = urllib.parse.unquote(params.get('category', ''))
            if cat:
                self.delete_category_dialog(cat)

        elif action == 'assign_album_to_category':
            album = urllib.parse.unquote(params.get('album', ''))
            self.assign_album_to_category_dialog(album)

        elif action == 'unassign_album_from_category':
            album = urllib.parse.unquote(params.get('album', ''))
            category = urllib.parse.unquote(params.get('category', ''))
            self.unassign_album_from_category(category, album)

        elif action == 'open_pictures':
            m_path = urllib.parse.unquote(params['path'])
            kodi_notify("{}".format(m_path))
            xbmc.executebuiltin('ActivateWindow(pictures,"{}",return)'.format(m_path))
            
        if action == 'edit_category':
            self.edit_category_dialog(urllib.parse.unquote(params.get('category','')))
            return

        elif action == 'all_sets':
            self.display_all_sets(handle)

        # ---------- NAVEGAÇÃO ----------
        elif params.get('folder') == 'Albuns':
            if 'category' in params:
                self.display_category_albums(handle, urllib.parse.unquote(params['category']))
            elif 'set' in params:
                self.display_album_items(handle, urllib.parse.unquote(params['set']))
            else:
                self.display_album_sets(handle)

        elif params.get('folder') == 'Lolitas':
            if 'set' in params:
                self.display_model_items(handle, urllib.parse.unquote(params['set']))
            else:
                self.display_model_sets(handle)

        else:
            # Raiz do addon: Albuns e Lolitas (Tags removido)
            self.add_directory('Albuns', handle)
            self.add_directory('Lolitas', handle)
            xbmcplugin.endOfDirectory(handle)

    # =========================
    # ===== infra básica ======
    # =========================
    def get_params(self, args):
        param_string = args[2][1:]
        params = {}
        if param_string:
            for param in param_string.split('&'):
                key_value = param.split('=')
                if len(key_value) == 2:
                    params[key_value[0]] = key_value[1]
        return params

    def create_required_folders(self, addon_data_path):
        # Pastas existentes do projeto
        folders = ['albuns_db', 'lolitas_db', CATEGORIES_DIRNAME]
        for folder in folders:
            folder_path = os.path.join(addon_data_path, folder)
            if not xbmcvfs.exists(folder_path):
                xbmcvfs.mkdirs(folder_path)

        # Remover completamente a antiga base de tags (se existir)
        old_tags_path = os.path.join(addon_data_path, 'tags_db')
        if xbmcvfs.exists(old_tags_path):
            try:
                shutil.rmtree(old_tags_path)
                xbmc.log('Removed legacy tags_db directory.')
            except Exception as e:
                xbmc.log(f'Failed to remove tags_db: {e}')

        # Garantir o arquivo de categorias
        cat_json = os.path.join(addon_data_path, CATEGORIES_DIRNAME, CATEGORIES_FILENAME)
        if not xbmcvfs.exists(cat_json):
            with xbmcvfs.File(cat_json, 'w') as f:
                f.write(json.dumps({}, ensure_ascii=False, indent=4))

    def add_directory(self, name, handle):
        url = f"plugin://plugin.program.photololitas/?folder={urllib.parse.quote(name)}"
        li = xbmcgui.ListItem(label=name)

        if name == 'Albuns':
            li.setArt({
                'icon': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_icon.png',
                'poster': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_poster.png',
                'clearlogo': 'special://home/addons/plugin.program.photololitas/media/theme/Albuns_clearlogo.png',
                'fanart': 'special://home/addons/plugin.program.photololitas/media/theme/_fanart.jpg',
            })
            context_menu = [
                ('Scan Albuns', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
                ('Scan Lolitas', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                ('Settings', 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
            ]
            li.addContextMenuItems(context_menu)

        elif name == 'Lolitas':
            li.setArt({
                'icon': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_icon.png',
                'poster': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_poster.png',
                'clearlogo': 'special://home/addons/plugin.program.photololitas/media/theme/Lolitas_clearlogo.png',
                'fanart': 'special://home/addons/plugin.program.photololitas/media/theme/_fanart.jpg',
            })
            context_menu = [
                ('Scan Lolitas', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                ('Settings', 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
            ]
            li.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(handle, url, li, True)

    # =========================
    # ===== CATEGORIAS (META/ART) =====
    # =========================

    THEME_PATH = 'special://home/addons/plugin.program.photololitas/media/theme/'
    FALLBACK_ICON      = f'{THEME_PATH}Albuns_icon.png'
    FALLBACK_POSTER    = f'{THEME_PATH}Albuns_poster.png'
    FALLBACK_CLEARLOGO = f'{THEME_PATH}Albuns_clearlogo.png'
    FALLBACK_FANART    = f'{THEME_PATH}fanart.jpg'
    FALLBACK_BANNER    = ''  # opcional

    def _categories_root(self):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        return os.path.join(addon_data_path, CATEGORIES_DIRNAME)

    def _categories_path(self):
        return os.path.join(self._categories_root(), CATEGORIES_FILENAME)

    def _category_info_path(self, category_name: str):
        # um arquivo por categoria com seus metadados/arte
        safe = category_name.replace('/', '_')
        return os.path.join(self._categories_root(), f'{safe}.json')

    def _default_category_payload(self, category_name: str):
        return {
            "m_category": category_name,
            "m_plot": "",
            "s_icon": "",
            "s_poster": "",
            "s_clearlogo": "",
            "s_fanart": "",
            "s_banner": ""
        }

    def load_categories(self):
        path = self._categories_path()
        try:
            with xbmcvfs.File(path) as f:
                raw = f.read()
                return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def save_categories(self, data):
        path = self._categories_path()
        with xbmcvfs.File(path, 'w') as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=4))

    def _ensure_category_info_exists(self, name):
        info_path = self._category_info_path(name)
        if not xbmcvfs.exists(info_path):
            with xbmcvfs.File(info_path, 'w') as f:
                f.write(json.dumps(self._default_category_payload(name), ensure_ascii=False, indent=4))

    def _load_category_info(self, name):
        self._ensure_category_info_exists(name)
        with xbmcvfs.File(self._category_info_path(name)) as f:
            raw = f.read()
            return json.loads(raw) if raw else self._default_category_payload(name)

    def _save_category_info(self, name, payload: dict):
        with xbmcvfs.File(self._category_info_path(name), 'w') as f:
            f.write(json.dumps(payload, ensure_ascii=False, indent=4))

    def _browse_art(self, title, start_dir):
        # file = 1, máscara deixo livre pra não limitar
        return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, start_dir)
            
    # ---------- CREATE / RENAME / DELETE (com JSON de categoria) ----------
    def create_category_dialog(self):
        name = xbmcgui.Dialog().input("Nome da nova categoria", type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            return
        cats = self.load_categories()
        if name in cats:
            kodi_notify_warn("Já existe uma categoria com esse nome.")
            return
        cats[name] = []
        self.save_categories(cats)
        # cria JSON da categoria com payload default
        self._ensure_category_info_exists(name)
        kodi_notify("Categoria criada.")
        kodi_refresh_container()

    def rename_category_dialog(self, old_name):
        new_name = xbmcgui.Dialog().input("Novo nome da categoria", defaultt=old_name, type=xbmcgui.INPUT_ALPHANUM)
        if not new_name or new_name == old_name:
            return
        cats = self.load_categories()
        if new_name in cats:
            kodi_notify_warn("Já existe uma categoria com esse nome.")
            return
        cats[new_name] = cats.pop(old_name, [])
        self.save_categories(cats)
        # renomear JSON de metadados
        old_json = self._category_info_path(old_name)
        new_json = self._category_info_path(new_name)
        try:
            if xbmcvfs.exists(old_json):
                xbmcvfs.rename(old_json, new_json)
        except Exception as e:
            xbmc.log(f'[categories] erro ao renomear json: {e}')
            # se falhar, salva payload com novo nome
            payload = self._load_category_info(old_name) if xbmcvfs.exists(old_json) else self._default_category_payload(new_name)
            payload['m_category'] = new_name
            self._save_category_info(new_name, payload)
            if xbmcvfs.exists(old_json):
                try: xbmcvfs.delete(old_json)
                except: pass
        kodi_notify("Categoria renomeada.")
        kodi_refresh_container()

    def delete_category_dialog(self, name):
        if not xbmcgui.Dialog().yesno("Excluir categoria", f'Tem certeza que deseja excluir "{name}"?\n(Álbuns permanecem intactos)'):
            return
        cats = self.load_categories()
        if name in cats:
            cats.pop(name)
            self.save_categories(cats)
        # remove o JSON da categoria
        info_path = self._category_info_path(name)
        if xbmcvfs.exists(info_path):
            try: xbmcvfs.delete(info_path)
            except: pass
        kodi_notify("Categoria excluída.")
        kodi_refresh_container()

    def manage_categories_dialog(self):
        cats = self.load_categories()
        options = ["<Criar categoria>", "<Renomear categoria>", "<Excluir categoria>"]
        sel = xbmcgui.Dialog().select("Gerenciar categorias", options)
        if sel == 0:
            self.create_category_dialog()
        elif sel == 1:
            if not cats:
                kodi_notify_warn("Nenhuma categoria para renomear.")
                return
            cat = self._pick_category("Renomear qual categoria?")
            if cat:
                self.rename_category_dialog(cat)
        elif sel == 2:
            if not cats:
                kodi_notify_warn("Nenhuma categoria para excluir.")
                return
            cat = self._pick_category("Excluir qual categoria?")
            if cat:
                self.delete_category_dialog(cat)

    def _pick_category(self, title="Selecione a categoria"):
        cats = sorted(self.load_categories().keys(), key=str.lower)
        if not cats:
            return None
        idx = xbmcgui.Dialog().select(title, cats)
        return cats[idx] if idx >= 0 else None

    def assign_album_to_category_dialog(self, album_name):
        if not album_name:
            kodi_notify_warn("Álbum inválido.")
            return
        cats = self.load_categories()
        if not cats:
            if xbmcgui.Dialog().yesno("Categorias", "Não há categorias ainda. Criar agora?"):
                self.create_category_dialog()
                cats = self.load_categories()
            else:
                return
        # escolher categoria
        cat = self._pick_category("Adicionar a qual categoria?")
        if not cat:
            return
        self.assign_album_to_category(cat, album_name)

    def assign_album_to_category(self, category, album_name):
        cats = self.load_categories()
        albums = set(cats.get(category, []))
        if album_name not in albums:
            albums.add(album_name)
            cats[category] = sorted(albums, key=str.lower)
            self.save_categories(cats)
            kodi_notify("Álbum adicionado à categoria.")
            kodi_refresh_container()
        else:
            kodi_notify_warn("Álbum já está nessa categoria.")

    def unassign_album_from_category(self, category, album_name):
        cats = self.load_categories()
        if category in cats and album_name in cats[category]:
            cats[category] = [a for a in cats[category] if a != album_name]
            self.save_categories(cats)
            kodi_notify("Álbum removido da categoria.")
            kodi_refresh_container()

    def edit_category_dialog(self, category_name):
        if not category_name:
            kodi_notify('Invalid category name!')
            return

        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        category_json_path = os.path.join(addon_data_path, f'categories_db/{category_name}.json')

        if not xbmcvfs.exists(category_json_path):
            kodi_notify('Category JSON not found')
            return

        with open(category_json_path, 'r', encoding='utf-8') as json_file:
            category_info = json.load(json_file)

        edit_category_data = True
        data_change = False

        while edit_category_data:
            edit_options = [
                "Edit Category Metadata",
                "Edit Category Artwork",
            ]

            selected_edit = xbmcgui.Dialog().select(f"Edit Category — {category_name}", edit_options)
            if selected_edit == -1:
                break

            # --- METADATA ---
            if selected_edit == 0:
                while True:
                    options = [
                        f"Edit Category Title: {category_info.get('m_category', '')}",
                        f"Edit Description (plot): {category_info.get('m_plot', '')[:40] + ('…' if len(category_info.get('m_plot', '')) > 40 else '')}",
                        "Save Category"
                    ]
                    selected = xbmcgui.Dialog().select("Edit Category Metadata", options)
                    if selected == -1 or selected == 2:
                        break

                    if selected == 0:
                        new_title = xbmcgui.Dialog().input("Enter new category title", defaultt=category_info.get('m_category', ''))
                        if new_title:
                            category_info['m_category'] = new_title
                            data_change = True
                            kodi_notify('Category title updated')
                            self._save_category_info(category_name, category_info)

                    elif selected == 1:
                        new_plot = xbmcgui.Dialog().input("Enter new description (plot)", defaultt=category_info.get('m_plot', ''))
                        category_info['m_plot'] = new_plot or ''
                        data_change = True
                        kodi_notify('Category description updated')
                        self._save_category_info(category_name, category_info)

            # --- ARTWORK ---
            elif selected_edit == 1:
                # Lê a pasta padrão do scanner nas configurações
                try:
                    addon = xbmcaddon.Addon()
                    scan_path_setting = addon.getSetting('scan_path') or ''
                    scan_path = xbmcvfs.translatePath(scan_path_setting) if scan_path_setting else ''
                except Exception:
                    scan_path = ''

                def _compute_initial_dir(current_path):
                    """
                    1) Se já existe caminho salvo e o arquivo existe, abre a pasta dele
                    2) Senão, usa scan_path (se configurado e existir)
                    3) Senão, diretório do JSON da categoria
                    """
                    if current_path and (xbmcvfs.exists(current_path) or str(current_path).lower().startswith(('http://', 'https://'))):
                        return os.path.dirname(current_path) if '://' not in current_path else scan_path or os.path.dirname(category_json_path)
                    if scan_path and xbmcvfs.exists(scan_path):
                        return scan_path
                    return os.path.dirname(category_json_path)

                while True:
                    # Labels/Imagens com .get() para evitar KeyError
                    label_icon      = category_info.get('s_icon')      or 'No Art'
                    label_poster    = category_info.get('s_poster')    or 'No Art'
                    label_clearlogo = category_info.get('s_clearlogo') or 'No Art'
                    label_fanart    = category_info.get('s_fanart')    or 'No Art'
                    label_banner    = category_info.get('s_banner')    or 'No Art'

                    img_icon      = category_info.get('s_icon')      or 'DefaultAddonNone.png'
                    img_poster    = category_info.get('s_poster')    or 'DefaultAddonNone.png'
                    img_clearlogo = category_info.get('s_clearlogo') or 'DefaultAddonNone.png'
                    img_fanart    = category_info.get('s_fanart')    or 'DefaultAddonNone.png'
                    img_banner    = category_info.get('s_banner')    or 'DefaultAddonNone.png'

                    icon_item      = xbmcgui.ListItem(label='Edit Icon',      label2=label_icon)
                    poster_item    = xbmcgui.ListItem(label='Edit Poster',    label2=label_poster)
                    clearlogo_item = xbmcgui.ListItem(label='Edit Clearlogo', label2=label_clearlogo)
                    fanart_item    = xbmcgui.ListItem(label='Edit Fanart',    label2=label_fanart)
                    banner_item    = xbmcgui.ListItem(label='Edit Banner',    label2=label_banner)

                    icon_item.setArt({'icon': img_icon})
                    poster_item.setArt({'icon': img_poster})
                    clearlogo_item.setArt({'icon': img_clearlogo})
                    fanart_item.setArt({'icon': img_fanart})
                    banner_item.setArt({'icon': img_banner})

                    sDialog = KodiSelectDialog('Edit Category Artwork', useDetails=True)
                    sDialog.setRows([
                        icon_item,
                        poster_item,
                        clearlogo_item,
                        fanart_item,
                        banner_item,
                    ])
                    selected_art_edit = sDialog.executeDialog()
                    if selected_art_edit is None:
                        break

                    # helper: só escolhe e grava o path no JSON
                    def _pick_and_set(prompt_title, ext_hint, field_key, success_msg):
                        nonlocal data_change
                        initial_dir = _compute_initial_dir(category_info.get(field_key))
                        chosen = kodi_dialog_get_image(prompt_title, ext_hint, initial_dir)
                        # aceita arquivo local existente OU URL http(s)
                        if chosen and (xbmcvfs.exists(chosen) or str(chosen).lower().startswith(('http://', 'https://'))):
                            category_info[field_key] = chosen
                            data_change = True
                            self._save_category_info(category_name, category_info)
                            kodi_notify(success_msg)

                    # ICON
                    if selected_art_edit == 0:
                        _pick_and_set('Select Category Icon', '.jpg', 's_icon', 'Category Icon path updated')

                    # POSTER
                    elif selected_art_edit == 1:
                        _pick_and_set('Select Category Poster', '.jpg', 's_poster', 'Category Poster path updated')

                    # CLEARLOGO (normalmente .png)
                    elif selected_art_edit == 2:
                        _pick_and_set('Select Category Clearlogo', '.png', 's_clearlogo', 'Category Clearlogo path updated')

                    # FANART
                    elif selected_art_edit == 3:
                        _pick_and_set('Select Category Fanart', '.jpg', 's_fanart', 'Category Fanart path updated')

                    # BANNER
                    elif selected_art_edit == 4:
                        _pick_and_set('Select Category Banner', '.jpg', 's_banner', 'Category Banner path updated')



        if data_change:
            self._save_category_info(category_name, category_info)
            kodi_notify(f'Category "{category_name}" updated!')
            kodi_refresh_container()


    # =========================
    # ===== ALBUNS (UI) =======
    # =========================
    def display_album_sets(self, handle):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        json_files = [
            f for f in os.listdir(albums_db_path)
            if f.endswith('.json') and f != '_scan_timestamp.json'
        ]
        if not json_files:
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # conjuntos (nomes de arquivos sem .json)
        all_sets = [f[:-5] for f in json_files]
        cats = self.load_categories()

        # álbuns categorizados
        categorized = set()
        for arr in cats.values():
            categorized.update(arr)

        # ordem: [Not Set] (se existir) -> álbuns NÃO categorizados -> categorias
        ordered_unassigned = sorted([s for s in all_sets if s != "[Not Set]" and s not in categorized], key=str.lower)

        # 1) [Not Set]
        if "[Not Set]" in all_sets:
            self._add_album_header_item(handle, set_name='[Not Set]')

        # 2) álbuns não categorizados
        for set_name in ordered_unassigned:
            self._add_album_header_item(handle, set_name=set_name, add_assign_menu=True)

        # 3) categorias (como pastas)
        for category in sorted(cats.keys(), key=str.lower):
            li = xbmcgui.ListItem(label=category)
            ci = self._load_category_info(category)
            li = xbmcgui.ListItem(label = ci.get('m_category', category))
            li.setArt({
                'icon':      ci.get('s_icon')      or '',
                'poster':    ci.get('s_poster')    or '',
                'clearlogo': ci.get('s_clearlogo') or '',
                'fanart':    ci.get('s_fanart')    or '',
                'banner':    ci.get('s_banner')    or '',
            })
            
            m_category = ci.get('m_category', set_name)
            m_plot = ci.get('m_plot', set_name)
            li.setProperty('m_category', m_category)
            li.setProperty('m_plot', m_plot)
            
            # menus da categoria
            context_menu = [
                ('Criar categoria', 'RunPlugin(plugin://plugin.program.photololitas?action=create_category)'),
                ('Gerenciar categorias', 'RunPlugin(plugin://plugin.program.photololitas?action=manage_categories)'),
                ('Editar categoria', f'RunPlugin(plugin://plugin.program.photololitas?action=edit_category&category={urllib.parse.quote(category)})'),
                ('Renomear categoria', f'RunPlugin(plugin://plugin.program.photololitas?action=rename_category&category={urllib.parse.quote(category)})'),
                ('Excluir categoria', f'RunPlugin(plugin://plugin.program.photololitas?action=delete_category&category={urllib.parse.quote(category)})'),
                ('Scan Albuns', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
            ]
            li.addContextMenuItems(context_menu)
            url = f"plugin://plugin.program.photololitas/?folder=Albuns&category={urllib.parse.quote(category)}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(handle)

    def _add_album_header_item(self, handle, set_name, add_assign_menu=False):
        # Lê cabeçalho do JSON do álbum e monta o item
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        if not xbmcvfs.exists(albums_json_path):
            return

        with open(albums_json_path, 'r', encoding='utf-8') as f:
            albums_dict = json.load(f)

        album_info = albums_dict
        # conta itens ignorando chaves de metadados
        not_keys = {"m_album","m_tags","m_year","m_plot","m_path","s_icon","s_poster","s_clearlogo","s_fanart","s_banner"}
        set_count = sum(1 for k in albums_dict if k not in not_keys)

        li = xbmcgui.ListItem(label=album_info.get('m_album', set_name))
        theme = 'special://home/addons/plugin.program.photololitas/media/theme/'
        icon_art   = album_info.get('s_icon')     or f'{theme}Not_Set_icon.png'
        poster_art = album_info.get('s_poster')   or f'{theme}Not_Set_poster.png'
        fanart_art = album_info.get('s_fanart')   or f'{theme}_fanart.jpg'

        li.setArt({
            'icon': icon_art,
            'poster': poster_art,
            'clearlogo': album_info.get('s_clearlogo', ''),
            'fanart': fanart_art,
            'banner': album_info.get('s_banner', '')
        })

        m_album = album_info.get('m_album', set_name)
        m_plot  = f"{m_album} possui {set_count} sets\n\n{album_info.get('m_plot','')}"
        li.setProperty('m_album', m_album)
        li.setProperty('m_plot', m_plot)
        li.setInfo(type='pictures', infoLabels={'title': album_info.get('m_title','')})

        # contextos
        context_menu = [
            ("Edit Album", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_album&set={urllib.parse.quote(set_name)})"),
            ('Scan Albuns', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
            ('Settings', 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
        ]
        if add_assign_menu:
            context_menu.insert(0, (
                "Adicionar a categoria…",
                f"RunPlugin(plugin://plugin.program.photololitas?action=assign_album_to_category&album={urllib.parse.quote(set_name)})"
            ))
            context_menu.insert(1, (
                "Criar categoria",
                "RunPlugin(plugin://plugin.program.photololitas?action=create_category)"
            ))
            context_menu.insert(2, (
                "Gerenciar categorias",
                "RunPlugin(plugin://plugin.program.photololitas?action=manage_categories)"
            ))

        li.addContextMenuItems(context_menu)

        url = f"plugin://plugin.program.photololitas/?folder=Albuns&set={urllib.parse.quote(set_name)}"
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    def display_category_albums(self, handle, category_name):
        cats = self.load_categories()
        albums = cats.get(category_name, [])
        if not albums:
            xbmcgui.Dialog().notification('Categoria', 'Sem álbuns nesta categoria', xbmcgui.NOTIFICATION_INFO, 4000)
            xbmcplugin.endOfDirectory(handle)
            return

        for set_name in sorted(albums, key=str.lower):
            addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
            if not xbmcvfs.exists(albums_json_path):
                continue

            with open(albums_json_path, 'r', encoding='utf-8') as f:
                album_info = json.load(f)

            # Criação do item
            li = xbmcgui.ListItem(label=album_info.get('m_album', set_name))
            theme = 'special://home/addons/plugin.program.photololitas/media/theme/'
            li.setArt({
                'icon': album_info.get('s_icon') or f'{theme}Not_Set_icon.png',
                'poster': album_info.get('s_poster') or f'{theme}Not_Set_poster.png',
                'fanart': album_info.get('s_fanart') or f'{theme}_fanart.jpg',
                'clearlogo': album_info.get('s_clearlogo',''),
                'banner': album_info.get('s_banner',''),
            })

            # 🔹 METADADOS
            not_keys = {"m_album","m_tags","m_year","m_plot","m_path","s_icon","s_poster","s_clearlogo","s_fanart","s_banner"}
            set_count = sum(1 for k in album_info if k not in not_keys)

            m_album = album_info.get('m_album', set_name)
            m_plot  = f"{m_album} possui {set_count} sets\n\n{album_info.get('m_plot','')}"
            m_year  = album_info.get('m_year', '') 
            m_tags  = album_info.get('m_tags', '')

            li.setProperty('m_album', m_album)
            li.setProperty('m_plot', m_plot)
            li.setProperty('m_year', str(m_year))
            li.setProperty('m_tags', m_tags)

            # Adiciona infoLabels (usados no painel do Kodi)
            li.setInfo(type='pictures', infoLabels={
                'title': album_info.get('m_title', ''),
                'year': m_year,
                'plot': album_info.get('m_plot', ''),
            })

            # Menus de contexto
            li.addContextMenuItems([
                ("Remover desta categoria", f"RunPlugin(plugin://plugin.program.photololitas?action=unassign_album_from_category&category={urllib.parse.quote(category_name)}&album={urllib.parse.quote(set_name)})"),
                ("Edit Album", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_album&set={urllib.parse.quote(set_name)})"),
            ])

            url = f"plugin://plugin.program.photololitas/?folder=Albuns&set={urllib.parse.quote(set_name)}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(handle)

    # =========================
    # ===== ITENS/SETS ========
    # =========================
    def display_album_items(self, handle, set_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        # Ignorar as chaves de metadados principais
        album_metadata_keys = {"m_album", "m_tags", "m_year", "m_plot", "m_path", "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"}
        album_items = {k: v for k, v in albums_dict.items() if k not in album_metadata_keys}

        # Ordenar os itens alfabeticamente por m_model
        sorted_items = sorted(album_items.items(), key=lambda item: item[1].get('m_model', '').lower())

        for album_key, album_info in sorted_items:
            
            # Defina o label como m_model
            label = album_info.get('m_model', 'Unknown Model')
            li = xbmcgui.ListItem(label=label)
            
            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })

            # Setar informações adicionais como propriedades
            li.setProperty('m_number', album_info.get('m_number', ''))
            li.setProperty('m_title', album_info.get('m_title', ''))
            li.setProperty('m_model', album_info.get('m_model', ''))
            li.setProperty('m_others', album_info.get('m_others', ''))
            li.setProperty('m_album', album_info.get('m_album', ''))
            li.setProperty('m_tags', album_info.get('m_tags', ''))
            li.setProperty('m_date', album_info.get('m_date', ''))
            li.setProperty('m_plot', album_info.get('m_plot', ''))
            li.setProperty('m_path', album_info.get('m_path', ''))

            # Definir infoLabels
            info_labels = {
                'title': album_info.get('m_title', ''),
                'label': album_info.get('m_model', ''),  
                'date': album_info.get('m_date', ''),
                'episode': album_info.get('m_number', ''),
            }
            li.setInfo(type='video', infoLabels=info_labels)
            
            album_name = album_info.get('m_album')
            
            # Adicionar o menu de contexto "Edit Issues"
            if not album_name:
                context_menu = [
                    ("Edit Issue", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_issue&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (f'Update Lolitas Database', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                    
                ]
            else:    
                context_menu = [
                    ("Edit Issue", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_issue&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (f'Update {album_name} Database', f'RunPlugin(plugin://plugin.program.photololitas?action=update_album&album_name={album_name})'),
                    (f'Update Lolitas Database', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
                    ('Scan Albuns', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
                ]
            li.addContextMenuItems(context_menu)
                
                

            # URL para abrir a janela de imagens
            url = f'plugin://plugin.program.photololitas?action=open_pictures&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por label (m_model)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_TITLE)  # Ordenar por título (se aplicável)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)   # Ordenar por data (se aplicável)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE) # Ordenar por episódio (se aplicável)

        xbmcplugin.endOfDirectory(handle)

    def display_all_sets(self, handle):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        # Forçar atualização sempre que entrar no diretório
        xbmc.executebuiltin('Container.Refresh')

        json_files = [filename for filename in os.listdir(albums_db_path) if filename.endswith('.json')]

        if not json_files:
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # Lista para armazenar todos os álbuns
        all_albums = []

        # Iterar sobre todos os arquivos JSON
        for set_name in json_files:
            albums_json_path = os.path.join(albums_db_path, set_name)

            with open(albums_json_path, 'r', encoding='utf-8') as json_file:
                albums_dict = json.load(json_file)

            # Ignorar arquivos JSON sem conjuntos específicos
            for album_key, album_info in albums_dict.items():
                # Pula as chaves do cabeçalho como 'm_album', 's_icon', etc.
                if isinstance(album_info, dict) and 'm_title' in album_info:
                    all_albums.append(album_info)

        if not all_albums:
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # Ordenar os álbuns por título
        all_albums_sorted = sorted(all_albums, key=lambda x: x.get('m_title', '[No Title]'))

        for album_info in all_albums_sorted:
            li = xbmcgui.ListItem(label=album_info.get('m_title', '[No Title]'))

            theme = 'special://home/addons/plugin.program.photololitas/media/theme/'

            icon_art = album_info.get('s_icon')     if album_info.get('s_icon')   else f'{theme}Not_Set_icon.png'
            poster_art = album_info.get('s_poster') if album_info.get('s_poster') else f'{theme}Not_Set_poster.png'
            fanart_art = album_info.get('s_fanart') if album_info.get('s_fanart') else f'{theme}_fanart.jpg'

            li.setArt({
                'icon': icon_art,
                'poster': poster_art,
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': fanart_art,
                'banner': album_info.get('s_banner', '')
            })

            # Verificar se os metadados existem
            m_album = album_info.get('m_album', '')
            m_tags = album_info.get('m_tags', '')
            m_year = album_info.get('m_year', '')
            m_plot = album_info.get('m_plot', '')

            # Definir as propriedades para o item da lista
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', m_tags)
            li.setProperty('m_year', m_year)
            li.setProperty('m_plot', m_plot)

            # Definir infoLabels
            info_labels = {
                'title': album_info.get('m_title', '[No Title]'),
            }
            li.setInfo(type='pictures', infoLabels=info_labels)

            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                ("Edit Album", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_album&album={urllib.parse.quote(album_info.get('m_title', ''))})"),
                (f'Scan Albuns', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
            ]
            li.addContextMenuItems(context_menu)

            # URL para abrir detalhes do álbum
            url = f"plugin://plugin.program.photololitas/?folder=Albums&album={urllib.parse.quote(album_info.get('m_title', ''))}"
            # URL para abrir a janela de imagens
            url = f'plugin://plugin.program.photololitas?action=open_pictures&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por data
        
        # Finaliza a listagem e garante que o conteúdo seja atualizado
        xbmcplugin.endOfDirectory(handle)
    
    def display_model_sets(self, handle):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        lolitas_timestamp_file = os.path.join(lolitas_db_path, '_scan_timestamp.json')
        albums_timestamp_file = os.path.join(albums_db_path, '_scan_timestamp.json')

        # Verificar se os arquivos de timestamp existem
        if xbmcvfs.exists(lolitas_timestamp_file) and xbmcvfs.exists(albums_timestamp_file):
            try:
                # Ler os arquivos de timestamp
                with open(lolitas_timestamp_file, 'r', encoding='utf-8') as f:
                    lolitas_data = json.load(f)
                with open(albums_timestamp_file, 'r', encoding='utf-8') as f:
                    albums_data = json.load(f)

                # Obter os timestamps
                lolitas_timestamp = lolitas_data.get('last_scan')
                albums_timestamp = albums_data.get('last_scan')

                # Verificar se ambos os timestamps foram encontrados e são válidos
                if lolitas_timestamp is None or albums_timestamp is None:
                    raise ValueError('Timestamp missing in one of the JSON files')

                # Comparar os timestamps Unix diretamente
                if lolitas_timestamp < albums_timestamp:
                    xbmcgui.Dialog().notification('Updating Lolitas', 'Model data is outdated. Updating now...', xbmcgui.NOTIFICATION_INFO, 5000)
                    self.scan_lolitas()

            except (ValueError, TypeError, json.JSONDecodeError, Exception) as e:
                xbmc.log(f"Error comparing timestamps: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().notification('Error', 'Failed to compare timestamps', xbmcgui.NOTIFICATION_ERROR, 5000)
                return

        else:
            # Se algum dos arquivos de timestamp não existir, chamar scan_lolitas
            xbmcgui.Dialog().notification('Updating Lolitas', 'Timestamp not found. Updating lolitas...', xbmcgui.NOTIFICATION_INFO, 5000)
            self.scan_lolitas()

        # Continuar com a exibição dos conjuntos de modelos
        json_files = [filename for filename in os.listdir(lolitas_db_path) if filename.endswith('.json') and filename != '_scan_timestamp.json']

        if not json_files:
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        album_sets = [filename.replace('.json', '') for filename in json_files]

        # Ordenar os conjuntos alfabeticamente
        sorted_sets = sorted(album_sets)

        # Mover [Not Set] para o início, se existir
        if "[Not Set]" in sorted_sets:
            sorted_sets.remove("[Not Set]")
            sorted_sets.insert(0, "[Not Set]")

        for set_name in sorted_sets:
            albums_json_path = os.path.join(lolitas_db_path, f"{set_name}.json")

            with open(albums_json_path, 'r', encoding='utf-8') as json_file:
                albums_dict = json.load(json_file)
            
            album_info = albums_dict
            
            # Contar o número de sets (volumes) presentes no JSON
            not_count = ["m_model", "m_type", "s_icon", "s_poster", "s_fanart", "s_banner"]

            # Contar o número de sets (volumes) ignorando as propriedades gerais
            set_count = sum(1 for key in albums_dict if key not in not_count)

            li = xbmcgui.ListItem(label=set_name)
            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })

            # Verificar se os metadados existem
            m_title = album_info.get('m_title', '[No Title]')
            m_album = album_info.get('m_album', '')
            m_tags = album_info.get('m_tags', '')
            m_year = album_info.get('m_year', '')
            m_plot = album_info.get('m_plot', '')
            m_model = album_info.get('m_model', '[No Model]')
            
            # Adicionar a frase "m_model possui X sets" ao início do m_plot
            m_plot = f"{m_model} possui {set_count} sets\n{m_plot}"

            # Definir as propriedades para o item da lista
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', m_tags)
            li.setProperty('m_year', m_year)
            li.setProperty('m_plot', m_plot)

            # Definir infoLabels
            info_labels = {
                'title': album_info.get('m_title', ''),
                'label': album_info.get('m_model', ''),  
                'date': album_info.get('m_date', ''),
                'episode': album_info.get('m_number', ''),
            }
            li.setInfo(type='video', infoLabels=info_labels)
            
            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                (f'Update Lolitas', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
            ]
            li.addContextMenuItems(context_menu)

            # URL para abrir o conjunto de álbuns
            url = f"plugin://plugin.program.photololitas/?folder=Lolitas&set={urllib.parse.quote(set_name)}"

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por nome
        
        xbmcplugin.endOfDirectory(handle)

    def display_model_items(self, handle, set_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'lolitas_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        # Ignorar as chaves de metadados principais
        album_metadata_keys = {"m_model", "m_type", "s_icon", "s_poster", "s_fanart", "s_banner"}
        album_items = {k: v for k, v in albums_dict.items() if k not in album_metadata_keys}

        # Ordenar os itens alfabeticamente
        sorted_items = sorted(album_items.items())

        for album_key, album_info in sorted_items:
            li = xbmcgui.ListItem(label=album_info.get("m_title", "Unknown Title"))

            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })
            
            m_album = album_info.get('m_album', '')
            if not m_album:
                m_album = '[Not Set]'

            # Setar informações adicionais como propriedades
            li.setProperty('m_number', album_info.get('m_number', ''))
            li.setProperty('m_title', album_info.get('m_title', ''))
            li.setProperty('m_model', album_info.get('m_model', ''))
            li.setProperty('m_others', album_info.get('m_others', ''))
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', album_info.get('m_tags', ''))
            li.setProperty('m_date', album_info.get('m_date', ''))
            li.setProperty('m_plot', album_info.get('m_plot', ''))
            li.setProperty('m_path', album_info.get('m_path', ''))

            # Definir infoLabels
            info_labels = {
                'title': album_info.get('m_title', ''),
                'label': album_info.get('m_model', ''),  
                'date': album_info.get('m_date', ''),
                'episode': album_info.get('m_number', ''),
            }
            li.setInfo(type='video', infoLabels=info_labels)
            
            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                ("Edit Issue", f"RunPlugin(plugin://plugin.program.photololitas?action=edit_issue&set={urllib.parse.quote(m_album)}&album={urllib.parse.quote(album_key)})"),
                (f'Update Lolitas', f'RunPlugin(plugin://plugin.program.photololitas?action=scan_lolitas)'),
            ]
            li.addContextMenuItems(context_menu)

            # URL para abrir a janela de imagens
            url = f'plugin://plugin.program.photololitas?action=open_pictures&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        
        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por nome
        
        xbmcplugin.endOfDirectory(handle)

    def edit_album(self, set_name):
        
        if set_name == '[Not Set]':
            kodi_notify('This album cannot be edited!')
            return
            
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            kodi_notify('Album JSON not found')
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)
            
        album_info = albums_dict
        edit_album_data = True
        data_change = False
        
        while edit_album_data == True:
            edit_options = [
                "Edit Album Metadata",
                "Edit Album Artwork",
            ]
            
            selected_edit = xbmcgui.Dialog().select("Edit Album", edit_options)
            
            if selected_edit == -1:
                break
            
            if selected_edit == 0:
                while True:
                    options = [
                        "Edit Album Title: {}".format(album_info.get('m_album', '')),
                        "Edit Album Tags: {}".format(album_info.get('m_tags', '')),
                        "Edit Album Release Year: {}".format(album_info.get('m_year', '')),
                        "Edit Album Plot: {}".format(album_info.get('m_plot', '')),
                        "Save Album"
                    ]
                    selected = xbmcgui.Dialog().select("Edit Album", options)
                    
                    if selected == -1 or selected == 5:
                        break
                    
                    if selected == 0:
                        new_title = xbmcgui.Dialog().input("Enter new title", defaultt=album_info.get('m_album', ''))
                        if new_title:
                            album_info['m_album'] = new_title
                            data_change = True
                            kodi_notify('Album title updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 1:
                        new_tags = xbmcgui.Dialog().input("Enter new tags", defaultt=album_info.get('m_tags', ''))
                        if new_tags:
                            album_info['m_tags'] = new_tags
                            kodi_notify('Album tags updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 2:
                        new_year = xbmcgui.Dialog().numeric(0, "Enter new release date", defaultt=album_info.get('m_year', ''))
                        if new_year:
                            album_info['m_year'] = new_year
                            data_change = True
                            kodi_notify('Album release year updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 3:
                        new_plot = xbmcgui.Dialog().input("Enter new plot", defaultt=album_info.get('m_plot', ''))
                        if new_plot:
                            album_info['m_plot'] = new_plot
                            kodi_notify('Album plot updated')
                            self.save_json(albums_json_path, albums_dict)
                    
                    elif selected == 4:
                        self.save_album_nfo(album_info)
                        kodi_notify("Data from from {} saved!".format(album_info.get('m_album')))
                        break
                    
            elif selected_edit == 1:
                while True:
                    
                    label2_poster    = album_info['s_poster'] if album_info['s_poster'] else 'No Art'
                    label2_fanart    = album_info['s_fanart'] if album_info['s_fanart'] else 'No Art'
                    label2_icon      = album_info['s_icon']   if album_info['s_icon']   else 'No Art'
                    label2_clearlogo = album_info['s_clearlogo'] if album_info['s_clearlogo'] else 'No Art'
                    label2_banner    = album_info['s_banner'] if album_info['s_banner'] else 'No Art'
                    
                    img_poster    = album_info['s_poster'] if album_info['s_poster'] else 'DefaultAddonNone.png'
                    img_fanart    = album_info['s_fanart'] if album_info['s_fanart'] else 'DefaultAddonNone.png'
                    img_icon      = album_info['s_icon']   if album_info['s_icon']   else 'DefaultAddonNone.png'
                    img_clearlogo = album_info['s_clearlogo'] if album_info['s_clearlogo'] else 'DefaultAddonNone.png'
                    img_banner    = album_info['s_banner'] if album_info['s_banner'] else 'DefaultAddonNone.png'
                    
                    poster_listitem    = xbmcgui.ListItem(label = 'Edit Poster', label2 = label2_poster)
                    fanart_listitem    = xbmcgui.ListItem(label = 'Edit fanart', label2 = label2_fanart)
                    icon_listitem      = xbmcgui.ListItem(label = 'Edit icon',   label2 = label2_icon)
                    clearlogo_listitem = xbmcgui.ListItem(label = 'Edit clearlogo', label2 = label2_clearlogo)
                    banner_listitem    = xbmcgui.ListItem(label = 'Edit banner', label2 = label2_banner)

                    poster_listitem.setArt   ({'icon' : img_poster})
                    fanart_listitem.setArt   ({'icon' : img_fanart})
                    icon_listitem.setArt     ({'icon' : img_icon})
                    clearlogo_listitem.setArt({'icon' : img_clearlogo})
                    banner_listitem.setArt   ({'icon' : img_banner})
                    
                    destination_path =  album_info['m_path']
                
                    sDialog = KodiSelectDialog('Edit Album Artwork', useDetails = True)
                    sDialog.setRows([
                        poster_listitem,
                        fanart_listitem,
                        icon_listitem,
                        clearlogo_listitem,
                        banner_listitem,
                    ])
                    selected_art_edit = sDialog.executeDialog()
                    if selected_art_edit is None: break
                    
                    if selected_art_edit == 0:
                        new_poster = kodi_dialog_get_image('Select Album Poster', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_poster == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Poster not change!')
                                    break
                            
                            album_info['s_poster'] = os.path.join(destination_path, 'folder.jpg')
                            self.save_artwork(new_poster, 's_poster', album_info, albums_json_path, albums_dict, 'Album Poster updated')

                        
                    elif selected_art_edit == 1:
                        new_fanart = kodi_dialog_get_image('Select Album Fanart', ',jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_fanart == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                                    
                            album_info['s_fanart'] = os.path.join(destination_path, 'fanart.jpg')
                            self.save_artwork(new_fanart, 's_fanart', album_info, albums_json_path, albums_dict, 'Album Fanart updated')
                            
                            utils_update_file_mtime(new_fanart)
                            
                    elif selected_art_edit == 2:
                        new_icon = kodi_dialog_get_image('Select Album Icon', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_icon == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_icon'] = os.path.join(destination_path, 'icon.jpg')
                            self.save_artwork(new_icon, 's_icon', album_info, albums_json_path, albums_dict, 'Album Icon updated')
                            
                    elif selected_art_edit == 3:
                        new_clearlogo = kodi_dialog_get_image('Select Album Clearlogo', '.png', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_clearlogo == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            return
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_clearlogo'] = os.path.join(destination_path, 'clearlogo.png')
                            self.save_artwork(new_clearlogo, 's_clearlogo', album_info, albums_json_path, albums_dict, 'Album Clearlogo updated')

                    elif selected_art_edit == 4:
                        new_banner = kodi_dialog_get_image('Select Album Banner', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_banner == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            return
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_banner'] = os.path.join(destination_path, 'banner.jpg')
                            self.save_artwork(new_banner, 's_banner', album_info, albums_json_path, albums_dict, 'Album Banner updated')

        if data_change:           
            self.save_album_nfo(album_info)
        
    def edit_issue(self, set_name, album_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
       
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification('Edit Issue', 'Album JSON not found', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        if album_name not in albums_dict:
            xbmcgui.Dialog().notification('Edit Issue', 'Album not found in JSON', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        album_info = albums_dict[album_name]

        edit_options = [
            "Edit Issue Metadata",
            "Scan Issue Metadata",
            "Edit Issue Artwork",
            "Scan Issue Artwork",
            "Save Issue"
        ]
        
        selected_edit = xbmcgui.Dialog().select(f"Edit {album_name}", edit_options)
        if selected_edit == -1:
            return
        
        if selected_edit == 0:
            while True:
            
                plot_str = text_limit_string(album_info.get('m_plot'), 40)
                sDialog = KodiSelectDialog('Edit Issue Metadata', useDetails = False)
                sDialog.setRows([
                    "Edit Number: {}".format(album_info.get('m_number')), 
                    "Edit Title: {}".format(album_info.get('m_title')),
                    "Edit Model: {}".format(album_info.get('m_model')), 
                    "Edit Other Names: {}".format(album_info.get('m_others')), 
                    "Edit Album: {}".format(album_info.get('m_album')),
                    "Edit Tags: {}".format(album_info.get('m_tags')),
                    "Edit Release Date: {}".format(album_info.get('m_date')),
                    "Edit Plot: {}".format(plot_str),
                    "Scan Issue Metadata from {}".format(album_info.get('m_album')),
                    "Save Issue Metadata"
                ])
                selected = sDialog.executeDialog()
                if selected is None: break

                if selected == 0:
                    new_number = xbmcgui.Dialog().input("Enter new issue number", defaultt=album_info.get('m_number', ''), type=xbmcgui.INPUT_NUMERIC)
                    if new_number:
                        album_info['m_number'] = new_number
                        kodi_notify('Issue number updated')
                        self.save_json(albums_json_path, albums_dict)

                elif selected == 1:
                    new_title = xbmcgui.Dialog().input("Enter new title", defaultt=album_info.get('m_title', ''))
                    if new_title:
                        album_info['m_title'] = new_title
                        kodi_notify('Issue title updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)

                elif selected == 2:
                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')

                    # Obter a lista de arquivos JSON existentes, excluindo '[Not Set]' e '_scan_timestamp.json'
                    model_files = [f for f in os.listdir(lolitas_db_path) if f.endswith('.json') and f not in ['[Not Set].json', '_scan_timestamp.json']]

                    # Remover a extensão dos arquivos
                    model_folders = [os.path.splitext(f)[0] for f in model_files]

                    # Adicionar a opção de criar um novo álbum no topo da lista
                    options = ['<Criar Novo Álbum>'] + model_folders
                    selected_model_index = xbmcgui.Dialog().select("Select Model or Create New", options)

                    if selected_model_index >= 0:
                        if selected_model_index == 0:  # Se o usuário escolheu a opção de criar um novo álbum
                            # Solicitar ao usuário que insira o nome do novo álbum
                            new_model = xbmcgui.Dialog().input("Digite o nome do novo álbum")
                            if not new_model:
                                xbmcgui.Dialog().notification("Erro", "Nome do álbum não pode ser vazio.")
                                return
                        else:
                            # Se o usuário selecionou um álbum existente
                            new_model = options[selected_model_index]
                        
                        origin_file = album_info.get('m_album') or "[Not Set]"
                        destiny_file = f"{new_model}"
                        
                        origin_path = os.path.join(lolitas_db_path, f"{origin_file}.json")
                        destiny_path = os.path.join(lolitas_db_path, f"{destiny_file}.json")

                        item_key = album_name

                        album_info['m_model'] = new_model
                        self.save_json(albums_json_path, albums_dict)

                        # Verificar se o álbum de destino já existe
                        destiny_data = {}
                        
                        if xbmcvfs.exists(destiny_path):
                            
                            # Carregar o arquivo de destino existente
                            try:
                                with xbmcvfs.File(destiny_path) as destiny_file_handle:
                                    destiny_data = json.load(destiny_file_handle)
                            except Exception as e:
                                xbmcgui.Dialog().notification("Error", f'Erro ao carregar o álbum de destino: {str(e)}')
                                return
                        else:
                            # Criar o cabeçalho padrão para o novo álbum
                            destiny_data = {
                                "m_model": new_model,
                                "m_type": "",
                                "s_icon": "",
                                "s_poster": "",
                                "s_fanart": "",
                                "s_banner": ""
                            }

                        # Carregar o arquivo de origem
                        try:
                            with xbmcvfs.File(origin_path) as origin_file_handle:
                                origin_data = json.load(origin_file_handle)
                        except Exception as e:
                            xbmcgui.Dialog().notification("Error", f'Erro ao carregar o arquivo de origem: {str(e)}')
                            return

                        # Remover o item do arquivo de origem
                        if item_key in origin_data:
                            item_data = origin_data.pop(item_key)

                            # Adicionar o item ao arquivo de destino
                            destiny_data[item_key] = item_data

                            # Salvar as alterações nos arquivos JSON
                            try:
                                # Salvar o arquivo de origem atualizado (sem o item)
                                with xbmcvfs.File(origin_path, 'w') as origin_file_handle:
                                    origin_file_handle.write(json.dumps(origin_data, indent=4, ensure_ascii=False))

                                # Salvar o arquivo de destino atualizado (com o novo item)
                                with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                    destiny_file_handle.write(json.dumps(destiny_data, indent=4, ensure_ascii=False))

                                xbmcgui.Dialog().notification("Success", f'Modelo "{item_key}" foi movido com sucesso para o grupo "{new_model}".')

                                # Excluir o arquivo de origem se estiver vazio
                                if not origin_data:
                                    xbmcvfs.delete(origin_path)
                                
                                # Excluir o arquivo "_scan_timestamp.json" e "[Not Set].json"
                                scan_timestamp_path = os.path.join(lolitas_db_path, '_scan_timestamp.json')
                                if xbmcvfs.exists(scan_timestamp_path):
                                    xbmcvfs.delete(scan_timestamp_path)

                                not_set_path = os.path.join(lolitas_db_path, '[Not Set].json')
                                if xbmcvfs.exists(not_set_path):
                                    xbmcvfs.delete(not_set_path)
                                
                                self.save_issue_nfo(album_info) 
                                save_timestamp(albums_db_path)
                                kodi_refresh_container()

                            except Exception as e:
                                xbmcgui.Dialog().notification("Error", f'Erro ao salvar os arquivos JSON: {str(e)}')
                                xbmc.log(f'Erro ao salvar os arquivos JSON: {str(e)}', xbmc.LOGERROR)
                        else:
                            xbmcgui.Dialog().notification("Error", f'O item "{item_key}" não foi encontrado no álbum de origem.')
                    else:
                        xbmcgui.Dialog().notification("Canceled", "Nenhum álbum foi selecionado.")
                
                elif selected == 3:
                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')

                    # Obter a lista de arquivos JSON existentes, excluindo '[Not Set]' e '_scan_timestamp.json'
                    model_files = [f for f in os.listdir(lolitas_db_path) if f.endswith('.json') and f not in ['[Not Set].json', '_scan_timestamp.json']]

                    # Remover a extensão dos arquivos
                    model_folders = [os.path.splitext(f)[0] for f in model_files]

                    # Adicionar a opção de criar novos álbuns no topo da lista
                    options = ['<Criar Nova Modelo>'] + model_folders

                    # Obter os modelos existentes em 'm_others' e 'm_model'
                    existing_others_str = album_info.get('m_others', "")
                    existing_model_str = album_info.get('m_model', "")

                    # Combinar 'm_others' e 'm_model' em uma única lista, garantindo que todos os valores estejam limpos e não haja duplicação
                    existing_lolitas = [model.strip() for model in existing_others_str.split(",") if model.strip()] + \
                                      [model.strip() for model in existing_model_str.split(",") if model.strip()]

                    # Remover duplicatas
                    existing_lolitas = list(set(existing_lolitas))

                    # Determinar quais opções já estão presentes em 'm_others' ou 'm_model' e selecionar seus índices
                    preselected_indices = [i for i, option in enumerate(options[1:], start=1) if option in existing_lolitas]

                    # Mostrar a caixa de diálogo multisseleção com as opções pré-selecionadas
                    selected_lolitas_indices = xbmcgui.Dialog().multiselect("Selecione uma ou mais Modelos ou Crie Novas", options, preselect=preselected_indices)

                    if selected_lolitas_indices:
                        new_lolitas = []

                        # Verificar se a opção de criar novo álbum foi selecionada
                        if 0 in selected_lolitas_indices:  # Se o índice 0 foi selecionado
                            # Obter os nomes selecionados da janela anterior para exibi-los na entrada de texto
                            selected_model_names = [options[i] for i in selected_lolitas_indices if i > 0]  # Ignorar o índice 0 (Criar Novo Álbum)
                            selected_model_names_str = ", ".join(selected_model_names)

                            # Solicitar ao usuário que insira os novos nomes de álbuns, separados por vírgulas
                            new_model_input = xbmcgui.Dialog().input("Digite o nome da nova Modelo (separado por vírgulas)", defaultt=selected_model_names_str)

                            if new_model_input:
                                # Dividir os nomes digitados pelo usuário e adicionar à lista, garantindo que não haja duplicação
                                new_lolitas += [model.strip() for model in new_model_input.split(",")]

                        # Adicionar os álbuns selecionados à lista
                        selected_lolitas = [options[i] for i in selected_lolitas_indices if i > 0]  # Ignorar o índice 0 (Criar Novo Álbum)
                        new_lolitas += selected_lolitas

                        # Combinar os modelos existentes com os novos e garantir que não haja duplicatas
                        combined_lolitas = list(set(existing_lolitas + new_lolitas))

                        # Transformar a lista em uma string separada por vírgulas
                        new_lolitas_str = ", ".join(combined_lolitas)

                        # Atualizar a informação do álbum
                        album_info['m_others'] = new_lolitas_str
                        self.save_json(albums_json_path, albums_dict)

                        # Notificar o usuário do sucesso
                        xbmcgui.Dialog().notification("Sucesso", f'Modelos "{new_lolitas_str}" foram selecionados ou criados com sucesso.')
                        
                        # Salvar o arquivo de timestamp e atualizar o contêiner do Kodi
                        save_timestamp(albums_db_path)
                        kodi_refresh_container()

                    else:
                        xbmcgui.Dialog().notification("Cancelado", "Nenhum álbum foi selecionado.")   
                
                elif selected == 4:
                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    albums_db_path = os.path.join(addon_data_path, 'albuns_db')

                    # Obter a lista de arquivos JSON existentes, excluindo '[Not Set]'
                    album_files = [f for f in os.listdir(albums_db_path) if f.endswith('.json') and f != '[Not Set].json']

                    # Remover a extensão dos arquivos
                    album_folders = [os.path.splitext(f)[0] for f in album_files]

                    # Adicionar a opção "Adicionar Album" no topo da lista
                    options = ["Adicionar Album"] + album_folders
                    selected_album_index = xbmcgui.Dialog().select("Select Album", options)

                    if selected_album_index == 0:  # O usuário selecionou "Adicionar Album"
                        keyboard = xbmcgui.Dialog().input("Digite o nome do novo álbum", type=xbmcgui.INPUT_ALPHANUM)
                        if keyboard:  # Se o usuário digitou algo
                            selected_album = keyboard
                        else:
                            xbmcgui.Dialog().notification("Canceled", "Nenhum nome de álbum foi inserido.")
                            return  # Sai da função se o usuário cancelar a entrada de texto
                    elif selected_album_index > 0:
                        selected_album = options[selected_album_index]
                    else:
                        xbmcgui.Dialog().notification("Canceled", "Nenhum álbum foi selecionado.")
                        return  # Sai da função se o usuário cancelar a seleção

                    # Identificar o arquivo de origem e destino
                    origin_file = album_info.get('m_album') or "[Not Set]"
                    destiny_file = selected_album
                    
                    origin_path = os.path.join(albums_db_path, f"{origin_file}.json")
                    destiny_path = os.path.join(albums_db_path, f"{destiny_file}.json")
                    item_key = album_name

                    # Atualizar o nome do álbum
                    album_info['m_album'] = os.path.splitext(destiny_file)[0]
                    self.save_json(albums_json_path, albums_dict)

                    try:
                        # Carregar os arquivos JSON de origem e destino
                        with xbmcvfs.File(origin_path) as origin_file_handle:
                            origin_data = json.load(origin_file_handle)

                        # Se o arquivo de destino não existir, criar o cabeçalho básico
                        if not xbmcvfs.exists(destiny_path):
                            destiny_data = {
                                "m_album": destiny_file,  # Ou destiny_file sem extensão, se necessário
                                "m_tags": "",
                                "m_year": "",
                                "m_plot": "",
                                "m_path": "",
                                "s_icon": "",
                                "s_poster": "",
                                "s_clearlogo": "",
                                "s_fanart": "",
                                "s_banner": ""
                            }
                        else:
                            with xbmcvfs.File(destiny_path) as destiny_file_handle:
                                destiny_data = json.load(destiny_file_handle)

                        # Remover o item do arquivo de origem e adicionar ao destino
                        if item_key in origin_data:
                            item_data = origin_data.pop(item_key)
                            destiny_data[item_key] = item_data

                            # Verificar se o arquivo de origem está vazio após remoção
                            if not origin_data:
                                xbmcvfs.delete(origin_path)
                            else:
                                with xbmcvfs.File(origin_path, 'w') as origin_file_handle:
                                    origin_file_handle.write(json.dumps(origin_data, indent=4, ensure_ascii=False))

                            # Salvar o arquivo de destino atualizado com o cabeçalho e o item movido
                            with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                destiny_file_handle.write(json.dumps(destiny_data, indent=4, ensure_ascii=False))

                            xbmcgui.Dialog().notification("Success", f'O item "{item_key}" foi movido com sucesso para o álbum "{selected_album}".')
                            self.save_issue_nfo(album_info) 
                            save_timestamp(albums_db_path)
                            kodi_refresh_container()
                            
                            # Saindo do loop
                            break
                        
                        else:
                            xbmcgui.Dialog().notification("Error", f'O item "{item_key}" não foi encontrado no álbum de origem.')
                    except Exception as e:
                        xbmcgui.Dialog().notification("Error", f"Falha ao mover o item: {str(e)}")

                elif selected == 5:
                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    tags_db_path = os.path.join(addon_data_path, 'tags_db')

                    # Obter a lista de arquivos JSON existentes, excluindo '[Not Set]' e '_scan_timestamp.json'
                    tags_files = [f for f in os.listdir(tags_db_path) if f.endswith('.json') and f not in ['[Not Set].json', '_scan_timestamp.json']]

                    # Remover a extensão dos arquivos
                    tags_folders = [os.path.splitext(f)[0] for f in tags_files]

                    # Adicionar a opção de criar novos álbuns no topo da lista
                    options = ['<Criar Nova Tag>'] + tags_folders

                    # Obter os modelos existentes em 'm_others' e 'm_model'
                    existing_tags_str = album_info.get('m_tags', "")

                    # Combinar 'm_others' e 'm_model' em uma única lista, garantindo que todos os valores estejam limpos e não haja duplicação
                    existing_tags = [tag.strip() for tag in existing_tags_str.split(",") if tag.strip()] 

                    # Remover duplicatas
                    existing_tags = list(set(existing_tags))

                    # Determinar quais opções já estão presentes em 'm_others' ou 'm_model' e selecionar seus índices
                    preselected_indices = [i for i, option in enumerate(options[1:], start=1) if option in existing_tags]

                    # Mostrar a caixa de diálogo multisseleção com as opções pré-selecionadas
                    selected_tags_indices = xbmcgui.Dialog().multiselect("Selecione uma ou mais Tags ou Crie Novas", options, preselect=preselected_indices)

                    if selected_tags_indices:
                        new_tags = []

                        # Verificar se a opção de criar novo álbum foi selecionada
                        if 0 in selected_tags_indices:  # Se o índice 0 foi selecionado
                            # Obter os nomes selecionados da janela anterior para exibi-los na entrada de texto
                            selected_tags_names = [options[i] for i in selected_tags_indices if i > 0]  # Ignorar o índice 0 (Criar Novo Álbum)
                            selected_tags_names_str = ", ".join(selected_tags_names)

                            # Solicitar ao usuário que insira os novos nomes de álbuns, separados por vírgulas
                            new_tag_input = xbmcgui.Dialog().input("Digite o nome da nova Modelo (separado por vírgulas)", defaultt=selected_tags_names_str)

                            if new_tag_input:
                                # Dividir os nomes digitados pelo usuário e adicionar à lista, garantindo que não haja duplicação
                                new_tags += [model.strip() for model in new_tag_input.split(",")]

                        # Adicionar os álbuns selecionados à lista
                        selected_tags = [options[i] for i in selected_tags_indices if i > 0]  # Ignorar o índice 0 (Criar Novo Álbum)
                        new_tags += selected_tags

                        # Combinar os modelos existentes com os novos e garantir que não haja duplicatas
                        combined_tags = list(set(existing_tags + new_tags))

                        # Transformar a lista em uma string separada por vírgulas
                        new_tags_str = ", ".join(combined_tags)

                        # Atualizar a informação do álbum
                        album_info['m_tags'] = new_tags_str
                        self.save_json(albums_json_path, albums_dict)

                        # Notificar o usuário do sucesso
                        xbmcgui.Dialog().notification("Sucesso", f'Tagss "{new_tags_str}" foram selecionados ou criados com sucesso.')
                        
                        # Salvar o arquivo de timestamp e atualizar o contêiner do Kodi
                        save_timestamp(albums_db_path)
                        kodi_refresh_container()

                    else:
                        xbmcgui.Dialog().notification("Cancelado", "Nenhuma tag foi selecionado.")   

                elif selected == 6:
                    new_date = xbmcgui.Dialog().numeric(1, "Enter new release date", defaultt=album_info.get('m_date', ''))
                    if new_date:
                        album_info['m_date'] = new_date
                        kodi_notify('Issue release date updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)

                elif selected == 7:
                    new_plot = xbmcgui.Dialog().input("Enter new plot", defaultt=album_info.get('m_plot', ''))
                    if new_plot:
                        album_info['m_plot'] = new_plot
                        kodi_notify('Issue plot updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)
                
                elif selected == 8:
                    album_name = album_info['m_album']
                    kodi_notify('Album: {}'.format(album_name))
                
                elif selected == 9:
                    self.save_issue_nfo(album_info)
                    kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))
                    break
        
        elif selected_edit == 1:
            # Caminhos dos diretórios
            addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            albums_db_path = os.path.join(addon_data_path, 'albuns_db')

            album_path = album_info.get('m_path')
            
            dir_name = os.path.basename(album_path)
            dir_path = os.path.dirname(os.path.abspath(album_path))

            nfo_file = os.path.join(album_path, f'{dir_name}.nfo')

            if os.path.exists(nfo_file):
                try:
                    # Carregar o arquivo NFO e obter informações
                    tree = ET.parse(nfo_file)
                    root_element = tree.getroot()
                    album_info["m_number"] = root_element.find('m_number').text or ""
                    album_info["m_title"] = root_element.find('m_title').text or dir_name
                    album_info["m_album"] = root_element.find('m_album').text or ""
                    album_info["m_model"] = root_element.find('m_model').text or ""
                    album_info["m_others"] = root_element.find('m_others').text or ""
                    album_info["m_date"] = root_element.find('m_date').text or ""
                    album_info["m_year"] = root_element.find('m_year').text or ""
                    album_info["m_tags"] = root_element.find('m_tags').text or ""
                    album_info["m_plot"] = root_element.find('m_plot').text or ""

                    # Se o álbum de origem não for vazio
                    if album_info["m_album"]:
                        origin_file = album_info['m_album']
                        destiny_file = f"{album_info['m_album']}"

                        origin_path = os.path.join(albums_db_path, f"{origin_file}.json")
                        destiny_path = os.path.join(albums_db_path, f"{destiny_file}.json")
                        item_key = album_info["m_title"]

                        # Verificar se o arquivo de destino existe, caso contrário, criar um arquivo com informações padrão
                        if not xbmcvfs.exists(destiny_path):
                            initial_data = {
                                "m_album": destiny_file,  # Nome do arquivo JSON como nome do álbum
                                "m_tags": "",
                                "m_year": "",
                                "m_plot": "",
                                "m_path": "",
                                "s_icon": "",
                                "s_poster": "",
                                "s_clearlogo": "",
                                "s_fanart": "",
                                "s_banner": ""
                            }
                            with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                destiny_file_handle.write(json.dumps(initial_data, indent=4, ensure_ascii=False))

                        # Carregar JSON de origem
                        with xbmcvfs.File(origin_path) as origin_file_handle:
                            origin_content = origin_file_handle.read()
                            if origin_content.strip():
                                origin_data = json.loads(origin_content)
                            else:
                                origin_data = {}

                        # Carregar JSON de destino
                        with xbmcvfs.File(destiny_path) as destiny_file_handle:
                            destiny_content = destiny_file_handle.read()
                            if destiny_content.strip():
                                destiny_data = json.loads(destiny_content)
                            else:
                                destiny_data = {}

                        # Verificar se o item está no arquivo de origem e removê-lo
                        if item_key in origin_data:
                            item_data = origin_data.pop(item_key)

                            # Adicionar o item ao arquivo de destino
                            destiny_data[item_key] = item_data

                            # Salvar o arquivo de origem após remover o item
                            with xbmcvfs.File(origin_path, 'w') as origin_file_handle:
                                origin_file_handle.write(json.dumps(origin_data, indent=4, ensure_ascii=False))

                            # Salvar o arquivo de destino com o novo item
                            with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                destiny_file_handle.write(json.dumps(destiny_data, indent=4, ensure_ascii=False))

                            # Notificação de sucesso
                            xbmcgui.Dialog().notification("Success", f'O item "{item_key}" foi movido com sucesso para o álbum "{album_info["m_title"]}".')

                            # Atualiza o álbum do item
                            album_info['m_album'] = destiny_file
                            self.save_json(albums_json_path, albums_dict)

                            save_timestamp(albums_db_path)
                            kodi_refresh_container()
                        else:
                            xbmcgui.Dialog().notification("Error", f'O item "{item_key}" não foi encontrado no álbum de origem.')

                    kodi_notify('Issue title updated')

                except ET.ParseError as e:
                    kodi_notify_error(f'Error parsing NFO file: {str(e)}')
            else:
                kodi_notify("No Local Metadata for {}".format(dir_name))
        
        elif selected_edit == 2:
            while True:
                
                label2_poster = album_info['s_poster'] if album_info['s_poster'] else 'No Art'
                label2_fanart = album_info['s_fanart'] if album_info['s_fanart'] else 'No Art'
                label2_banner = album_info['s_banner'] if album_info['s_banner'] else 'No Art'
                label2_icon   = album_info['s_icon']   if album_info['s_icon']   else 'No Art'
                label2_save   = 'Save issue data to NFO'
                
                img_poster = album_info['s_poster'] if album_info['s_poster'] else 'DefaultAddonNone.png'
                img_fanart = album_info['s_fanart'] if album_info['s_fanart'] else 'DefaultAddonNone.png'
                img_banner = album_info['s_banner'] if album_info['s_banner'] else 'DefaultAddonNone.png'
                img_icon =   album_info['s_icon']   if album_info['s_icon']   else 'DefaultAddonNone.png'
                img_save = 'defaultaddonsrepo.png'
                
                poster_listitem     = xbmcgui.ListItem(label = 'Edit Poster', label2 = label2_poster)
                fanart_listitem     = xbmcgui.ListItem(label = 'Edit fanart', label2 = label2_fanart)
                banner_listitem     = xbmcgui.ListItem(label = 'Edit banner', label2 = label2_banner)
                icon_listitem       = xbmcgui.ListItem(label = 'Edit icon',   label2 = label2_icon)
                save_listitem       = xbmcgui.ListItem(label = 'Save Issue',  label2 = label2_save)

                poster_listitem.setArt({'icon' : img_poster})
                fanart_listitem.setArt({'icon' : img_fanart})
                banner_listitem.setArt({'icon' : img_banner})
                icon_listitem.setArt({'icon' : img_icon})
                save_listitem.setArt({'icon' : img_save})
                
                destination_path =  album_info['m_path']
            
                sDialog = KodiSelectDialog('Edit Issue Artwork', useDetails = True)
                sDialog.setRows([
                    poster_listitem,
                    fanart_listitem,
                    banner_listitem,
                    icon_listitem,
                    save_listitem
                ])
                selected_art_edit = sDialog.executeDialog()
                if selected_art_edit is None: return
                
                if selected_art_edit == 0:
                    new_poster = kodi_dialog_get_image('Select issue Poster', '.jpg', destination_path)
                    if new_poster:
                        album_info['s_poster'] = os.path.join(destination_path, 'folder.jpg')
                        self.save_artwork(new_poster, 's_poster', album_info, albums_json_path, albums_dict, 'Issue Poster updated')

                elif selected_art_edit == 1:
                    new_fanart = kodi_dialog_get_image('Select issue Fanart', '.jpg', destination_path)
                    if new_fanart:
                        album_info['s_fanart'] = os.path.join(destination_path, 'fanart.jpg')
                        self.save_artwork(new_fanart, 's_fanart', album_info, albums_json_path, albums_dict, 'Issue Fanart updated')
                        
                        utils_update_file_mtime(new_fanart)
                        
                elif selected_art_edit == 2:
                    new_banner = kodi_dialog_get_image('Select issue Banner', '.jpg', destination_path)
                    if new_banner:
                        album_info['s_banner'] = os.path.join(destination_path, 'banner.jpg')
                        self.save_artwork(new_banner, 's_banner', album_info, albums_json_path, albums_dict, 'Issue Banner updated')

                elif selected_art_edit == 3:
                    new_icon = kodi_dialog_get_image('Select issue Icon', '.jpg', destination_path)
                    if new_icon:
                        album_info['s_icon'] = os.path.join(destination_path, 'icon.jpg')
                        self.save_artwork(new_icon, 's_icon', album_info, albums_json_path, albums_dict, 'Issue Icon updated')
                
                elif selected_art_edit == 4:
                    self.save_issue_nfo(album_info)
                    kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))
                    break
        
        elif selected_edit == 3:
            valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']
            
            set_path = album_info.get('m_path', "")
            # kodi_dialog_OK("{}".format(album_path))
            
            # Percorra os arquivos de arte válidos e verifique se estão presentes no caminho
            for file_name in valid_art_files:
                art_path = os.path.join(set_path, file_name)
                
                # Verifica se o arquivo de arte existe
                if os.path.exists(art_path):
                    # Atualiza o JSON com o caminho da arte correspondente
                    if file_name == 'banner.jpg':
                        album_info['s_banner'] = art_path
                    elif file_name == 'fanart.jpg':
                        album_info['s_fanart'] = art_path
                    elif file_name == 'folder.jpg':
                        album_info['s_poster'] = art_path
                    elif file_name == 'icon.jpg':
                        album_info['s_icon'] = art_path
                    elif file_name == 'clearlogo.png':
                        album_info['s_clearlogo'] = art_path
            
            
            self.save_json(albums_json_path, albums_dict)
            save_timestamp(albums_db_path)
            
            kodi_notify("Artwork from isssue {} loaded!".format(album_info.get('m_title')))
                
        elif selected_edit == 4:
            self.save_issue_nfo(album_info)
            kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))

    def save_album_nfo(self, album_info):

        # Crie o elemento root
        album = ET.Element('album')
        
        # Adicione subelementos ao root
        ET.SubElement(album, 'm_album').text = album_info.get('m_album', '')
        ET.SubElement(album, 'm_tags').text = album_info.get('m_tags', '')
        ET.SubElement(album, 'm_year').text = album_info.get('m_year', '')
        ET.SubElement(album, 'm_plot').text = album_info.get('m_plot', '')
        ET.SubElement(album, 'm_path').text = album_info.get('m_path', '')
        ET.SubElement(album, 's_icon').text = album_info.get('s_icon', '')
        ET.SubElement(album, 's_poster').text = album_info.get('s_poster', '')
        ET.SubElement(album, 's_clearlogo').text = album_info.get('s_clearlogo', '')
        ET.SubElement(album, 's_fanart').text = album_info.get('s_fanart', '')
        ET.SubElement(album, 's_banner').text = album_info.get('s_banner', '')
        
        # Obtenha o caminho da pasta e o nome da pasta
        m_path = album_info.get('m_path', '')
        
        if not m_path:
            m_path = kodi_dialog_get_directory('Select where to store Album NFO')
            if not m_path:
                kodi_notify('Album NFO not saved')
                return
                
        folder_name = os.path.basename(os.path.normpath(m_path))
        nfo_path = os.path.join(m_path, f"{folder_name}.nfo")

        # Crie a árvore XML
        tree = ET.ElementTree(album)
        
        # Converta para string com minidom para formatação bonita
        xml_str = ET.tostring(album, encoding='utf-8')
        pretty_xml_str = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Salve o arquivo XML
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_str)
            
        kodi_notify('Album data sucessfully saved!')

    def save_issue_nfo(self, album_info):

        # Crie o elemento root
        issue = ET.Element('issue')
        
        # Adicione subelementos ao root
        ET.SubElement(issue, 'm_number').text = album_info.get('m_number', '')
        ET.SubElement(issue, 'm_title').text = album_info.get('m_title', '')
        ET.SubElement(issue, 'm_model').text = album_info.get('m_model', '')
        ET.SubElement(issue, 'm_others').text = album_info.get('m_others', '')
        ET.SubElement(issue, 'm_album').text = album_info.get('m_album', '')
        ET.SubElement(issue, 'm_tags').text = album_info.get('m_tags', '')
        ET.SubElement(issue, 'm_date').text = album_info.get('m_date', '')
        ET.SubElement(issue, 'm_year').text = album_info.get('m_year', '')
        ET.SubElement(issue, 'm_plot').text = album_info.get('m_plot', '')

        # Obtenha o caminho da pasta e o nome da pasta
        m_path = album_info.get('m_path', '')
        if not m_path:
            raise ValueError("O campo 'm_path' não pode estar vazio.")
        
        folder_name = os.path.basename(os.path.normpath(m_path))
        nfo_path = os.path.join(m_path, f"{folder_name}.nfo")
            
        # Crie a árvore XML
        tree = ET.ElementTree(issue)
        
        # Converta para string com minidom para formatação bonita
        xml_str = ET.tostring(issue, encoding='utf-8')
        pretty_xml_str = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Salve o arquivo XML
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_str)

    def save_artwork(self, image_path, album_info_key, album_info, albums_json_path, albums_dict, notification_message):
        """
        Apenas salva o caminho da arte no JSON, sem copiar o arquivo.
        """
        if not image_path:
            kodi_notify('Nenhuma imagem selecionada')
            return

        # Atualiza o dicionário com o novo caminho
        album_info[album_info_key] = image_path

        # Notifica e salva no JSON
        kodi_notify(notification_message)
        self.save_json(albums_json_path, albums_dict)
        
    def save_json(self, albums_json_path, albums_dict):
        # Salvar as alterações de volta ao JSON
        try:
            with open(albums_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(albums_dict, json_file, ensure_ascii=False, indent=4)
                kodi_refresh_container()
        except Exception as e:
            xbmcgui.Dialog().notification('Edit Issue', f'Error saving changes: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 5000)
        
    def scan_albums(self, scan_path):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        
        # Criar diretório 'albuns_db' se não existir
        if not xbmcvfs.exists(albums_db_path):
            xbmcvfs.mkdirs(albums_db_path)

        albums_dict = {}

        # Inicializa a barra de progresso para o scan de novos álbuns
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create('Starting Search', 'Collecting data from:\n{}'.format(scan_path))

        total_dirs = sum([len(dirs) for _, dirs, _ in os.walk(scan_path)])
        added_count = 0
        except_scan = False
        valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']

        for root, dirs, files in os.walk(scan_path):
            for dir_name in dirs:
                progress_dialog.create('Scanning Albums', 'Scanning for .issue files:\n{}'.format(dir_name))
                issue_file = os.path.join(root, dir_name, f'{dir_name}.issue')
                nfo_set_file = os.path.join(root, dir_name, f'{dir_name}.nfo')

                if os.path.exists(issue_file) and dir_name:
                    album_data = {
                        "m_number": "",
                        "m_title": dir_name,
                        "m_model": "",
                        "m_others": "",
                        "m_album": "",
                        "m_tags": "",
                        "m_date": "",
                        "m_year": "",
                        "m_plot": "",
                        "m_path": os.path.join(root, dir_name),
                        "s_icon": "",
                        "s_poster": "",
                        "s_fanart": "",
                        "s_banner": ""
                    }

                    # Agora, procuramos as artes na pasta de cada set (dir_name)
                    set_path = os.path.join(root, dir_name)
                    
                    for file_name in os.listdir(set_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:
                            art_path = os.path.join(set_path, file_name)
                            if file_name == 'banner.jpg':
                                album_data['s_banner'] = art_path

                            if file_name == 'fanart.jpg':
                                album_data['s_fanart'] = art_path
 
                            if file_name == 'folder.jpg':
                                album_data['s_poster'] = art_path
  
                            if file_name == 'icon.jpg':
                                album_data['s_icon'] = art_path
 
                            if file_name == 'clearlogo.png':
                                album_data['s_clearlogo'] = art_path

                    if os.path.exists(nfo_set_file):
                    
                        # xbmc.log(f'nfo_set_file: {str(nfo_set_file)}', xbmc.LOGERROR)  
                        try:
                            tree = ET.parse(nfo_set_file)
                            root_element = tree.getroot()
                            album_data["m_number"] = root_element.find('m_number').text or ""
                            album_data["m_title"] = root_element.find('m_title').text or dir_name
                            album_data["m_album"] = root_element.find('m_album').text or ""
                            album_data["m_model"] = root_element.find('m_model').text or ""
                            album_data["m_others"] = root_element.find('m_others').text or ""
                            album_data["m_date"] = root_element.find('m_date').text or ""
                            album_data["m_year"] = root_element.find('m_year').text or ""
                            album_data["m_tags"] = root_element.find('m_tags').text or ""
                            album_data["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break

                    album_key = album_data["m_album"] if album_data["m_album"] else "[Not Set]"
                    nfo_album_file = os.path.join(root, f'{album_key}.nfo')
                    
                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Verifique se o álbum já existe no dicionário, se não, crie a entrada
                    if album_key not in albums_dict:
                        albums_dict[album_key] = {
                            "m_album": album_key,
                            "m_tags": "",
                            "m_year": "",
                            "m_plot": "",
                            "m_path": album_path,
                            "s_icon": "",
                            "s_poster": "",
                            "s_clearlogo": "",
                            "s_fanart": "",
                            "s_banner": ""
                        }

                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Atribuir as artes do cabeçalho diretamente ao álbum principal (não aos sets)
                    for file_name in os.listdir(album_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:  # Verificar se o arquivo é uma arte válida
                            art_path = os.path.join(album_path, file_name)
                            
                            if album_key != "[Not Set]":
                                if 's_banner' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_banner'] = ""
                                if 's_fanart' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_fanart'] = ""
                                if 's_poster' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_poster'] = ""
                                if 's_icon' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_icon'] = ""
                                if 's_clearlogo' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_clearlogo'] = ""

                                # Atribui as artes ao álbum principal se não for "[Not Set]"
                                if file_name == 'banner.jpg':
                                    albums_dict[album_key]['s_banner'] = art_path
                                if file_name == 'fanart.jpg':
                                    albums_dict[album_key]['s_fanart'] = art_path
                                if file_name == 'folder.jpg':
                                    albums_dict[album_key]['s_poster'] = art_path
                                if file_name == 'icon.jpg':
                                    albums_dict[album_key]['s_icon'] = art_path
                                if file_name == 'clearlogo.png':
                                    albums_dict[album_key]['s_clearlogo'] = art_path
                    
                    if os.path.exists(nfo_album_file):
                        try:
                            tree = ET.parse(nfo_album_file)
                            root_element = tree.getroot()
                            albums_dict[album_key]["m_album"] = root_element.find('m_album').text or ""
                            albums_dict[album_key]["m_tags"] = root_element.find('m_tags').text or ""
                            albums_dict[album_key]["m_year"] = root_element.find('m_year').text or ""
                            albums_dict[album_key]["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break
                    
                    # Adicionar ao dicionário principal
                    # albums_dict[album_key][f"{album_data['m_title']}"] = album_data
                    albums_dict[album_key][f"{dir_name}"] = album_data
                    added_count += 1

                    progress = int((added_count / total_dirs) * 100)
                    progress_dialog.update(progress)

                    if progress_dialog.iscanceled():
                        break

        progress_dialog.close()

        # Excluir todos os arquivos JSON no caminho albums_db_path
        for filename in os.listdir(albums_db_path):
            file_path = os.path.join(albums_db_path, filename)
            if filename.endswith('.json'):
                try:
                    os.remove(file_path)
                except Exception as e:
                    xbmc.log(f'Erro ao tentar excluir o arquivo {file_path}: {str(e)}', xbmc.LOGERROR)

        # Salvar cada conjunto de álbuns em arquivos JSON separados
        for album_key, album_content in albums_dict.items():
            album_json_path = os.path.join(albums_db_path, f'{album_key}.json')
            try:
                with open(album_json_path, 'w', encoding='utf-8') as json_file:
                    json.dump(album_content, json_file, ensure_ascii=False, indent=4)
            except Exception as e:
                kodi_notify_error(f'Error saving {album_key}.json: {str(e)}')
                return

        kodi_refresh_container()

        if added_count > 0:
            kodi_notify(f'{added_count} issue(s) localized')
            self.scan_lolitas()

        if except_scan == False:
            kodi_notify('Scan completed')
        else: 
            kodi_notify_warn('Scan completed with errors')

        # Obter o timestamp Unix atual
        timestamp_unix = int(datetime.datetime.now().timestamp())

        # Criar o dicionário com o timestamp Unix
        timestamp_data = {
            "last_scan": timestamp_unix
        }

        timestamp_json_path = os.path.join(albums_db_path, '_scan_timestamp.json')
        
        try:
            with open(timestamp_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(timestamp_data, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            kodi_notify_error(f'Error saving timestamp JSON: {str(e)}')
            
        kodi_refresh_container()
    
    def update_album(self, scan_path, album_path):
        
        full_path = f'{scan_path}{album_path}'

        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        
        # Criar diretório 'albuns_db' se não existir
        if not xbmcvfs.exists(albums_db_path):
            xbmcvfs.mkdirs(albums_db_path)

        albums_dict = {}

        # Inicializa a barra de progresso para o scan de novos álbuns
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create('Starting Search', 'Collecting data from:\n{}'.format(full_path))

        total_dirs = sum([len(dirs) for _, dirs, _ in os.walk(full_path)])
        added_count = 0
        except_scan = False
        valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']

        for root, dirs, files in os.walk(full_path):
            for dir_name in dirs:
                progress_dialog.create('Scanning Albums', 'Scanning for .issue files:\n{}'.format(dir_name))
                issue_file = os.path.join(root, dir_name, f'{dir_name}.issue')
                nfo_set_file = os.path.join(root, dir_name, f'{dir_name}.nfo')

                if os.path.exists(issue_file) and dir_name:
                    album_data = {
                        "m_number": "",
                        "m_title": dir_name,
                        "m_model": "",
                        "m_others": "",
                        "m_album": "",
                        "m_tags": "",
                        "m_date": "",
                        "m_year": "",
                        "m_plot": "",
                        "m_path": os.path.join(root, dir_name),
                        "s_icon": "",
                        "s_poster": "",
                        "s_fanart": "",
                        "s_banner": ""
                    }

                    # Agora, procuramos as artes na pasta de cada set (dir_name)
                    set_path = os.path.join(root, dir_name)
                    
                    for file_name in os.listdir(set_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:
                            art_path = os.path.join(set_path, file_name)
                            if file_name == 'banner.jpg':
                                album_data['s_banner'] = art_path

                            if file_name == 'fanart.jpg':
                                album_data['s_fanart'] = art_path
 
                            if file_name == 'folder.jpg':
                                album_data['s_poster'] = art_path
  
                            if file_name == 'icon.jpg':
                                album_data['s_icon'] = art_path
 
                            if file_name == 'clearlogo.png':
                                album_data['s_clearlogo'] = art_path

                    if os.path.exists(nfo_set_file):
                    
                        # xbmc.log(f'nfo_set_file: {str(nfo_set_file)}', xbmc.LOGERROR)  
                        try:
                            tree = ET.parse(nfo_set_file)
                            root_element = tree.getroot()
                            album_data["m_number"] = root_element.find('m_number').text or ""
                            album_data["m_title"] = root_element.find('m_title').text or dir_name
                            album_data["m_album"] = root_element.find('m_album').text or ""
                            album_data["m_model"] = root_element.find('m_model').text or ""
                            album_data["m_others"] = root_element.find('m_others').text or ""
                            album_data["m_date"] = root_element.find('m_date').text or ""
                            album_data["m_year"] = root_element.find('m_year').text or ""
                            album_data["m_tags"] = root_element.find('m_tags').text or ""
                            album_data["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break

                    album_key = album_data["m_album"] if album_data["m_album"] else "[Not Set]"
                    nfo_album_file = os.path.join(root, f'{album_key}.nfo')
                    
                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Verifique se o álbum já existe no dicionário, se não, crie a entrada
                    if album_key not in albums_dict:
                        albums_dict[album_key] = {
                            "m_album": album_key,
                            "m_tags": "",
                            "m_year": "",
                            "m_plot": "",
                            "m_path": album_path,
                            "s_icon": "",
                            "s_poster": "",
                            "s_clearlogo": "",
                            "s_fanart": "",
                            "s_banner": ""
                        }

                    # Agora, procuramos as artes na pasta de cada álbum (root)
                    album_path = os.path.join(root)

                    # Atribuir as artes do cabeçalho diretamente ao álbum principal (não aos sets)
                    for file_name in os.listdir(album_path):  # Iterar sobre os arquivos na pasta do álbum
                        if file_name.lower() in valid_art_files:  # Verificar se o arquivo é uma arte válida
                            art_path = os.path.join(album_path, file_name)
                            
                            if album_key != "[Not Set]":
                                if 's_banner' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_banner'] = ""
                                if 's_fanart' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_fanart'] = ""
                                if 's_poster' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_poster'] = ""
                                if 's_icon' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_icon'] = ""
                                if 's_clearlogo' not in albums_dict[album_key]:
                                    albums_dict[album_key]['s_clearlogo'] = ""

                                # Atribui as artes ao álbum principal se não for "[Not Set]"
                                if file_name == 'banner.jpg':
                                    albums_dict[album_key]['s_banner'] = art_path
                                if file_name == 'fanart.jpg':
                                    albums_dict[album_key]['s_fanart'] = art_path
                                if file_name == 'folder.jpg':
                                    albums_dict[album_key]['s_poster'] = art_path
                                if file_name == 'icon.jpg':
                                    albums_dict[album_key]['s_icon'] = art_path
                                if file_name == 'clearlogo.png':
                                    albums_dict[album_key]['s_clearlogo'] = art_path
                    
                    if os.path.exists(nfo_album_file):
                        try:
                            tree = ET.parse(nfo_album_file)
                            root_element = tree.getroot()
                            albums_dict[album_key]["m_album"] = root_element.find('m_album').text or ""
                            albums_dict[album_key]["m_tags"] = root_element.find('m_tags').text or ""
                            albums_dict[album_key]["m_year"] = root_element.find('m_year').text or ""
                            albums_dict[album_key]["m_plot"] = root_element.find('m_plot').text or ""
                        except ET.ParseError as e:
                            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
                            except_scan = True
                            break
                    
                    # Adicionar ao dicionário principal
                    # albums_dict[album_key][f"{album_data['m_title']}"] = album_data
                    albums_dict[album_key][f"{dir_name}"] = album_data
                    added_count += 1

                    progress = int((added_count / total_dirs) * 100)
                    progress_dialog.update(progress)

                    if progress_dialog.iscanceled():
                        break

        progress_dialog.close()

        # Excluir todos os arquivos JSON no caminho albums_db_path
        for filename in os.listdir(albums_db_path):
            file_path = os.path.join(albums_db_path, filename)
            if filename.endswith(f'{album_path}.json'):
                try:
                    os.remove(file_path)
                except Exception as e:
                    xbmc.log(f'Erro ao tentar excluir o arquivo {file_path}: {str(e)}', xbmc.LOGERROR)

        # Salvar cada conjunto de álbuns em arquivos JSON separados
        for album_key, album_content in albums_dict.items():
            album_json_path = os.path.join(albums_db_path, f'{album_key}.json')
            try:
                with open(album_json_path, 'w', encoding='utf-8') as json_file:
                    json.dump(album_content, json_file, ensure_ascii=False, indent=4)
            except Exception as e:
                kodi_notify_error(f'Error saving {album_key}.json: {str(e)}')
                return

        kodi_refresh_container()

        if added_count > 0:
            kodi_notify(f'{added_count} issue(s) localized')
            # self.scan_lolitas()

        if except_scan == False:
            kodi_notify('Scan completed')
        else: 
            kodi_notify_warn('Scan completed with errors')

        # Obter o timestamp Unix atual
        timestamp_unix = int(datetime.datetime.now().timestamp())

        # Criar o dicionário com o timestamp Unix
        timestamp_data = {
            "last_scan": timestamp_unix
        }

        timestamp_json_path = os.path.join(albums_db_path, '_scan_timestamp.json')
    
    def get_album_data(self, album_key, scan_path, album_dict):
        for root, dirs, files in os.walk(scan_path):
            for file in files:
                if file == f"{album_key}.nfo":
                    nfo_file = os.path.join(root, file)

                    tree = ET.parse(nfo_file)
                    root_element = tree.getroot()
                    
                    
                    album_dict["m_album"] = root_element.find('m_album').text or ""
                    album_dict["m_tags"] = root_element.find('m_tags').text or ""
                    album_dict["m_year"] = root_element.find('m_year').text or ""
                    album_dict["m_plot"] = root_element.find('m_plot').text or ""
                    album_dict["m_path"] = root or ""
                    album_dict["s_icon"] = root_element.find('s_icon').text or ""
                    album_dict["s_poster"] = root_element.find('s_poster').text or ""
                    album_dict["s_clearlogo"] = root_element.find('s_clearlogo').text or ""
                    album_dict["s_fanart"] = root_element.find('s_fanart').text or ""
                    album_dict["s_banner"] = root_element.find('s_banner').text or ""
                    
                    return album_dict
        
        return album_dict
        
    def scan_lolitas(self):
        addon = xbmcaddon.Addon()
        lolitas_arts = addon.getSetting('lolitas_arts_dir')
        fanarts_arts = addon.getSetting('fanarts_arts_dir')
    
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')
        
        # Dicionário para armazenar os dados organizados por modelo
        lolitas_data = {}
        unique_lolitas = set()
        
        # Inicializa a barra de progresso para o scan de novas modelos
        progress_dialog = xbmcgui.DialogProgress()
        
        # Percorrer todos os arquivos JSON no diretório
        json_files = [filename for filename in os.listdir(albums_db_path) if filename.endswith('.json')]

        # Primeira passagem para contar os modelos únicos
        for json_file in json_files:
            json_path = os.path.join(albums_db_path, json_file)
            
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Verificar se o JSON contém itens de álbum
            album_items = {key: value for key, value in data.items() if isinstance(value, dict)}
            
            # Adicionar cada modelo ao conjunto unique_lolitas
            for item_key, item_info in album_items.items():
                m_model = item_info.get("m_model", "").strip()
                m_others = item_info.get("m_others", "").strip()
                if m_model == "":
                    m_model = "[Not Set]"
                unique_lolitas.add(m_model)

                if m_others:
                    others_list = [model.strip() for model in m_others.split(",")]
                    for other_model in others_list:
                        unique_lolitas.add(other_model)

        # Número total de modelos
        total_lolitas = len(unique_lolitas)
        model_count = 0
        
        # Segunda passagem para atualizar lolitas_data e mostrar progresso
        for json_file in json_files:
            json_path = os.path.join(albums_db_path, json_file)
            
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Verificar se o JSON contém itens de álbum
            album_items = {key: value for key, value in data.items() if isinstance(value, dict)}
            
            # Adicionar cada item ao dicionário lolitas_data
            for item_key, item_info in album_items.items():
                m_model = item_info.get("m_model", "").strip()
                m_others = item_info.get("m_others", "").strip()
                if m_model == "":
                    m_model = "[Not Set]"
                
                if m_others == "":
                    if m_model not in lolitas_data:
                        lolitas_data[m_model] = {}
                    lolitas_data[m_model][item_key] = item_info
                
                else:
                    others_list = [model.strip() for model in m_others.split(",")]
                    for other_model in others_list:
                        if other_model not in lolitas_data:
                            lolitas_data[other_model] = {}
                        lolitas_data[other_model][item_key] = item_info
                
                model_count = len(lolitas_data)
                
                # Mostrar progresso
                progress_dialog.create('Scanning Albums', 'Updating Lolitas DB:\n{}/{}: {}'.format(model_count, total_lolitas, m_model))
                progress = int((model_count / total_lolitas) * 100)
                progress_dialog.update(progress)
                
                # time.sleep(0.05)
            
                if progress_dialog.iscanceled():
                    break
        
        progress_dialog.close()
        
        # Excluir todos os arquivos JSON no caminho lolitas_db_path
        for filename in os.listdir(lolitas_db_path):
            file_path = os.path.join(lolitas_db_path, filename)
            if filename.endswith('.json'):
                try:
                    os.remove(file_path)
                except Exception as e:
                    xbmc.log(f'Erro ao tentar excluir o arquivo {file_path}: {str(e)}', xbmc.LOGERROR)
        
        # Criar arquivos JSON para cada modelo
        for model, items in lolitas_data.items():
            model_json_path = os.path.join(lolitas_db_path, f"{model}.json")
            model_poster_dir = os.path.join(lolitas_arts, f"{model}.jpg")
            fanarts_dir = os.path.join(fanarts_arts, f"{model}.jpg")
            
            if os.path.exists(model_poster_dir):
                s_poster = model_poster_dir
            else:
                s_poster = ""
                
            if os.path.exists(fanarts_dir):
                s_fanart = fanarts_dir
            else:
                s_fanart = ""
            
            # Adicionar metadados do modelo se necessário
            model_data = {
                "m_model": model,
                "m_type": "",
                "s_icon": "",
                "s_poster": s_poster,
                "s_fanart": s_fanart,
                "s_banner": "",
            }
            model_data.update(items)

            with open(model_json_path, 'w', encoding='utf-8') as f:
                json.dump(model_data, f, ensure_ascii=False, indent=4)
                
        # Obter o timestamp Unix atual
        timestamp_unix = int(datetime.datetime.now().timestamp())

        # Criar o dicionário com o timestamp Unix
        timestamp_data = {
            "last_scan": timestamp_unix
        }

        timestamp_json_path = os.path.join(lolitas_db_path, '_scan_timestamp.json')

        try:
            with open(timestamp_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(timestamp_data, json_file, ensure_ascii=False, indent=4)
        except Exception as e:
            kodi_notify_error(f'Error saving timestamp JSON: {str(e)}')
        
    