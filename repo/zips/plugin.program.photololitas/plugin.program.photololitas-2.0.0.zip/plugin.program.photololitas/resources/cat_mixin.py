# -*- coding: utf-8 -*-
# Tudo de categorias (CRUD, atribuição e exibição por categoria)

import os
import json
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# --- Utilitários do addon ---
from .utils import *

# Constantes específicas do módulo de categorias
CATEGORIES_DIRNAME = 'categories_db'
CATEGORIES_FILENAME = 'categories.json'

class CatMixin:
    def _loc(self, string_id, fallback=''):
        return kodi_localize(string_id, fallback)
    # =========================
    # ===== CATEGORIAS (META/ART) =====
    # =========================

    THEME_PATH = 'special://home/addons/plugin.program.photololitas/media/theme/'
    FALLBACK_ICON      = f'{THEME_PATH}Albuns_icon.png'
    FALLBACK_POSTER    = f'{THEME_PATH}Albuns_poster.png'
    FALLBACK_CLEARLOGO = f'{THEME_PATH}Albuns_clearlogo.png'
    FALLBACK_FANART    = f'{THEME_PATH}fanart.jpg'
    FALLBACK_BANNER    = ''  # opcional

    def _categories_root(self):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        return os.path.join(addon_data_path, CATEGORIES_DIRNAME)

    def _categories_path(self):
        return os.path.join(self._categories_root(), CATEGORIES_FILENAME)

    def _category_info_path(self, category_name: str):
        # um arquivo por categoria com seus metadados/arte
        safe = category_name.replace('/', '_')
        return os.path.join(self._categories_root(), f'{safe}.json')

    def _default_category_payload(self, category_name: str):
        return {
            "m_category": category_name,
            "m_plot": "",
            "s_icon": "",
            "s_poster": "",
            "s_clearlogo": "",
            "s_fanart": "",
            "s_banner": ""
        }

    def load_categories(self):
        path = self._categories_path()
        try:
            with xbmcvfs.File(path) as f:
                raw = f.read()
                return json.loads(raw) if raw else {}
        except Exception:
            return {}

    def save_categories(self, data):
        path = self._categories_path()
        with xbmcvfs.File(path, 'w') as f:
            f.write(json.dumps(data, ensure_ascii=False, indent=4))

    def _ensure_category_info_exists(self, name):
        info_path = self._category_info_path(name)
        if not xbmcvfs.exists(info_path):
            with xbmcvfs.File(info_path, 'w') as f:
                f.write(json.dumps(self._default_category_payload(name), ensure_ascii=False, indent=4))

    def _load_category_info(self, name):
        self._ensure_category_info_exists(name)
        with xbmcvfs.File(self._category_info_path(name)) as f:
            raw = f.read()
            return json.loads(raw) if raw else self._default_category_payload(name)

    def _save_category_info(self, name, payload: dict):
        with xbmcvfs.File(self._category_info_path(name), 'w') as f:
            f.write(json.dumps(payload, ensure_ascii=False, indent=4))

    def _browse_art(self, title, start_dir):
        # file = 1, máscara deixo livre pra não limitar
        return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, start_dir)
        
    # =========================
    # ===== CRUD CATEGORIES ===
    # =========================

    def create_category_dialog(self):
        name = xbmcgui.Dialog().input("Nome da nova categoria", type=xbmcgui.INPUT_ALPHANUM)
        if not name:
            return
        cats = self.load_categories()
        if name in cats:
            kodi_notify_warn("Já existe uma categoria com esse nome.")
            return
        cats[name] = []
        self.save_categories(cats)
        # cria JSON da categoria com payload default
        self._ensure_category_info_exists(name)
        kodi_notify("Categoria criada.")
        kodi_refresh_container()

    def rename_category_dialog(self, old_name):
        new_name = xbmcgui.Dialog().input("Novo nome da categoria", defaultt=old_name, type=xbmcgui.INPUT_ALPHANUM)
        if not new_name or new_name == old_name:
            return
        cats = self.load_categories()
        if new_name in cats:
            kodi_notify_warn("Já existe uma categoria com esse nome.")
            return
        cats[new_name] = cats.pop(old_name, [])
        self.save_categories(cats)
        # renomear JSON de metadados
        old_json = self._category_info_path(old_name)
        new_json = self._category_info_path(new_name)
        try:
            if xbmcvfs.exists(old_json):
                xbmcvfs.rename(old_json, new_json)
        except Exception as e:
            xbmc.log(f'[categories] erro ao renomear json: {e}')
            # se falhar, salva payload com novo nome
            payload = self._load_category_info(old_name) if xbmcvfs.exists(old_json) else self._default_category_payload(new_name)
            payload['m_category'] = new_name
            self._save_category_info(new_name, payload)
            if xbmcvfs.exists(old_json):
                try: xbmcvfs.delete(old_json)
                except: pass
        kodi_notify("Categoria renomeada.")
        kodi_refresh_container()

    def delete_category_dialog(self, name):
        if not xbmcgui.Dialog().yesno(self._loc(30028, "Delete category"), self._loc(30029, 'Are you sure you want to delete "{name}"?\n(Albums remain intact)').format(name=name)):
            return
        cats = self.load_categories()
        if name in cats:
            cats.pop(name)
            self.save_categories(cats)
        # remove o JSON da categoria
        info_path = self._category_info_path(name)
        if xbmcvfs.exists(info_path):
            try: xbmcvfs.delete(info_path)
            except: pass
        kodi_notify(self._loc(30030, "Category deleted."))
        kodi_refresh_container()

    def manage_categories_dialog(self):
        cats = self.load_categories()
        options = [self._loc(30031, "<Create category>"), self._loc(30032, "<Rename category>"), self._loc(30033, "<Delete category>")]
        sel = xbmcgui.Dialog().select(self._loc(30034, "Manage categories"), options)
        if sel == 0:
            self.create_category_dialog()
        elif sel == 1:
            if not cats:
                kodi_notify_warn(self._loc(30035, "No category to rename."))
                return
            cat = self._pick_category(self._loc(30036, "Rename which category?"))
            if cat:
                self.rename_category_dialog(cat)
        elif sel == 2:
            if not cats:
                kodi_notify_warn(self._loc(30037, "No category to delete."))
                return
            cat = self._pick_category(self._loc(30038, "Delete which category?"))
            if cat:
                self.delete_category_dialog(cat)

    def _pick_category(self, title=None):
        if title is None:
            title = self._loc(30039, "Select category")
        cats = sorted(self.load_categories().keys(), key=str.lower)
        if not cats:
            return None
        idx = xbmcgui.Dialog().select(title, cats)
        return cats[idx] if idx >= 0 else None

    def assign_album_to_category_dialog(self, album_name):
        if not album_name:
            kodi_notify_warn(self._loc(30040, "Invalid album."))
            return
        cats = self.load_categories()
        if not cats:
            if xbmcgui.Dialog().yesno(self._loc(30041, "Categories"), self._loc(30042, "There are no categories yet. Create one now?")):
                self.create_category_dialog()
                cats = self.load_categories()
            else:
                return
        # escolher categoria
        cat = self._pick_category(self._loc(30043, "Add to which category?"))
        if not cat:
            return
        self.assign_album_to_category(cat, album_name)

    def assign_album_to_category(self, category, album_name):
        cats = self.load_categories()
        albums = set(cats.get(category, []))
        if album_name not in albums:
            albums.add(album_name)
            cats[category] = sorted(albums, key=str.lower)
            self.save_categories(cats)
            kodi_notify(self._loc(30044, "Album added to category."))
            kodi_refresh_container()
        else:
            kodi_notify_warn(self._loc(30045, "Album is already in this category."))

    def unassign_album_from_category(self, category, album_name):
        cats = self.load_categories()
        if category in cats and album_name in cats[category]:
            cats[category] = [a for a in cats[category] if a != album_name]
            self.save_categories(cats)
            kodi_notify(self._loc(30046, "Album removed from category."))
            kodi_refresh_container()

    def edit_category_dialog(self, category_name):
        if not category_name:
            kodi_notify('Invalid category name!')
            return

        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        category_json_path = os.path.join(addon_data_path, f'categories_db/{category_name}.json')

        if not xbmcvfs.exists(category_json_path):
            kodi_notify('Category JSON not found')
            return

        with open(category_json_path, 'r', encoding='utf-8') as json_file:
            category_info = json.load(json_file)

        edit_category_data = True
        data_change = False

        while edit_category_data:
            edit_options = [
                "Edit Category Metadata",
                "Edit Category Artwork",
            ]

            selected_edit = xbmcgui.Dialog().select(f"Edit Category — {category_name}", edit_options)
            if selected_edit == -1:
                break

            # --- METADATA ---
            if selected_edit == 0:
                while True:
                    options = [
                        f"Edit Category Title: {category_info.get('m_category', '')}",
                        f"Edit Description (plot): {category_info.get('m_plot', '')[:40] + ('…' if len(category_info.get('m_plot', '')) > 40 else '')}",
                        "Save Category"
                    ]
                    selected = xbmcgui.Dialog().select("Edit Category Metadata", options)
                    if selected == -1 or selected == 2:
                        break

                    if selected == 0:
                        new_title = xbmcgui.Dialog().input("Enter new category title", defaultt=category_info.get('m_category', ''))
                        if new_title:
                            category_info['m_category'] = new_title
                            data_change = True
                            kodi_notify('Category title updated')
                            self._save_category_info(category_name, category_info)

                    elif selected == 1:
                        new_plot = xbmcgui.Dialog().input("Enter new description (plot)", defaultt=category_info.get('m_plot', ''))
                        category_info['m_plot'] = new_plot or ''
                        data_change = True
                        kodi_notify('Category description updated')
                        self._save_category_info(category_name, category_info)

            # --- ARTWORK ---
            elif selected_edit == 1:
                # Lê a pasta padrão do scanner nas configurações
                try:
                    addon = xbmcaddon.Addon()
                    scan_path_setting = addon.getSetting('scan_path') or ''
                    scan_path = xbmcvfs.translatePath(scan_path_setting) if scan_path_setting else ''
                except Exception:
                    scan_path = ''

                def _compute_initial_dir(current_path):
                    """
                    1) Se já existe caminho salvo e o arquivo existe, abre a pasta dele
                    2) Senão, usa scan_path (se configurado e existir)
                    3) Senão, diretório do JSON da categoria
                    """
                    if current_path and (xbmcvfs.exists(current_path) or str(current_path).lower().startswith(('http://', 'https://'))):
                        return os.path.dirname(current_path) if '://' not in current_path else scan_path or os.path.dirname(category_json_path)
                    if scan_path and xbmcvfs.exists(scan_path):
                        return scan_path
                    return os.path.dirname(category_json_path)

                while True:
                    # Labels/Imagens com .get() para evitar KeyError
                    label_icon      = category_info.get('s_icon')      or 'No Art'
                    label_poster    = category_info.get('s_poster')    or 'No Art'
                    label_clearlogo = category_info.get('s_clearlogo') or 'No Art'
                    label_fanart    = category_info.get('s_fanart')    or 'No Art'
                    label_banner    = category_info.get('s_banner')    or 'No Art'

                    img_icon      = category_info.get('s_icon')      or 'DefaultAddonNone.png'
                    img_poster    = category_info.get('s_poster')    or 'DefaultAddonNone.png'
                    img_clearlogo = category_info.get('s_clearlogo') or 'DefaultAddonNone.png'
                    img_fanart    = category_info.get('s_fanart')    or 'DefaultAddonNone.png'
                    img_banner    = category_info.get('s_banner')    or 'DefaultAddonNone.png'

                    icon_item      = xbmcgui.ListItem(label='Edit Icon',      label2=label_icon)
                    poster_item    = xbmcgui.ListItem(label='Edit Poster',    label2=label_poster)
                    clearlogo_item = xbmcgui.ListItem(label='Edit Clearlogo', label2=label_clearlogo)
                    fanart_item    = xbmcgui.ListItem(label='Edit Fanart',    label2=label_fanart)
                    banner_item    = xbmcgui.ListItem(label='Edit Banner',    label2=label_banner)

                    icon_item.setArt({'icon': img_icon})
                    poster_item.setArt({'icon': img_poster})
                    clearlogo_item.setArt({'icon': img_clearlogo})
                    fanart_item.setArt({'icon': img_fanart})
                    banner_item.setArt({'icon': img_banner})

                    sDialog = KodiSelectDialog('Edit Category Artwork', useDetails=True)
                    sDialog.setRows([
                        icon_item,
                        poster_item,
                        clearlogo_item,
                        fanart_item,
                        banner_item,
                    ])
                    selected_art_edit = sDialog.executeDialog()
                    if selected_art_edit is None:
                        break

                    # helper: só escolhe e grava o path no JSON
                    def _pick_and_set(prompt_title, ext_hint, field_key, success_msg):
                        nonlocal data_change
                        initial_dir = _compute_initial_dir(category_info.get(field_key))
                        chosen = kodi_dialog_get_image(prompt_title, ext_hint, initial_dir)
                        # aceita arquivo local existente OU URL http(s)
                        if chosen and (xbmcvfs.exists(chosen) or str(chosen).lower().startswith(('http://', 'https://'))):
                            category_info[field_key] = chosen
                            data_change = True
                            self._save_category_info(category_name, category_info)
                            kodi_notify(success_msg)

                    # ICON
                    if selected_art_edit == 0:
                        _pick_and_set('Select Category Icon', '.jpg', 's_icon', 'Category Icon path updated')

                    # POSTER
                    elif selected_art_edit == 1:
                        _pick_and_set('Select Category Poster', '.jpg', 's_poster', 'Category Poster path updated')

                    # CLEARLOGO (normalmente .png)
                    elif selected_art_edit == 2:
                        _pick_and_set('Select Category Clearlogo', '.png', 's_clearlogo', 'Category Clearlogo path updated')

                    # FANART
                    elif selected_art_edit == 3:
                        _pick_and_set('Select Category Fanart', '.jpg', 's_fanart', 'Category Fanart path updated')

                    # BANNER
                    elif selected_art_edit == 4:
                        _pick_and_set('Select Category Banner', '.jpg', 's_banner', 'Category Banner path updated')



        if data_change:
            self._save_category_info(category_name, category_info)
            kodi_notify(f'Category "{category_name}" updated!')
            kodi_refresh_container()


    # =========================
    # ===== EXIBIÇÃO ==========
    # =========================

    def display_album_sets(self, handle):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        json_files = [
            f for f in os.listdir(albums_db_path)
            if f.endswith('.json') and f != '_scan_timestamp.json'
        ]
        if not json_files:
            xbmcgui.Dialog().notification('Show Albums', 'No albums found', xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # conjuntos (nomes de arquivos sem .json)
        all_sets = [f[:-5] for f in json_files]
        cats = self.load_categories()

        # álbuns categorizados
        categorized = set()
        for arr in cats.values():
            categorized.update(arr)

        # ordem: [Not Set] (se existir) -> álbuns NÃO categorizados -> categorias
        ordered_unassigned = sorted([s for s in all_sets if s != "[Not Set]" and s not in categorized], key=str.lower)

        # 1) [Not Set]
        if "[Not Set]" in all_sets:
            self._add_album_header_item(handle, set_name='[Not Set]')

        # 2) álbuns não categorizados
        for set_name in ordered_unassigned:
            self._add_album_header_item(handle, set_name=set_name, add_assign_menu=True)

        # 3) categorias (como pastas)
        for category in sorted(cats.keys(), key=str.lower):
            li = xbmcgui.ListItem(label=category)
            ci = self._load_category_info(category)
            li = xbmcgui.ListItem(label = ci.get('m_category', category))
            li.setArt({
                'icon':      ci.get('s_icon')      or '',
                'poster':    ci.get('s_poster')    or '',
                'clearlogo': ci.get('s_clearlogo') or '',
                'fanart':    ci.get('s_fanart')    or '',
                'banner':    ci.get('s_banner')    or '',
            })
            
            m_category = ci.get('m_category', category)
            m_plot = ci.get('m_plot', category)
            li.setProperty('m_category', m_category)
            li.setProperty('m_plot', m_plot)
            
            # menus da categoria
            context_menu = [
                (self._loc(30074, 'Create category'), 'RunPlugin(plugin://plugin.program.photololitas?action=create_category)'),
                (self._loc(30075, 'Manage categories'), 'RunPlugin(plugin://plugin.program.photololitas?action=manage_categories)'),
                (self._loc(30076, 'Edit category'), f'RunPlugin(plugin://plugin.program.photololitas?action=edit_category&category={urllib.parse.quote(category)})'),
                (self._loc(30077, 'Rename category'), f'RunPlugin(plugin://plugin.program.photololitas?action=rename_category&category={urllib.parse.quote(category)})'),
                (self._loc(30028, 'Delete category'), f'RunPlugin(plugin://plugin.program.photololitas?action=delete_category&category={urllib.parse.quote(category)})'),
                (self._loc(30025, 'Scan Albums'), 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
            ]
            li.addContextMenuItems(context_menu)
            url = f"plugin://plugin.program.photololitas/?folder=Albuns&category={urllib.parse.quote(category)}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(handle)

    def _add_album_header_item(self, handle, set_name, add_assign_menu=False):
        # Lê cabeçalho do JSON do álbum e monta o item
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        if not xbmcvfs.exists(albums_json_path):
            return

        with open(albums_json_path, 'r', encoding='utf-8') as f:
            albums_dict = json.load(f)

        album_info = albums_dict
        # conta itens ignorando chaves de metadados
        not_keys = {"m_album","m_tags","m_year","m_plot","m_path","s_icon","s_poster","s_clearlogo","s_fanart","s_banner"}
        set_count = sum(1 for k in albums_dict if k not in not_keys)

        li = xbmcgui.ListItem(label=album_info.get('m_album', set_name))
        theme = 'special://home/addons/plugin.program.photololitas/media/theme/'
        icon_art   = album_info.get('s_icon')     or f'{theme}Not_Set_icon.png'
        poster_art = album_info.get('s_poster')   or f'{theme}Not_Set_poster.png'
        fanart_art = album_info.get('s_fanart')   or f'{theme}_fanart.jpg'

        li.setArt({
            'icon': icon_art,
            'poster': poster_art,
            'clearlogo': album_info.get('s_clearlogo', ''),
            'fanart': fanart_art,
            'banner': album_info.get('s_banner', '')
        })

        m_album = album_info.get('m_album', set_name)
        m_plot  = f"{m_album} possui {set_count} sets\n\n{album_info.get('m_plot','')}"
        li.setProperty('m_album', m_album)
        li.setProperty('m_plot', m_plot)
        
        li.setLabel(album_info.get('m_album', set_name))  # já estava no label de criação, pode manter
        tag = li.getVideoInfoTag()
        tag.setTitle(album_info.get('m_title', '') or '')

        # opcional: preenche o plot no InfoTag também (além de setProperty já usado)
        plot_text = f"{album_info.get('m_album', set_name)} possui {set_count} sets\n\n{album_info.get('m_plot','')}"
        tag.setPlot(plot_text)

        # contextos
        context_menu = [
            (self._loc(30072, "Edit Album"), f"RunPlugin(plugin://plugin.program.photololitas?action=edit_album&set={urllib.parse.quote(set_name)})"),
            (self._loc(30056, "Update Album"), f"RunPlugin(plugin://plugin.program.photololitas?action=update_album&set={urllib.parse.quote(set_name)})"),
            (self._loc(30025, 'Scan Albums'), 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
            (self._loc(30027, 'Settings'), 'RunPlugin(plugin://plugin.program.photololitas?action=settings)'),
        ]
        if add_assign_menu:
            context_menu.insert(3, (
                self._loc(30078, "Add to category…"),
                f"RunPlugin(plugin://plugin.program.photololitas?action=assign_album_to_category&album={urllib.parse.quote(set_name)})"
            ))
            context_menu.insert(4, (
                self._loc(30074, "Create category"),
                "RunPlugin(plugin://plugin.program.photololitas?action=create_category)"
            ))
            context_menu.insert(5, (
                self._loc(30075, "Manage categories"),
                "RunPlugin(plugin://plugin.program.photololitas?action=manage_categories)"
            ))

        li.addContextMenuItems(context_menu)

        url = f"plugin://plugin.program.photololitas/?folder=Albuns&set={urllib.parse.quote(set_name)}"
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

    def display_category_albums(self, handle, category_name):
        cats = self.load_categories()
        albums = cats.get(category_name, [])
        if not albums:
            xbmcgui.Dialog().notification('Categoria', 'Sem álbuns nesta categoria', xbmcgui.NOTIFICATION_INFO, 4000)
            xbmcplugin.endOfDirectory(handle)
            return

        for set_name in sorted(albums, key=str.lower):
            addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
            if not xbmcvfs.exists(albums_json_path):
                continue

            with open(albums_json_path, 'r', encoding='utf-8') as f:
                album_info = json.load(f)

            # Criação do item
            li = xbmcgui.ListItem(label=album_info.get('m_album', set_name))
            theme = 'special://home/addons/plugin.program.photololitas/media/theme/'
            li.setArt({
                'icon': album_info.get('s_icon') or f'{theme}Not_Set_icon.png',
                'poster': album_info.get('s_poster') or f'{theme}Not_Set_poster.png',
                'fanart': album_info.get('s_fanart') or f'{theme}_fanart.jpg',
                'clearlogo': album_info.get('s_clearlogo',''),
                'banner': album_info.get('s_banner',''),
            })

            # 🔹 METADADOS
            not_keys = {"m_album","m_tags","m_year","m_plot","m_path","s_icon","s_poster","s_clearlogo","s_fanart","s_banner"}
            set_count = sum(1 for k in album_info if k not in not_keys)

            m_album = album_info.get('m_album', set_name)
            m_plot  = f"{m_album} possui {set_count} sets\n\n{album_info.get('m_plot','')}"
            m_year  = album_info.get('m_year', '') 
            m_tags  = album_info.get('m_tags', '')

            li.setProperty('m_album', m_album)
            li.setProperty('m_plot', m_plot)
            li.setProperty('m_year', str(m_year))
            li.setProperty('m_tags', m_tags)

            tag = li.getVideoInfoTag()
            tag.setTitle(album_info.get('m_title', '') or '')
            tag.setPlot(album_info.get('m_plot', '') or '')

            # year pode vir como string vazia; convertemos com segurança
            _year = (str(m_year).strip() if m_year is not None else '')
            if _year.isdigit():
                try:
                    tag.setYear(int(_year))
                except Exception:
                    pass  # ignora se não suportado na sua versão de Kodi

            # Menus de contexto
            li.addContextMenuItems([
                (self._loc(30072, "Edit Album"), f"RunPlugin(plugin://plugin.program.photololitas?action=edit_album&set={urllib.parse.quote(set_name)})"),
                ('Scan Albums', 'RunPlugin(plugin://plugin.program.photololitas?action=scan_albums)'),
                (self._loc(30079, "Remove from this category"), f"RunPlugin(plugin://plugin.program.photololitas?action=unassign_album_from_category&category={urllib.parse.quote(category_name)}&album={urllib.parse.quote(set_name)})"),
                (self._loc(30056, "Update Album"), f"RunPlugin(plugin://plugin.program.photololitas?action=update_album&set={urllib.parse.quote(set_name)})"),
            ])

            url = f"plugin://plugin.program.photololitas/?folder=Albuns&set={urllib.parse.quote(set_name)}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(handle)
