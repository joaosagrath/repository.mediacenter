# -*- coding: utf-8 -*-
# Edição de metadados e artes (álbum/issue)

import os
import json
import urllib.parse
import xml.etree.ElementTree as ET
from xml.dom import minidom

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# --- Utilitários do addon ---
from .utils import *

ALBUNS_DIRNAME = 'albuns_db'


class EditorMixin:
    def _loc(self, string_id, fallback=''):
        return kodi_localize(string_id, fallback)

    def edit_album(self, set_name):
        
        if set_name == '[Not Set]':
            kodi_notify(self._loc(30068, 'This album cannot be edited!'))
            return
            
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            kodi_notify(self._loc(30069, 'Album JSON not found'))
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)
            
        album_info = albums_dict
        edit_album_data = True
        data_change = False
        
        while edit_album_data == True:
            edit_options = [
                self._loc(30070, "Edit Album Metadata"),
                self._loc(30071, "Edit Album Artwork"),
            ]
            
            selected_edit = xbmcgui.Dialog().select(self._loc(30072, "Edit Album"), edit_options)
            
            if selected_edit == -1:
                break
            
            if selected_edit == 0:
                while True:
                    options = [
                        "Edit Album Title: {}".format(album_info.get('m_album', '')),
                        "Edit Album Tags: {}".format(album_info.get('m_tags', '')),
                        "Edit Album Release Year: {}".format(album_info.get('m_year', '')),
                        "Edit Album Plot: {}".format(album_info.get('m_plot', '')),
                        "Save Album"
                    ]
                    selected = xbmcgui.Dialog().select(self._loc(30072, "Edit Album"), options)
                    
                    if selected == -1 or selected == 5:
                        break
                    
                    if selected == 0:
                        new_title = xbmcgui.Dialog().input("Enter new title", defaultt=album_info.get('m_album', ''))
                        if new_title:
                            album_info['m_album'] = new_title
                            data_change = True
                            kodi_notify('Album title updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 1:
                        new_tags = xbmcgui.Dialog().input("Enter new tags", defaultt=album_info.get('m_tags', ''))
                        if new_tags:
                            album_info['m_tags'] = new_tags
                            kodi_notify('Album tags updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 2:
                        new_year = xbmcgui.Dialog().numeric(0, "Enter new release date", defaultt=album_info.get('m_year', ''))
                        if new_year:
                            album_info['m_year'] = new_year
                            data_change = True
                            kodi_notify('Album release year updated')
                            self.save_json(albums_json_path, albums_dict)

                    elif selected == 3:
                        new_plot = xbmcgui.Dialog().input("Enter new plot", defaultt=album_info.get('m_plot', ''))
                        if new_plot:
                            album_info['m_plot'] = new_plot
                            kodi_notify('Album plot updated')
                            self.save_json(albums_json_path, albums_dict)
                    
                    elif selected == 4:
                        self.save_album_nfo(album_info)
                        kodi_notify("Data from from {} saved!".format(album_info.get('m_album')))
                        break
                    
            elif selected_edit == 1:
                while True:
                    
                    label2_poster    = album_info['s_poster'] if album_info['s_poster'] else 'No Art'
                    label2_fanart    = album_info['s_fanart'] if album_info['s_fanart'] else 'No Art'
                    label2_icon      = album_info['s_icon']   if album_info['s_icon']   else 'No Art'
                    label2_clearlogo = album_info['s_clearlogo'] if album_info['s_clearlogo'] else 'No Art'
                    label2_banner    = album_info['s_banner'] if album_info['s_banner'] else 'No Art'
                    
                    img_poster    = album_info['s_poster'] if album_info['s_poster'] else 'DefaultAddonNone.png'
                    img_fanart    = album_info['s_fanart'] if album_info['s_fanart'] else 'DefaultAddonNone.png'
                    img_icon      = album_info['s_icon']   if album_info['s_icon']   else 'DefaultAddonNone.png'
                    img_clearlogo = album_info['s_clearlogo'] if album_info['s_clearlogo'] else 'DefaultAddonNone.png'
                    img_banner    = album_info['s_banner'] if album_info['s_banner'] else 'DefaultAddonNone.png'
                    
                    poster_listitem    = xbmcgui.ListItem(label = 'Edit Poster', label2 = label2_poster)
                    fanart_listitem    = xbmcgui.ListItem(label = 'Edit fanart', label2 = label2_fanart)
                    icon_listitem      = xbmcgui.ListItem(label = 'Edit icon',   label2 = label2_icon)
                    clearlogo_listitem = xbmcgui.ListItem(label = 'Edit clearlogo', label2 = label2_clearlogo)
                    banner_listitem    = xbmcgui.ListItem(label = 'Edit banner', label2 = label2_banner)

                    poster_listitem.setArt   ({'icon' : img_poster})
                    fanart_listitem.setArt   ({'icon' : img_fanart})
                    icon_listitem.setArt     ({'icon' : img_icon})
                    clearlogo_listitem.setArt({'icon' : img_clearlogo})
                    banner_listitem.setArt   ({'icon' : img_banner})
                    
                    destination_path =  album_info['m_path']
                
                    sDialog = KodiSelectDialog(self._loc(30071, 'Edit Album Artwork'), useDetails = True)
                    sDialog.setRows([
                        poster_listitem,
                        fanart_listitem,
                        icon_listitem,
                        clearlogo_listitem,
                        banner_listitem,
                    ])
                    selected_art_edit = sDialog.executeDialog()
                    if selected_art_edit is None: break
                    
                    if selected_art_edit == 0:
                        new_poster = kodi_dialog_get_image('Select Album Poster', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_poster == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Poster not change!')
                                    break
                            
                            album_info['s_poster'] = os.path.join(destination_path, 'folder.jpg')
                            self.save_artwork(new_poster, 's_poster', album_info, albums_json_path, albums_dict, 'Album Poster updated')

                        
                    elif selected_art_edit == 1:
                        new_fanart = kodi_dialog_get_image('Select Album Fanart', ',jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_fanart == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                                    
                            album_info['s_fanart'] = os.path.join(destination_path, 'fanart.jpg')
                            self.save_artwork(new_fanart, 's_fanart', album_info, albums_json_path, albums_dict, 'Album Fanart updated')
                            
                            utils_update_file_mtime(new_fanart)
                            
                    elif selected_art_edit == 2:
                        new_icon = kodi_dialog_get_image('Select Album Icon', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_icon == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            break
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_icon'] = os.path.join(destination_path, 'icon.jpg')
                            self.save_artwork(new_icon, 's_icon', album_info, albums_json_path, albums_dict, 'Album Icon updated')
                            
                    elif selected_art_edit == 3:
                        new_clearlogo = kodi_dialog_get_image('Select Album Clearlogo', '.png', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_clearlogo == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            return
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_clearlogo'] = os.path.join(destination_path, 'clearlogo.png')
                            self.save_artwork(new_clearlogo, 's_clearlogo', album_info, albums_json_path, albums_dict, 'Album Clearlogo updated')

                    elif selected_art_edit == 4:
                        new_banner = kodi_dialog_get_image('Select Album Banner', '.jpg', destination_path)
                        # Verifica se o usuário cancelou a seleção
                        if new_banner == destination_path:
                            # Exibe uma mensagem ao usuário (opcional)
                            kodi_notify('Nenhuma imagem selecionada.')
                            # Para a execução da função
                            return
                        else:
                            if not destination_path:
                                destination_path = kodi_dialog_get_directory('Select where to store Album Arts:')
                                album_info['m_path'] = destination_path 
                                if not destination_path:
                                    kodi_notify('Album Fanart not change!')
                                    break
                            album_info['s_banner'] = os.path.join(destination_path, 'banner.jpg')
                            self.save_artwork(new_banner, 's_banner', album_info, albums_json_path, albums_dict, 'Album Banner updated')

        if data_change:           
            self.save_album_nfo(album_info)
        
    def edit_issue(self, set_name, album_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
       
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification('Edit Issue', 'Album JSON not found', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        if album_name not in albums_dict:
            xbmcgui.Dialog().notification('Edit Issue', 'Album not found in JSON', xbmcgui.NOTIFICATION_ERROR, 5000)
            return

        album_info = albums_dict[album_name]

        edit_options = [
            "Edit Issue Metadata",
            "Scan Issue Metadata",
            "Edit Issue Artwork",
            "Scan Issue Artwork",
            "Save Issue"
        ]
        
        selected_edit = xbmcgui.Dialog().select(f"Edit {album_name}", edit_options)
        if selected_edit == -1:
            return
        
        if selected_edit == 0:
            while True:
            
                plot_str = text_limit_string(album_info.get('m_plot'), 40)
                sDialog = KodiSelectDialog('Edit Issue Metadata', useDetails = False)
                sDialog.setRows([
                    "Edit Number: {}".format(album_info.get('m_number')), 
                    "Edit Title: {}".format(album_info.get('m_title')),
                    "Edit Model: {}".format(album_info.get('m_model')), 
                    "Edit Other Names: {}".format(album_info.get('m_others')), 
                    "Edit Album: {}".format(album_info.get('m_album')),
                    "Edit Release Date: {}".format(album_info.get('m_date')),
                    "Edit Plot: {}".format(plot_str),
                    "Scan Issue Metadata from {}".format(album_info.get('m_album')),
                    "Save Issue Metadata"
                ])
                selected = sDialog.executeDialog()
                if selected is None: break

                if selected == 0:
                    
                    old_number = album_info.get('m_number')
                    new_number = xbmcgui.Dialog().input("Enter new issue number", defaultt=album_info.get('m_number', ''), type=xbmcgui.INPUT_NUMERIC)
                    if new_number:
                        album_info['m_number'] = new_number
                        kodi_notify('Issue number updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)
                    else:
                        album_info['m_number'] = old_number
                        kodi_notify('Issue number not updated')
                    
                elif selected == 1:
                    
                    old_title = album_info.get('m_title')
                    new_title = xbmcgui.Dialog().input("Enter new title", defaultt=album_info.get('m_title', ''))
                    if new_title:
                        album_info['m_title'] = new_title
                        kodi_notify('Issue title updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)
                    else:
                        album_info['m_title'] = old_title
                        kodi_notify('Issue title not updated')

                # Pelo novo padrão (com etapa por LETRA):
                elif selected == 2:
                    import unicodedata

                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')

                    # Lista de arquivos JSON (exclui especiais)
                    model_files = [f for f in os.listdir(lolitas_db_path)
                                   if f.endswith('.json') and f not in ['[Not Set].json', '_scan_timestamp.json']]

                    # Nomes (sem .json)
                    model_folders = sorted([os.path.splitext(f)[0] for f in model_files], key=lambda s: s.casefold())

                    # Helper para obter a letra do grupo (normaliza acentos; não-alfabético => '#')
                    def _group_letter(name: str) -> str:
                        if not name:
                            return '#'
                        first = name.strip()[0]
                        # normaliza acentos (Á->A, Ç->C, Ñ->N)
                        base = unicodedata.normalize('NFKD', first).encode('ASCII', 'ignore').decode('ASCII').upper()
                        return base if 'A' <= base <= 'Z' else '#'

                    # Agrupa por letra
                    groups = {}
                    for m in model_folders:
                        g = _group_letter(m)
                        groups.setdefault(g, []).append(m)

                    # Ordena listas internas
                    for g in groups:
                        groups[g].sort(key=lambda s: s.casefold())

                    # Monta lista de letras existentes (A..Z) + '#' se houver
                    letters = [chr(c) for c in range(ord('A'), ord('Z') + 1) if c - 65 < 26 and chr(c) in groups]
                    if '#' in groups:
                        letters.append('#')

                    # Se não há nada, só permitir criar novo
                    if not letters:
                        letters = []

                    # Dialogo 1: escolher letra ou criar novo
                    letter_labels = ['<Criar Novo Álbum>'] + (letters if letters else [])
                    sel_letter_idx = xbmcgui.Dialog().select("Selecione a letra do álbum", letter_labels)

                    if sel_letter_idx < 0:
                        xbmcgui.Dialog().notification("Canceled", "Nenhum álbum foi selecionado.")
                        return

                    # Criar novo direto
                    if sel_letter_idx == 0:
                        new_model = xbmcgui.Dialog().input("Digite o nome do novo álbum")
                        if not new_model:
                            xbmcgui.Dialog().notification("Erro", "Nome do álbum não pode ser vazio.")
                            return
                    else:
                        chosen_letter = letter_labels[sel_letter_idx]  # 'A'..'Z' ou '#'
                        models_for_letter = groups.get(chosen_letter, [])
                        if not models_for_letter:
                            xbmcgui.Dialog().notification("Atenção", "Não há álbuns para essa letra.")
                            return

                        # Dialogo 2: escolher álbum dentro da letra
                        sel_model_idx = xbmcgui.Dialog().select(f"Selecione o álbum — {chosen_letter}", models_for_letter)
                        if sel_model_idx < 0:
                            xbmcgui.Dialog().notification("Canceled", "Nenhum álbum foi selecionado.")
                            return

                        new_model = models_for_letter[sel_model_idx]

                    # Origem correta para mover entre grupos de modelo:
                    # deve vir de m_model (não de m_album).
                    origin_model = (album_info.get('m_model') or '').strip() or "[Not Set]"
                    destiny_file = f"{new_model}"

                    # Fallback para set_name/[Not Set] em bases antigas/inconsistentes.
                    origin_candidates = []
                    for candidate in [origin_model, set_name, "[Not Set]"]:
                        if candidate and candidate not in origin_candidates:
                            origin_candidates.append(candidate)

                    origin_path = None
                    for candidate in origin_candidates:
                        test_path = os.path.join(lolitas_db_path, f"{candidate}.json")
                        if xbmcvfs.exists(test_path):
                            origin_path = test_path
                            break

                    if not origin_path:
                        xbmcgui.Dialog().notification("Error", "Arquivo de origem do modelo não encontrado.")
                        return

                    destiny_path = os.path.join(lolitas_db_path, f"{destiny_file}.json")

                    item_key = album_name

                    album_info['m_model'] = new_model
                    self.save_json(albums_json_path, albums_dict)

                    # Verificar se o álbum de destino já existe
                    destiny_data = {}
                    if xbmcvfs.exists(destiny_path):
                        try:
                            with xbmcvfs.File(destiny_path) as destiny_file_handle:
                                destiny_raw = destiny_file_handle.read()
                                destiny_data = json.loads(destiny_raw) if destiny_raw and destiny_raw.strip() else {}
                        except Exception as e:
                            xbmcgui.Dialog().notification("Error", f'Erro ao carregar o álbum de destino: {str(e)}')
                            return
                    else:
                        destiny_data = {
                            "m_model": new_model,
                            "m_type": "",
                            "s_icon": "",
                            "s_poster": "",
                            "s_fanart": "",
                            "s_banner": ""
                        }

                    # Carregar o arquivo de origem
                    try:
                        with xbmcvfs.File(origin_path) as origin_file_handle:
                            origin_raw = origin_file_handle.read()
                            origin_data = json.loads(origin_raw) if origin_raw and origin_raw.strip() else {}
                    except Exception as e:
                        xbmcgui.Dialog().notification("Error", f'Erro ao carregar o arquivo de origem: {str(e)}')
                        return

                    # Remover o item do arquivo de origem
                    if item_key in origin_data:
                        item_data = origin_data.pop(item_key)

                        # Adiciona item ao destino
                        destiny_data[item_key] = item_data

                        # Persistência
                        try:
                            with xbmcvfs.File(origin_path, 'w') as origin_file_handle:
                                origin_file_handle.write(json.dumps(origin_data, indent=4, ensure_ascii=False))
                            with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                destiny_file_handle.write(json.dumps(destiny_data, indent=4, ensure_ascii=False))

                            xbmcgui.Dialog().notification("Success", f'Modelo "{item_key}" foi movido com sucesso para o grupo "{new_model}".')

                            # Limpeza de arquivos órfãos/especiais
                            if not origin_data:
                                xbmcvfs.delete(origin_path)
                            scan_timestamp_path = os.path.join(lolitas_db_path, '_scan_timestamp.json')
                            if xbmcvfs.exists(scan_timestamp_path):
                                xbmcvfs.delete(scan_timestamp_path)
                            not_set_path = os.path.join(lolitas_db_path, '[Not Set].json')
                            if xbmcvfs.exists(not_set_path):
                                xbmcvfs.delete(not_set_path)

                            self.save_issue_nfo(album_info)
                            save_timestamp(albums_db_path)
                            kodi_refresh_container()

                        except Exception as e:
                            xbmcgui.Dialog().notification("Error", f'Erro ao salvar os arquivos JSON: {str(e)}')
                            xbmc.log(f'Erro ao salvar os arquivos JSON: {str(e)}', xbmc.LOGERROR)
                    else:
                        xbmcgui.Dialog().notification("Error", f'O item "{item_key}" não foi encontrado no álbum de origem.')

                # Pelo novo padrão (etapa por LETRA, com "Voltar" implícito e finalizar quando quiser):
                elif selected == 3:
                    import unicodedata

                    # Fluxo "Edit Other Names":
                    # 1) Carrega modelos de lolitas_db e agrupa por letra.
                    # 2) Inicializa seleção com m_others (nomes completos) ou m_model (fallback).
                    # 3) Usuário pode:
                    #    - escolher modelos por letra (multiselect),
                    #    - criar nomes manuais separados por vírgula,
                    #    - limpar seleção.
                    # 4) Ao concluir:
                    #    - m_others recebe os nomes completos selecionados.
                    #    - m_model recebe primeiros nomes unidos por "and"
                    #      (2 nomes: "A and B"; 3+: "A, B and C").
                    # 5) Salva JSON, timestamp e atualiza container.

                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    lolitas_db_path = os.path.join(addon_data_path, 'lolitas_db')

                    # Carrega lista de modelos a partir dos .json (exclui especiais)
                    model_files = [f for f in os.listdir(lolitas_db_path)
                                   if f.endswith('.json') and f not in ['[Not Set].json', '_scan_timestamp.json']]
                    model_folders = sorted([os.path.splitext(f)[0] for f in model_files], key=lambda s: s.casefold())

                    # Normaliza primeira letra (Á->A, Ç->C, etc.); não-alfabéticos em '#'
                    def _group_letter(name: str) -> str:
                        if not name:
                            return '#'
                        first = name.strip()[0]
                        base = unicodedata.normalize('NFKD', first).encode('ASCII', 'ignore').decode('ASCII').upper()
                        return base if 'A' <= base <= 'Z' else '#'

                    # Agrupa por letra
                    groups = {}
                    for m in model_folders:
                        g = _group_letter(m)
                        groups.setdefault(g, []).append(m)
                    for g in groups:
                        groups[g].sort(key=lambda s: s.casefold())

                    # Seleção inicial prioriza m_others (nomes completos).
                    # Se não houver m_others, usa m_model como fallback.
                    existing_others_str = album_info.get('m_others', "") or ""
                    existing_model_str  = (album_info.get('m_model', "") or "").strip()

                    selected_models = set([x.strip() for x in existing_others_str.split(',') if x.strip()])
                    if not selected_models and existing_model_str:
                        selected_models.add(existing_model_str)

                    def _join_with_and(items):
                        n = len(items)
                        if n == 0:
                            return ''
                        if n == 1:
                            return items[0]
                        if n == 2:
                            return f"{items[0]} and {items[1]}"
                        return ", ".join(items[:-1]) + " and " + items[-1]

                    def _build_preview_from_selected(selected_names):
                        final_list = sorted(selected_names, key=lambda s: s.casefold())
                        first_names = []
                        seen = set()
                        for full in final_list:
                            first = (full.strip().split()[0] if full.strip() else '')
                            if first and first not in seen:
                                seen.add(first)
                                first_names.append(first)
                        return _join_with_and(first_names)

                    # Monta as letras disponíveis
                    available_letters = [ltr for ltr in [chr(c) for c in range(ord('A'), ord('Z')+1)] if ltr in groups]
                    if '#' in groups:
                        available_letters.append('#')

                    # Loop de navegação (voltar para letras quantas vezes quiser)
                    while True:
                        preview_model = _build_preview_from_selected(selected_models)
                        # Menu principal (letras + ações)
                        letter_menu = [
                            f'<Concluir e Salvar ({preview_model})>',
                            '<Criar Nova Modelo>',
                            '<Limpar seleção>'
                        ] + available_letters
                        sel_letter_idx = xbmcgui.Dialog().select("Modelos por letra (selecione em várias letras antes de salvar)", letter_menu)

                        if sel_letter_idx < 0:
                            xbmcgui.Dialog().notification("Cancelado", "Nenhuma alteração realizada.")
                            break

                        # 0 = concluir/salvar
                        if sel_letter_idx == 0:
                            # Lista final de modelos completos (m_others): mantém nomes completos
                            final_list = sorted(selected_models, key=lambda s: s.casefold())
                            new_lolitas_str = ", ".join(final_list)

                            # Extrai apenas o primeiro nome de cada modelo
                            first_names = []
                            seen = set()
                            for full in final_list:
                                first = (full.strip().split()[0] if full.strip() else '')
                                if first and first not in seen:
                                    seen.add(first)
                                    first_names.append(first)

                            # Junta com "and" no formato esperado pela skin:
                            # - 2 nomes: "Ksyusha and Lesya"
                            # - 3+ nomes: "Diana, Ksyusha and Lesya"
                            # Atualiza campos para exibição na skin:
                            # - m_others: nomes completos, separados por vírgula
                            # - m_model: primeiros nomes unidos por "and"
                            album_info['m_others'] = new_lolitas_str.strip().strip(',')  # nomes completos
                            album_info['m_model']  = _join_with_and(first_names)          # só primeiros nomes

                            self.save_json(albums_json_path, albums_dict)
                            xbmcgui.Dialog().notification("Sucesso", f'Modelos atualizados: {album_info["m_model"]}')
                            save_timestamp(albums_db_path)
                            kodi_refresh_container()
                            break

                        # 1 = criar novos nomes (permite digitar vários, separados por vírgula)
                        elif sel_letter_idx == 1:
                            seed = ", ".join(sorted(selected_models, key=lambda s: s.casefold()))
                            typed = xbmcgui.Dialog().input("Digite novos nomes (separados por vírgulas)", defaultt=seed)
                            if typed:
                                for nm in [t.strip() for t in typed.split(',') if t.strip()]:
                                    selected_models.add(nm)
                            # volta ao menu de letras para permitir escolher mais
                            continue
                        
                        # 2 = limpar seleção
                        elif sel_letter_idx == 2:
                            selected_models.clear()
                            xbmcgui.Dialog().notification("OK", "Seleção limpa.")
                            continue

                        # Letra escolhida
                        chosen_letter = letter_menu[sel_letter_idx]
                        models_for_letter = groups.get(chosen_letter, [])

                        if not models_for_letter:
                            xbmcgui.Dialog().notification("Atenção", "Não há modelos para essa letra.")
                            continue

                        # Preseleciona o que já estava marcado nessa letra
                        pre = [i for i, name in enumerate(models_for_letter) if name in selected_models]

                        # Multisseleção: cancelar aqui apenas retorna ao menu de letras (não salva nem altera)
                        picked = xbmcgui.Dialog().multiselect(f"Selecione modelos — {chosen_letter}", models_for_letter, preselect=pre)

                        if picked is None:
                            # usuário cancelou esta tela → volta para lista de letras
                            continue

                        # Atualiza seleção geral: remove os desta letra e adiciona os escolhidos
                        prev_letter_set = set(models_for_letter) & selected_models
                        new_letter_set  = set(models_for_letter[i] for i in picked)

                        selected_models.difference_update(prev_letter_set)
                        selected_models.update(new_letter_set)
                        # volta para lista de letras para permitir adicionar de outras letras

                elif selected == 4:
                    # Caminhos dos diretórios
                    addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
                    albums_db_path = os.path.join(addon_data_path, 'albuns_db')

                    # Obter a lista de arquivos JSON existentes, excluindo '[Not Set]'
                    album_files = [f for f in os.listdir(albums_db_path) if f.endswith('.json') and f != '[Not Set].json']

                    # Remover a extensão dos arquivos
                    album_folders = [os.path.splitext(f)[0] for f in album_files]

                    # Adicionar a opção "Adicionar Album" no topo da lista
                    options = ["Adicionar Album"] + album_folders
                    selected_album_index = xbmcgui.Dialog().select("Select Album", options)

                    if selected_album_index == 0:  # O usuário selecionou "Adicionar Album"
                        keyboard = xbmcgui.Dialog().input("Digite o nome do novo álbum", type=xbmcgui.INPUT_ALPHANUM)
                        if keyboard:  # Se o usuário digitou algo
                            selected_album = keyboard
                        else:
                            xbmcgui.Dialog().notification("Canceled", "Nenhum nome de álbum foi inserido.")
                            return  # Sai da função se o usuário cancelar a entrada de texto
                    elif selected_album_index > 0:
                        selected_album = options[selected_album_index]
                    else:
                        xbmcgui.Dialog().notification("Canceled", "Nenhum álbum foi selecionado.")
                        return  # Sai da função se o usuário cancelar a seleção

                    # Identificar o arquivo de origem e destino
                    origin_file = album_info.get('m_album') or "[Not Set]"
                    destiny_file = selected_album
                    
                    origin_path = os.path.join(albums_db_path, f"{origin_file}.json")
                    destiny_path = os.path.join(albums_db_path, f"{destiny_file}.json")
                    item_key = album_name

                    # Atualizar o nome do álbum
                    album_info['m_album'] = os.path.splitext(destiny_file)[0]
                    self.save_json(albums_json_path, albums_dict)

                    try:
                        # Carregar os arquivos JSON de origem e destino
                        with xbmcvfs.File(origin_path) as origin_file_handle:
                            origin_data = json.load(origin_file_handle)

                        # Se o arquivo de destino não existir, criar o cabeçalho básico
                        if not xbmcvfs.exists(destiny_path):
                            destiny_data = {
                                "m_album": destiny_file,  # Ou destiny_file sem extensão, se necessário
                                "m_tags": "",
                                "m_year": "",
                                "m_plot": "",
                                "m_path": "",
                                "s_icon": "",
                                "s_poster": "",
                                "s_clearlogo": "",
                                "s_fanart": "",
                                "s_banner": ""
                            }
                        else:
                            with xbmcvfs.File(destiny_path) as destiny_file_handle:
                                destiny_data = json.load(destiny_file_handle)

                        # Remover o item do arquivo de origem e adicionar ao destino
                        if item_key in origin_data:
                            item_data = origin_data.pop(item_key)
                            destiny_data[item_key] = item_data

                            # Verificar se o arquivo de origem está vazio após remoção
                            if not origin_data:
                                xbmcvfs.delete(origin_path)
                            else:
                                with xbmcvfs.File(origin_path, 'w') as origin_file_handle:
                                    origin_file_handle.write(json.dumps(origin_data, indent=4, ensure_ascii=False))

                            # Salvar o arquivo de destino atualizado com o cabeçalho e o item movido
                            with xbmcvfs.File(destiny_path, 'w') as destiny_file_handle:
                                destiny_file_handle.write(json.dumps(destiny_data, indent=4, ensure_ascii=False))

                            xbmcgui.Dialog().notification("Success", f'O item "{item_key}" foi movido com sucesso para o álbum "{selected_album}".')
                            self.save_issue_nfo(album_info) 
                            save_timestamp(albums_db_path)
                            kodi_refresh_container()
                            
                            # Saindo do loop
                            break
                        
                        else:
                            xbmcgui.Dialog().notification("Error", f'O item "{item_key}" não foi encontrado no álbum de origem.')
                    except Exception as e:
                        xbmcgui.Dialog().notification("Error", f"Falha ao mover o item: {str(e)}")

                elif selected == 5:
                    new_date = xbmcgui.Dialog().numeric(1, "Enter new release date", defaultt=album_info.get('m_date', ''))
                    if new_date:
                        album_info['m_date'] = new_date
                        kodi_notify('Issue release date updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)

                elif selected == 6:
                    new_plot = xbmcgui.Dialog().input("Enter new plot", defaultt=album_info.get('m_plot', ''))
                    if new_plot:
                        album_info['m_plot'] = new_plot
                        kodi_notify('Issue plot updated')
                        self.save_json(albums_json_path, albums_dict)
                        save_timestamp(albums_db_path)
                
                elif selected == 7:
                    album_name = album_info['m_album']
                    kodi_notify('Album: {}'.format(album_name))
                
                elif selected == 8:
                    self.save_issue_nfo(album_info)
                    kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))
                    break
        
        elif selected_edit == 1:
            if self._scan_issue_metadata(album_info):
                self.save_json(albums_json_path, albums_dict)
                save_timestamp(albums_db_path)
                kodi_refresh_container()
                kodi_notify("Issue metadata updated from NFO.")
        
        elif selected_edit == 2:
            while True:
                
                label2_poster = album_info['s_poster'] if album_info['s_poster'] else 'No Art'
                label2_fanart = album_info['s_fanart'] if album_info['s_fanart'] else 'No Art'
                label2_banner = album_info['s_banner'] if album_info['s_banner'] else 'No Art'
                label2_icon   = album_info['s_icon']   if album_info['s_icon']   else 'No Art'
                label2_save   = 'Save issue data to NFO'
                
                img_poster = album_info['s_poster'] if album_info['s_poster'] else 'DefaultAddonNone.png'
                img_fanart = album_info['s_fanart'] if album_info['s_fanart'] else 'DefaultAddonNone.png'
                img_banner = album_info['s_banner'] if album_info['s_banner'] else 'DefaultAddonNone.png'
                img_icon =   album_info['s_icon']   if album_info['s_icon']   else 'DefaultAddonNone.png'
                img_save = 'defaultaddonsrepo.png'
                
                poster_listitem     = xbmcgui.ListItem(label = 'Edit Poster', label2 = label2_poster)
                fanart_listitem     = xbmcgui.ListItem(label = 'Edit fanart', label2 = label2_fanart)
                banner_listitem     = xbmcgui.ListItem(label = 'Edit banner', label2 = label2_banner)
                icon_listitem       = xbmcgui.ListItem(label = 'Edit icon',   label2 = label2_icon)
                save_listitem       = xbmcgui.ListItem(label = 'Save Issue',  label2 = label2_save)

                poster_listitem.setArt({'icon' : img_poster})
                fanart_listitem.setArt({'icon' : img_fanart})
                banner_listitem.setArt({'icon' : img_banner})
                icon_listitem.setArt({'icon' : img_icon})
                save_listitem.setArt({'icon' : img_save})
                
                destination_path =  album_info['m_path']
                
                # Método Auxialir
                def _is_valid_file(path, allowed_exts):
                    if not path or not isinstance(path, str):
                        return False
                    path = path.strip()
                    base = os.path.basename(path)
                    root, ext = os.path.splitext(base)
                    if not root or not ext:
                        return False
                    if ext.lower() not in allowed_exts:
                        return False
                    # Usa VFS do Kodi (funciona com smb://, nfs:// etc.); fallback local:
                    try:
                        return xbmcvfs.exists(path)
                    except Exception:
                        return os.path.isfile(path)

                def edit_artwork(key, title, ext, dest_name):
                    old_path = album_info.get(key) or ''
                    new_path = kodi_dialog_get_image(f'Select issue {title}', ext, destination_path)

                    # Conjunto de extensões aceitas (.jpg também aceita .jpeg)
                    allowed_exts = {ext.lower()}
                    if ext.lower() == '.jpg':
                        allowed_exts.add('.jpeg')

                    # Se veio diretório ou arquivo inexistente/sem extensão válida → trata como cancel
                    if not _is_valid_file(new_path, allowed_exts):
                        kodi_notify(f'{title} not changed')
                        return False, None

                    target = os.path.join(destination_path, dest_name)

                    # Atualiza destino “fixo” (ex.: folder.jpg) somente se diferente
                    if not old_path or os.path.normpath(str(old_path)) != os.path.normpath(str(target)):
                        album_info[key] = target

                    # Copia a arte escolhida para o destino e persiste JSON
                    self.save_artwork(new_path, key, album_info, albums_json_path, albums_dict, f'Issue {title} updated')
                    return True, new_path
            
                sDialog = KodiSelectDialog('Edit Issue Artwork', useDetails = True)
                sDialog.setRows([
                    poster_listitem,
                    fanart_listitem,
                    banner_listitem,
                    icon_listitem,
                    save_listitem
                ])
                selected_art_edit = sDialog.executeDialog()
                if selected_art_edit is None: return
                
                if selected_art_edit == 0:
                    edit_artwork('s_poster', 'Poster', '.jpg', 'folder.jpg')

                elif selected_art_edit == 1:
                    changed, src = edit_artwork('s_fanart', 'Fanart', '.jpg', 'fanart.jpg')
                    if changed and src:
                        utils_update_file_mtime(src)
                        
                elif selected_art_edit == 2:
                    edit_artwork('s_banner', 'Banner', '.jpg', 'banner.jpg')

                elif selected_art_edit == 3:
                    edit_artwork('s_icon', 'Icon', '.png', 'icon.png')
                
                elif selected_art_edit == 4:
                    self.save_issue_nfo(album_info)
                    kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))
                    break
        
        elif selected_edit == 3:
            if self._scan_issue_artworks(album_info):
                self.save_json(albums_json_path, albums_dict)
                save_timestamp(albums_db_path)
                kodi_refresh_container()
                kodi_notify("Artwork from isssue {} loaded!".format(album_info.get('m_title')))
                
        elif selected_edit == 4:
            self.save_issue_nfo(album_info)
            kodi_notify("Data from isssue {} saved!".format(album_info.get('m_title')))

    def _scan_issue_metadata(self, album_info):
        issue_path = (album_info.get('m_path') or '').strip()
        if not issue_path:
            kodi_notify('Issue path not found.')
            return False

        dir_name = os.path.basename(os.path.normpath(issue_path))
        nfo_file = os.path.join(issue_path, f'{dir_name}.nfo')

        if not os.path.exists(nfo_file):
            kodi_notify("No Local Metadata for {}".format(dir_name))
            return False

        try:
            tree = ET.parse(nfo_file)
            root_element = tree.getroot()
            album_info["m_number"] = root_element.findtext('m_number') or album_info.get("m_number") or ""
            album_info["m_title"] = root_element.findtext('m_title') or album_info.get("m_title") or dir_name
            album_info["m_album"] = root_element.findtext('m_album') or album_info.get("m_album") or ""
            album_info["m_model"] = root_element.findtext('m_model') or album_info.get("m_model") or ""
            album_info["m_others"] = root_element.findtext('m_others') or album_info.get("m_others") or ""
            album_info["m_date"] = root_element.findtext('m_date') or album_info.get("m_date") or ""
            album_info["m_year"] = root_element.findtext('m_year') or album_info.get("m_year") or ""
            album_info["m_tags"] = root_element.findtext('m_tags') or album_info.get("m_tags") or ""
            album_info["m_plot"] = root_element.findtext('m_plot') or album_info.get("m_plot") or ""
            return True
        except ET.ParseError as e:
            kodi_notify_error(f'Error parsing NFO file: {str(e)}')
            return False

    def _scan_issue_artworks(self, album_info):
        valid_art_files = ['banner.jpg', 'fanart.jpg', 'folder.jpg', 'icon.jpg', 'clearlogo.png']
        issue_path = (album_info.get('m_path') or '').strip()
        if not issue_path:
            kodi_notify('Issue path not found.')
            return False

        found_any = False
        for file_name in valid_art_files:
            art_path = os.path.join(issue_path, file_name)
            if not os.path.exists(art_path):
                continue
            found_any = True
            if file_name == 'banner.jpg':
                album_info['s_banner'] = art_path
            elif file_name == 'fanart.jpg':
                album_info['s_fanart'] = art_path
            elif file_name == 'folder.jpg':
                album_info['s_poster'] = art_path
            elif file_name == 'icon.jpg':
                album_info['s_icon'] = art_path
            elif file_name == 'clearlogo.png':
                album_info['s_clearlogo'] = art_path

        if not found_any:
            kodi_notify("No local artworks for {}".format(album_info.get('m_title') or 'issue'))
        return found_any

    def save_album_nfo(self, album_info):

        # Crie o elemento root
        album = ET.Element('album')
        
        # Adicione subelementos ao root
        ET.SubElement(album, 'm_album').text = album_info.get('m_album', '')
        ET.SubElement(album, 'm_tags').text = album_info.get('m_tags', '')
        ET.SubElement(album, 'm_year').text = album_info.get('m_year', '')
        ET.SubElement(album, 'm_plot').text = album_info.get('m_plot', '')
        ET.SubElement(album, 'm_path').text = album_info.get('m_path', '')
        ET.SubElement(album, 's_icon').text = album_info.get('s_icon', '')
        ET.SubElement(album, 's_poster').text = album_info.get('s_poster', '')
        ET.SubElement(album, 's_clearlogo').text = album_info.get('s_clearlogo', '')
        ET.SubElement(album, 's_fanart').text = album_info.get('s_fanart', '')
        ET.SubElement(album, 's_banner').text = album_info.get('s_banner', '')
        
        # Obtenha o caminho da pasta e o nome da pasta
        m_path = album_info.get('m_path', '')
        
        if not m_path:
            m_path = kodi_dialog_get_directory('Select where to store Album NFO')
            if not m_path:
                kodi_notify('Album NFO not saved')
                return
                
        folder_name = os.path.basename(os.path.normpath(m_path))
        nfo_path = os.path.join(m_path, f"{folder_name}.nfo")

        # Crie a árvore XML
        tree = ET.ElementTree(album)
        
        # Converta para string com minidom para formatação bonita
        xml_str = ET.tostring(album, encoding='utf-8')
        pretty_xml_str = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Salve o arquivo XML
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_str)
            
        kodi_notify('Album data sucessfully saved!')


    def save_all_issues_nfo(self):
        addon = xbmcaddon.Addon()
        addon_data_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        verbose_log = (addon.getSetting('batch_update_verbose_log') or '').lower() == 'true'

        xbmc.log(f'[photololitas] save_all_issues_nfo started | profile={addon_data_path} | albuns_db={albums_db_path} | verbose_log={verbose_log}', xbmc.LOGINFO)

        updated_count = 0
        skipped_count = 0
        failed_count = 0
        tasks = []

        processed_from_db = False
        json_files = []
        if os.path.isdir(albums_db_path):
            json_files = [f for f in os.listdir(albums_db_path) if f.endswith('.json')]
            xbmc.log(f'[photololitas] albuns_db found with {len(json_files)} json files', xbmc.LOGINFO)
        else:
            xbmc.log('[photololitas] albuns_db directory not found. Trying scan_path fallback.', xbmc.LOGWARNING)

        if json_files:
            processed_from_db = True
            xbmc.log('[photololitas] Processing batch from albuns_db JSON files', xbmc.LOGINFO)
            for json_name in sorted(json_files):
                json_path = os.path.join(albums_db_path, json_name)
                try:
                    with open(json_path, 'r', encoding='utf-8') as json_file:
                        albums_dict = json.load(json_file)
                except Exception as exc:
                    failed_count += 1
                    xbmc.log(f'[photololitas] Failed to open {json_path}: {exc}', xbmc.LOGERROR)
                    continue

                for issue_name, issue_info in albums_dict.items():
                    if isinstance(issue_info, dict):
                        tasks.append((issue_name, issue_info, json_name))

        # Fallback: quando não houver base em albuns_db, varrer o scan_path e usar os .issue/.nfo locais.
        if not processed_from_db:
            scan_path = (addon.getSetting('scan_path') or '').strip()
            xbmc.log(f'[photololitas] Fallback enabled | scan_path={scan_path}', xbmc.LOGINFO)
            if not scan_path or not os.path.isdir(scan_path):
                kodi_notify_error('Base de dados não encontrada e scan_path inválido.')
                return

            for root, dirs, _ in os.walk(scan_path):
                for dir_name in dirs:
                    issue_file = os.path.join(root, dir_name, f'{dir_name}.issue')
                    if not os.path.exists(issue_file):
                        continue

                    if verbose_log:
                        xbmc.log(f'[photololitas] issue file found: {issue_file}', xbmc.LOGINFO)

                    issue_path = os.path.join(root, dir_name)
                    nfo_file = os.path.join(issue_path, f'{dir_name}.nfo')
                    issue_info = {
                        'm_number': '',
                        'm_title': dir_name,
                        'm_model': '',
                        'm_others': '',
                        'm_album': os.path.basename(root) if root else '',
                        'm_tags': '',
                        'm_date': '',
                        'm_year': '',
                        'm_plot': '',
                        'm_path': issue_path,
                        's_icon': '',
                        's_poster': '',
                        's_fanart': '',
                        's_banner': '',
                    }

                    if os.path.exists(nfo_file):
                        try:
                            tree = ET.parse(nfo_file)
                            root_element = tree.getroot()
                            issue_info['m_number'] = root_element.findtext('m_number') or ''
                            issue_info['m_title'] = root_element.findtext('m_title') or dir_name
                            issue_info['m_model'] = root_element.findtext('m_model') or ''
                            issue_info['m_others'] = root_element.findtext('m_others') or ''
                            issue_info['m_album'] = root_element.findtext('m_album') or issue_info['m_album']
                            issue_info['m_tags'] = root_element.findtext('m_tags') or ''
                            issue_info['m_date'] = root_element.findtext('m_date') or ''
                            issue_info['m_year'] = root_element.findtext('m_year') or ''
                            issue_info['m_plot'] = root_element.findtext('m_plot') or ''
                        except Exception as exc:
                            xbmc.log(f'[photololitas] Failed parsing issue NFO {nfo_file}: {exc}', xbmc.LOGERROR)

                    tasks.append((dir_name, issue_info, 'scan_path'))

        total_tasks = len(tasks)
        if total_tasks == 0:
            kodi_notify('Nenhum issue encontrado para atualizar.')
            xbmc.log('[photololitas] save_all_issues_nfo finished | no tasks found', xbmc.LOGWARNING)
            return

        progress = xbmcgui.DialogProgress()
        progress.create('Atualização em lote', f'Preparando atualização de {total_tasks} issues...')

        try:
            for idx, (issue_name, issue_info, source_name) in enumerate(tasks, start=1):
                percent = int((idx * 100) / total_tasks)
                progress.update(percent, f'Atualizando {idx}/{total_tasks}\n{issue_name}')

                if progress.iscanceled():
                    xbmc.log('[photololitas] Batch update canceled by user', xbmc.LOGWARNING)
                    break

                if not isinstance(issue_info, dict):
                    continue

                issue_path = (issue_info.get('m_path') or '').strip()
                if not issue_path:
                    skipped_count += 1
                    if verbose_log:
                        xbmc.log(f'[photololitas] Skipped issue without m_path | issue={issue_name} | source={source_name}', xbmc.LOGWARNING)
                    continue

                try:
                    self.save_issue_nfo(issue_info)
                    updated_count += 1
                    if verbose_log:
                        xbmc.log(f'[photololitas] NFO updated | issue={issue_name} | source={source_name} | path={issue_path}', xbmc.LOGINFO)
                except Exception as exc:
                    failed_count += 1
                    xbmc.log(
                        f'[photololitas] Failed saving NFO for issue "{issue_name}" from "{source_name}": {exc}',
                        xbmc.LOGERROR
                    )
        finally:
            progress.close()

        xbmc.log(f'[photololitas] save_all_issues_nfo finished | updated={updated_count} | skipped={skipped_count} | failed={failed_count}', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'Batch update',
            f'NFOs updated: {updated_count} | skipped: {skipped_count} | failed: {failed_count}',
            xbmcgui.NOTIFICATION_INFO,
            7000
        )

    def save_all_albums_nfo(self):
        addon = xbmcaddon.Addon()
        addon_data_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')
        verbose_log = (addon.getSetting('batch_update_verbose_log') or '').lower() == 'true'

        xbmc.log(f'[photololitas] save_all_albums_nfo started | profile={addon_data_path} | albuns_db={albums_db_path} | verbose_log={verbose_log}', xbmc.LOGINFO)

        if not os.path.isdir(albums_db_path):
            kodi_notify_error('Base de dados de álbuns não encontrada.')
            xbmc.log('[photololitas] save_all_albums_nfo finished | albuns_db directory not found', xbmc.LOGWARNING)
            return

        json_files = sorted([f for f in os.listdir(albums_db_path) if f.endswith('.json')])
        total_tasks = len(json_files)
        if total_tasks == 0:
            kodi_notify('Nenhum álbum encontrado para atualizar.')
            xbmc.log('[photololitas] save_all_albums_nfo finished | no album json found', xbmc.LOGWARNING)
            return

        updated_count = 0
        skipped_count = 0
        failed_count = 0

        progress = xbmcgui.DialogProgress()
        progress.create('Atualização em lote', f'Preparando atualização de {total_tasks} álbuns...')

        try:
            for idx, json_name in enumerate(json_files, start=1):
                percent = int((idx * 100) / total_tasks)
                progress.update(percent, f'Atualizando {idx}/{total_tasks}\n{json_name}')

                if progress.iscanceled():
                    xbmc.log('[photololitas] Album batch update canceled by user', xbmc.LOGWARNING)
                    break

                json_path = os.path.join(albums_db_path, json_name)
                try:
                    with open(json_path, 'r', encoding='utf-8') as json_file:
                        album_info = json.load(json_file)
                except Exception as exc:
                    failed_count += 1
                    xbmc.log(f'[photololitas] Failed to open album json "{json_path}": {exc}', xbmc.LOGERROR)
                    continue

                if not isinstance(album_info, dict):
                    skipped_count += 1
                    if verbose_log:
                        xbmc.log(f'[photololitas] Skipped non-dict album payload | file={json_name}', xbmc.LOGWARNING)
                    continue

                album_path = (album_info.get('m_path') or '').strip()
                if not album_path:
                    skipped_count += 1
                    if verbose_log:
                        xbmc.log(f'[photololitas] Skipped album without m_path | file={json_name}', xbmc.LOGWARNING)
                    continue

                try:
                    self.save_album_nfo(album_info)
                    updated_count += 1
                    if verbose_log:
                        xbmc.log(f'[photololitas] Album NFO updated | file={json_name} | path={album_path}', xbmc.LOGINFO)
                except Exception as exc:
                    failed_count += 1
                    xbmc.log(f'[photololitas] Failed saving album NFO for "{json_name}": {exc}', xbmc.LOGERROR)
        finally:
            progress.close()

        xbmc.log(f'[photololitas] save_all_albums_nfo finished | updated={updated_count} | skipped={skipped_count} | failed={failed_count}', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(
            'Batch update',
            f'Álbuns atualizados: {updated_count} | ignorados: {skipped_count} | falhas: {failed_count}',
            xbmcgui.NOTIFICATION_INFO,
            7000
        )

    def save_issue_nfo(self, album_info):

        # Crie o elemento root
        issue = ET.Element('issue')
        
        # Adicione subelementos ao root
        ET.SubElement(issue, 'm_number').text = album_info.get('m_number', '')
        ET.SubElement(issue, 'm_title').text = album_info.get('m_title', '')
        ET.SubElement(issue, 'm_model').text = album_info.get('m_model', '')
        ET.SubElement(issue, 'm_others').text = album_info.get('m_others', '')
        ET.SubElement(issue, 'm_album').text = album_info.get('m_album', '')
        ET.SubElement(issue, 'm_tags').text = album_info.get('m_tags', '')
        ET.SubElement(issue, 'm_date').text = album_info.get('m_date', '')
        ET.SubElement(issue, 'm_year').text = album_info.get('m_year', '')
        ET.SubElement(issue, 'm_plot').text = album_info.get('m_plot', '')

        # Obtenha o caminho da pasta e o nome da pasta
        m_path = album_info.get('m_path', '')
        if not m_path:
            raise ValueError("O campo 'm_path' não pode estar vazio.")
        
        folder_name = os.path.basename(os.path.normpath(m_path))
        nfo_path = os.path.join(m_path, f"{folder_name}.nfo")
            
        # Crie a árvore XML
        tree = ET.ElementTree(issue)
        
        # Converta para string com minidom para formatação bonita
        xml_str = ET.tostring(issue, encoding='utf-8')
        pretty_xml_str = minidom.parseString(xml_str).toprettyxml(indent="  ")
        
        # Salve o arquivo XML
        with open(nfo_path, 'w', encoding='utf-8') as f:
            f.write(pretty_xml_str)

    def save_artwork(self, image_path, album_info_key, album_info, albums_json_path, albums_dict, notification_message):
        """
        Apenas salva o caminho da arte no JSON, sem copiar o arquivo.
        """
        if not image_path:
            kodi_notify('Nenhuma imagem selecionada')
            return

        # Atualiza o dicionário com o novo caminho
        album_info[album_info_key] = image_path

        # Notifica e salva no JSON
        kodi_notify(notification_message)
        self.save_json(albums_json_path, albums_dict)
        
    def save_json(self, albums_json_path, albums_dict):
        # Salvar as alterações de volta ao JSON
        try:
            with open(albums_json_path, 'w', encoding='utf-8') as json_file:
                json.dump(albums_dict, json_file, ensure_ascii=False, indent=4)
                kodi_refresh_container()
        except Exception as e:
            xbmcgui.Dialog().notification('Edit Issue', f'Error saving changes: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 5000)
        
