# Games Center para Kodi

O **Games Center** é um addon para **Kodi** que transforma sua biblioteca em uma central para **jogos de PC e aplicativos externos**. Com ele, você pode organizar seus jogos, adicionar capas e fanarts, editar informações e iniciar tudo diretamente pela interface do Kodi.

Ideal para quem usa o Kodi como hub multimídia e quer reunir **filmes, séries, música e jogos** em um só lugar.

## O que o addon faz

O Games Center permite:

- **Adicionar e iniciar jogos/programas** direto pelo Kodi.
- **Organizar sua coleção** com categorias personalizadas.
- **Exibir artes** como poster, banner, thumb, fanart, icon e clearlogo.
- **Gerenciar metadados** como título, ano, gênero, desenvolvedor, classificação indicativa, número de jogadores e descrição.
- **Ler e gerar arquivos NFO**, facilitando a preservação e reaproveitamento das informações da biblioteca.
- **Buscar metadados e artes online** com suporte a serviços como **IGDB** e **SteamGridDB**.
- **Criar backups** das categorias e configurações do addon.

## Para quem ele é indicado

Este addon é voltado para usuários que:

- usam o **Kodi em PCs, HTPCs ou centrais multimídia**;
- querem abrir jogos do Windows, Linux ou macOS a partir do Kodi;
- desejam uma interface mais bonita e organizada para sua coleção de jogos;
- gostam de manter metadados e artes personalizados;
- querem integrar jogos locais ao restante da experiência do Kodi.

## Principais recursos

### 1. Biblioteca de jogos dentro do Kodi
Você pode apontar uma pasta com seus executáveis e deixar o addon localizar os jogos suportados automaticamente. O Games Center trabalha com arquivos como:

- `.exe`
- `.url`
- `.lnk`
- `.bat`

### 2. Organização por categorias
Crie categorias como, por exemplo:

- Ação
- Aventura
- Corrida
- RPG
- Multiplayer
- Favoritos
- Emuladores

As categorias podem ter seus próprios títulos, descrições e artes.

### 3. Artes personalizadas
O addon suporta vários tipos de imagens para deixar sua biblioteca visualmente atraente:

- Poster
- Banner
- Thumb
- Fanart
- Ícone
- Clearlogo

Também é possível preencher artes automaticamente para categorias a partir de uma pasta configurada.

### 4. Metadados completos
Cada jogo pode exibir e armazenar informações como:

- Título
- Ano
- Gênero
- Desenvolvedor
- Número de jogadores
- Classificação indicativa (ESRB)
- Nota/rating
- Descrição/plot

### 5. Suporte a NFO
Se você já usa arquivos **NFO**, o Games Center consegue aproveitar essas informações. Ele também pode salvar ou atualizar os NFOs da sua coleção para manter a biblioteca organizada.

### 6. Busca online de informações
Para enriquecer os itens da biblioteca, o addon oferece integração com:

- **IGDB**: para buscar metadados de jogos.
- **SteamGridDB**: para baixar artes e imagens personalizadas.

> Observação: alguns recursos online dependem de configuração prévia de chaves/API nas opções do addon.

### 7. Backup e restauração
Você pode gerar backup das categorias e das configurações principais do addon, o que facilita migrações, reinstalações ou recuperação da biblioteca.

## Como funciona na prática

De forma simples, o fluxo de uso costuma ser assim:

1. Instale o addon no Kodi.
2. Configure a pasta onde estão seus jogos/programas.
3. Opcionalmente, configure pastas de artes e NFOs.
4. Atualize a biblioteca pelo addon.
5. Edite metadados e imagens dos itens que desejar.
6. Organize tudo em categorias.
7. Inicie seus jogos diretamente pelo Kodi.

## Configurações disponíveis

O addon possui opções para configurar:

- pasta dos programas/jogos;
- pasta de posters;
- pasta de banners;
- pasta de fanarts;
- pasta de thumbs;
- pasta de clearlogos;
- pasta de NFOs;
- pasta de assets das categorias;
- pasta de backups;
- chave da API do SteamGridDB;
- credenciais do IGDB/Twitch.

## Benefícios para o usuário final

- **Centralização**: reúne jogos e mídia no mesmo ambiente.
- **Organização**: mantém a coleção separada por categorias e com visual padronizado.
- **Praticidade**: evita sair do Kodi para abrir jogos manualmente.
- **Personalização**: permite ajustar artes e metadados da forma que você preferir.
- **Preservação da biblioteca**: com NFOs e backups, fica mais fácil manter tudo salvo.

## Compatibilidade

O addon foi pensado para uso com **Kodi** e suporta o lançamento de jogos/aplicativos em diferentes sistemas, conforme a plataforma e o tipo de atalho/executável utilizado.

## Limitações importantes

Antes de usar, vale considerar que:

- a execução correta dos jogos depende do sistema operacional e da forma como o jogo foi instalado;
- alguns jogos podem exigir permissões, launchers externos ou parâmetros específicos;
- recursos online dependem de conexão com a internet e, em alguns casos, de APIs configuradas;
- a qualidade das artes e metadados pode variar conforme a disponibilidade nas fontes utilizadas.

## Exemplo de uso

Imagine um PC conectado à TV rodando Kodi. Com o Games Center, você pode:

- abrir sua biblioteca de jogos pelo sofá;
- navegar por categorias como “Favoritos” ou “Cooperativo Local”;
- visualizar capa, fanart e descrição de cada jogo;
- iniciar o jogo sem precisar sair da interface principal do Kodi.

## Resumo

O **Games Center** é uma solução para quem quer usar o **Kodi como central de jogos**, com foco em organização, apresentação visual e praticidade. Ele combina **launcher**, **gerenciamento de biblioteca**, **metadados**, **artes**, **NFO** e **backup** em um único addon.

Se a proposta é transformar o Kodi em uma experiência mais completa para entretenimento, este addon é uma ótima base para integrar seus jogos ao restante da sua biblioteca.
