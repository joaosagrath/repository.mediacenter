# -*- coding: utf-8 -*-
# Games Center - Backup & Restore helpers (categorias + settings)
# GPL-2.0-only
from typing import Dict, Optional, Callable
import os, json, time
import xbmc, xbmcgui, xbmcaddon, xbmcvfs

# contexto local (não importa main.py)
ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE    = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
BACKUPS_DIR = os.path.join(PROFILE, 'backups')

# utils que já existem no seu utils.py
from .utils import (
    load_categories, save_categories,
    get_setting_path, notify_ok, os_open, L, LF,
)

# --- chaves de settings que vamos salvar/restaurar (RAW, sem translatePath)
SETTINGS_KEYS = [
    'programs_dir', 'posters_dir', 'banners_dir', 'fanarts_dir',
    'thumbs_dir', 'clearlogo_dir', 'nfos_dir', 'cat_assets_dir',
    'backups_dir',
]

# ---------------------------------------------------------------------------------------
# Funções de Backup
# ---------------------------------------------------------------------------------------

def get_backups_root() -> str:
    """Retorna a pasta de backups configurada; se vazia/erro, usa a padrão do addon."""
    cfg = get_setting_path('backups_dir')
    root = cfg if cfg else BACKUPS_DIR
    # garante existência
    try:
        os.makedirs(root, exist_ok=True)
    except Exception:
        try:
            if not xbmcvfs.exists(root):
                xbmcvfs.mkdirs(root)
        except Exception:
            pass
    return root

def snapshot_settings_raw() -> Dict[str, str]:
    snap: Dict[str, str] = {}
    for k in SETTINGS_KEYS:
        try:
            snap[k] = ADDON.getSetting(k) or ''
        except Exception:
            snap[k] = ''
    return snap

def apply_settings_raw(snap: Dict[str, str]) -> None:
    for k in SETTINGS_KEYS:
        if k in snap:
            try:
                ADDON.setSetting(k, str(snap[k]))
            except Exception:
                pass

def export_backup_file() -> Optional[str]:
    """Cria backup JSON com categorias + settings RAW na pasta configurada (ou padrão)."""
    root = get_backups_root()
    payload = {
        'version': 1,
        'addon_id': ADDON_ID,
        'created': int(time.time()),
        'categories': load_categories(),
        'settings': snapshot_settings_raw(),
    }
    ts = time.strftime('%Y%m%d-%H%M%S')
    fname = f'backup-cats-settings-{ts}.json'
    dest = os.path.join(root, fname)
    try:
        with xbmcvfs.File(dest, 'w') as fh:
            fh.write(json.dumps(payload, ensure_ascii=False, indent=2))
        return dest
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30205, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)
        return None

def restore_backup_file(src_path: str, mode: str = 'replace') -> bool:
    """
    Restaura de backup JSON:
      - mode='replace': substitui categorias atuais pelas do backup
      - mode='merge': mescla por 'name' (atualiza existentes e adiciona novas)
    Sempre aplica settings RAW do backup.
    """
    try:
        with xbmcvfs.File(src_path, 'r') as fh:
            data = fh.read()
        obj = json.loads(data)
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30206, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)
        return False

    cats_backup = obj.get('categories') or []
    settings_backup = obj.get('settings') or {}

    # aplica settings
    apply_settings_raw(settings_backup)

    # aplica categorias
    if mode == 'replace':
        save_categories(cats_backup)
    else:
        # merge por 'name' (case-insensitive)
        current = load_categories()
        by_name = {c['name'].lower(): c for c in current if c.get('name')}
        for c in cats_backup:
            nm = (c.get('name') or '').lower()
            if not nm:
                continue
            by_name[nm] = {
                'name': c.get('name',''),
                'title': c.get('title','') or c.get('name',''),
                'plot': c.get('plot',''),
                'poster': c.get('poster',''),
                'fanart': c.get('fanart',''),
                'icon': c.get('icon',''),
                'clearlogo': c.get('clearlogo',''),
                'hide_from_widgets': bool(c.get('hide_from_widgets', False)),
            }
        merged = list(by_name.values())
        save_categories(merged)

    return True

def backup_restore_dialog(update_all_nfos_func: Optional[Callable[[bool], tuple]] = None):
    """
    Caixa de diálogo:
      - Fazer backup agora  (antes: atualizar NFOs se callback fornecido)
      - Restaurar de arquivo…
      - Abrir pasta de backups
    """
    while True:
        choice = xbmcgui.Dialog().select(L(30200), [
            L(30201),
            L(30202),
            L(30203),
            L(30204)
        ])
        if choice in (-1, 3):
            break

        if choice == 0:
            # 1) Atualiza NFOs se callback foi fornecido
            resumo = None
            if callable(update_all_nfos_func):
                total, ok, fail, canceled, _ = update_all_nfos_func(True)
                resumo = "\n".join([
                    LF(30134, total=total),
                    LF(30135, ok=ok),
                    LF(30136, fail=fail)
                ])
                if canceled:
                    resumo += "\n" + L(30214)

            # 2) Faz o backup
            dest = export_backup_file()
            if dest:
                if resumo:
                    xbmcgui.Dialog().ok(ADDON_NAME, f"{resumo}\n\n" + LF(30207, dest=dest))
                else:
                    xbmcgui.Dialog().ok(ADDON_NAME, LF(30207, dest=dest))

        elif choice == 1:
            # escolher arquivo .json
            src = xbmcgui.Dialog().browse(
                1, L(30208), 'files', '.json', False, False, get_backups_root()
            )
            if not src:
                continue
            mode_sel = xbmcgui.Dialog().select(L(30209), [L(30210), L(30211)])
            if mode_sel == -1:
                continue
            mode = 'replace' if mode_sel == 0 else 'merge'
            ok = restore_backup_file(src, mode)
            if ok:
                notify_ok(L(30212))
                xbmc.executebuiltin('Container.Refresh')

        elif choice == 2:
            path = get_backups_root()
            try:
                os_open(path)
            except Exception:
                xbmcgui.Dialog().ok(ADDON_NAME, LF(30213, path=path))
