# -*- coding: utf-8 -*-
# Games Center - __init__.py
# GPL-2.0-only