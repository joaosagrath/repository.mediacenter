# -*- coding: utf-8 -*-
# Games Center - Kodi utilities (helpers, IO, validation, formatting)
# Copyright (C) 2024-2025 Sagrath (joaosagrath)
# Email: joaosagrath@gmail.com
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 2 ONLY, as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.

from typing import List, Dict, Optional
import os, sys, json, time, re, urllib.parse, unicodedata
import xbmc, xbmcgui, xbmcaddon, xbmcvfs

# Contexto do Add-on (recomputa aqui para evitar dependência circular com main.py)
ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE    = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))


# ---------------------------------------------------------------------------------------
# Localization helpers
# ---------------------------------------------------------------------------------------
def L(string_id: int) -> str:
    """Return a localized string from strings.po by numeric id."""
    try:
        return ADDON.getLocalizedString(int(string_id))
    except Exception:
        return str(string_id)

def LF(string_id: int, **kwargs) -> str:
    """Localized string + .format(**kwargs) convenience."""
    try:
        return L(string_id).format(**kwargs)
    except Exception:
        return L(string_id)

# Paths de armazenamento (devem coincidir com main.py)
STORAGE         = os.path.join(PROFILE, 'programs.json')
CATEGORIES_PATH = os.path.join(PROFILE, 'categories.json')

# Extensões aceitas
# IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.gif')
IMAGE_EXTS = '.jpg|.jpeg|.png|.bmp|.gif|.webp|.ico'
NFO_EXTS   = ('.nfo', '.xml')
EXEC_EXTS  = ('.exe', '.url', '.lnk', '.bat')

# ---------------------------------------------------------------------------------------
# Utils  (extraídos de main.py)
# ---------------------------------------------------------------------------------------
def ensure_dirs() -> None:
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)

def _norm(s: str) -> str:
    """Normaliza para comparação: strip + casefold."""
    return (s or '').strip().casefold()

def _sort_key_title(item: dict) -> str:
    """Ordena alfabeticamente por título (fallback: nome do arquivo), ignorando acentos/maiúsculas."""
    title = item.get('title') or os.path.splitext(os.path.basename(item.get('path','')))[0]
    norm = unicodedata.normalize('NFKD', str(title))
    no_accents = ''.join(ch for ch in norm if not unicodedata.combining(ch))
    return no_accents.casefold()

def _iter_cat_refs(lst) -> list:
    """Converte referências de categorias do item para strings normalizadas.
       Aceita strings ou dicts {'name':..., 'title':...} legados."""
    out = []
    for c in (lst or []):
        if isinstance(c, dict):
            out.append(_norm(c.get('name') or c.get('title') or ''))
        else:
            out.append(_norm(str(c)))
    return out

def load_programs() -> List[Dict]:
    ensure_dirs()
    if not xbmcvfs.exists(STORAGE):
        return []
    try:
        with xbmcvfs.File(STORAGE, 'r') as fh:
            data = fh.read()
        raw = json.loads(data) if data else []
        if not isinstance(raw, list):
            return []
        # normalização mínima
        out = []
        seen = set()
        for it in raw:
            if not isinstance(it, dict): 
                continue
            path = str(it.get('path') or '').strip()
            if not path or path in seen:
                continue
            seen.add(path)
            it.setdefault('title', '')
            it.setdefault('year', '')
            it.setdefault('plot', '')
            it.setdefault('genre', '')
            it.setdefault('developer', '')
            it.setdefault('nplayers', '')
            it.setdefault('esrb', '')
            it.setdefault('rating', '')
            it.setdefault('thumb', '')
            it.setdefault('poster', '')
            it.setdefault('banner', '')
            it.setdefault('fanart', '')
            it.setdefault('clearlogo', '')
            it.setdefault('nfo_path', '')
            it.setdefault('categories', [])
            it.setdefault('lastplayed', 0)
            out.append(it)
        return out
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] load_programs error: {e}", xbmc.LOGERROR)
        return []

def save_programs(items: List[Dict]) -> None:
    try:
        ensure_dirs()
        with xbmcvfs.File(STORAGE, 'w') as fh:
            fh.write(json.dumps(items, ensure_ascii=False, indent=2))
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] save_programs error: {e}", xbmc.LOGERROR)

def load_categories() -> List[Dict]:
    ensure_dirs()
    if not xbmcvfs.exists(CATEGORIES_PATH):
        return []
    try:
        with xbmcvfs.File(CATEGORIES_PATH, 'r') as fh:
            data = fh.read()
        raw = json.loads(data) if data else []
    except Exception:
        return []

    cats: List[Dict] = []

    def _mk(name: str, title: Optional[str] = None) -> Dict:
        n = (name or '').strip()
        t = (title if title is not None else n).strip()
        return {
            'name': n,
            'title': t or n,
            'plot': '',
            'poster': '',
            'fanart': '',
            'icon': '',
            'clearlogo': '',
            'hide_from_widgets': False,
        }

    if isinstance(raw, list):
        for x in raw:
            if isinstance(x, str):
                cats.append(_mk(x))
            elif isinstance(x, dict):
                name  = str(x.get('name') or x.get('title') or x.get('Name') or '').strip()
                title = str(x.get('title') or x.get('Title') or name).strip()
                item  = _mk(name or title, title)

                for k in ('plot','poster','fanart','icon','clearlogo'):
                    if x.get(k) is not None:
                        item[k] = str(x.get(k) or '')

                if 'hide_from_widgets' in x:
                    item['hide_from_widgets'] = bool(x.get('hide_from_widgets'))

                cats.append(item)

    # dedup por name + garantir chaves
    out, seen = [], set()
    for c in cats:
        if not c.get('name'):
            continue
        key = c['name'].lower()
        if key in seen:
            continue
        seen.add(key)

        c.setdefault('title','')
        c.setdefault('plot','')
        c.setdefault('poster','')
        c.setdefault('fanart','')
        c.setdefault('icon','')
        c.setdefault('clearlogo','')
        c.setdefault('hide_from_widgets', False)
        c['hide_from_widgets'] = bool(c['hide_from_widgets'])

        out.append(c)
    return out

def save_categories(cats: List[Dict]) -> None:
    try:
        ensure_dirs()
        # normalizar saída
        norm = []
        for c in cats:
            norm.append({
                'name': str(c.get('name') or '').strip(),
                'title': str(c.get('title') or c.get('name') or '').strip(),
                'plot': str(c.get('plot') or ''),
                'poster': str(c.get('poster') or ''),
                'fanart': str(c.get('fanart') or ''),
                'icon': str(c.get('icon') or ''),
                'clearlogo': str(c.get('clearlogo') or ''),
                'hide_from_widgets': bool(c.get('hide_from_widgets', False)),
            })
        with xbmcvfs.File(CATEGORIES_PATH, 'w') as fh:
            fh.write(json.dumps(norm, ensure_ascii=False, indent=2))
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] save_categories error: {e}", xbmc.LOGERROR)

# build_url fica no main.py (depende de BASE_URL setado em tempo de execução)

def os_open(path: str) -> None:
    try:
        if sys.platform.startswith('win'):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform.startswith('darwin'):
            import subprocess
            subprocess.Popen(['open', path])
        else:
            import subprocess
            subprocess.Popen(['xdg-open', path])
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, LF(30004, path=path, error=str(e)))

def notify_ok(msg: str, t: int = 3000):
    xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, t)

def yesno_compat(heading, line1, line2='', line3='', nolabel=None, yeslabel=None):
    dlg = xbmcgui.Dialog()
    try:
        # Tentativa 1: assinatura completa com labels e autoclose explícito
        return dlg.yesno(heading, line1, line2, line3, nolabel, yeslabel, 0)
    except TypeError:
        try:
            # Tentativa 2: sem labels (usa rótulos padrão/localizados)
            return dlg.yesno(heading, line1, line2, line3)
        except TypeError:
            # Tentativa 3: fallback mínimo
            return dlg.yesno(heading, line1)

def preview_image(title: str, url: str):
    """
    Abre um select de 1 item com useDetails=True para renderizar a imagem remota.
    O retorno do select é ignorado; serve como tela de pré-visualização.
    """
    if not url:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30005), xbmcgui.NOTIFICATION_INFO, 3000)
        return
    li = xbmcgui.ListItem(label=title, label2=url)
    li.setArt({'icon': url, 'thumb': url, 'poster': url, 'fanart': url})
    xbmcgui.Dialog().select(LF(30006, title=title), [li], useDetails=True)

def _log(msg: str, level=xbmc.LOGINFO):
    try:
        xbmc.log(f'[{ADDON_ID}][IGDB] {msg}', level=level)
    except Exception:
        pass

def keyboard_input(title: str, default: str = '') -> Optional[str]:
    return xbmcgui.Dialog().input(title, defaultt=default)

def ask_image(title: str, default_path: str = '') -> Optional[str]:
    return xbmcgui.Dialog().browse(1, title, 'pictures', IMAGE_EXTS, True, False, default_path)

def get_setting_path(key: str) -> str:
    """Lê um setting de pasta e traduz para o SO; vazio -> ''. """
    try:
        p = ADDON.getSetting(key) or ''
    except Exception:
        p = ''
    return xbmcvfs.translatePath(p) if p else ''

def safe_float(v) -> Optional[float]:
    try:
        return float(v)
    except Exception:
        return None

def is_allowed_exec(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in EXEC_EXTS

def param_to_path(v: str) -> str:
    """Decodifica o 'path' vindo pela query (desfaz dupla codificação se houver)."""
    v = v or ''
    try:
        v = urllib.parse.unquote(v)
        v = urllib.parse.unquote(v)
    except Exception:
        pass
    return v

def find_item_index_by_path(item_path: str) -> int:
    items = load_programs()
    for i, it in enumerate(items):
        if it.get('path','') == item_path:
            return i
    return -1
  
# edit_program_by_path / remove_program_by_path / manage_item_categories_by_path / remove_from_category_by_path
# permanecem no main.py para evitar dependência circular.
