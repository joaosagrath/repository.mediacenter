# -*- coding: utf-8 -*-
# Games Center - Kodi main module (launchers, categories, NFO, widgets, backup/restore)
# Copyright (C) 2024-2025 Sagrath (joaosagrath)
# Email: joaosagrath@gmail.com
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 2 ONLY, as
# published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with
# this program. If not, see <https://www.gnu.org/licenses/>.


"""
Games Center for Kodi — main module (migrated from addon.py)

Recursos:
- Varredura recursiva (executáveis/artes/NFOs)
- Cleanup (remove paths inexistentes + dedup por path)
- NFO: leitura prioritária + gravação (no local de origem quando conhecido, fallback por estrutura)
- Exec whitelist: .exe, .url, .lnk, .bat
- Edição com submenus (Metadados / Artes) e miniaturas
- Sort methods: Título, Gênero, Ano
- Categorias: criar/renomear/excluir; navegar por categoria; atribuir itens; artes/metadados por categoria
- Auto-preenchimento de categorias a partir de pasta configurada (poster/fanart/icon/clearlogo + title.txt/plot.txt/NFO)
- “Todos os Itens” (UI) mostra APENAS itens sem categoria e só aparece se eles existirem
- Rota exclusiva para widgets: lista TODOS os itens, ignorando categorias

Estrutura:
- Este arquivo é carregado por addon.py (raiz) via resources.main.Main().run_plugin(sys.argv)
"""

import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import xbmcplugin

import os
import sys
import time
import unicodedata
import urllib.parse
import xml.etree.ElementTree as ET
from typing import List, Dict, Tuple, Optional

# ---------------------------------------------------------------------------------------
# Utils (migrado para resources/utils.py)
# ---------------------------------------------------------------------------------------
from .utils import *

# ---------------------------------------------------------------------------------------
# Backups (migrado para resources/backups.py)
# ---------------------------------------------------------------------------------------
from .backups import *

# ---------------------------------------------------------------------------------------
# NFO's (migrado para resources/nfo.py)
# ---------------------------------------------------------------------------------------
from .nfo import *

# ---------------------------------------------------------------------------------------
# Categoriess (migrado para resources/categories.py)
# ---------------------------------------------------------------------------------------
from .categories import *

# ---------------------------------------------------------------------------------------
# Contexto Kodi / Add-on
# ---------------------------------------------------------------------------------------
ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE    = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# IMPORTANTE: serão atualizados dinamicamente pelo loader (Main.run_plugin)
HANDLE   = -1
BASE_URL = ''

# Armazenamento
STORAGE         = os.path.join(PROFILE, 'programs.json')
CATEGORIES_PATH = os.path.join(PROFILE, 'categories.json')

# Backup
BACKUPS_DIR = os.path.join(PROFILE, 'backups')

# Extensões
IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.gif', '.ico')
NFO_EXTS   = ('.nfo', '.xml')
EXEC_EXTS  = ('.exe', '.url', '.lnk', '.bat')
 
def build_url(params: Dict[str, str]) -> str:
    return f"{BASE_URL}?{urllib.parse.urlencode(params)}"

def _nc(p: str) -> str:
    """Normaliza caminho para comparação: absoluto + normpath + case-insensitive em Win."""
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(p or '')))
    except Exception:
        return (p or '').lower()

def _norm(s: str) -> str:
    """Normaliza para comparação: strip + casefold."""
    return (s or '').strip().casefold()

def _sort_key_title(item: dict) -> str:
    """Ordena alfabeticamente por título (fallback: nome do arquivo), ignorando acentos/maiúsculas."""
    title = item.get('title') or os.path.splitext(os.path.basename(item.get('path','')))[0]
    norm = unicodedata.normalize('NFKD', str(title))
    no_accents = ''.join(ch for ch in norm if not unicodedata.combining(ch))
    return no_accents.casefold()

def _iter_cat_refs(lst) -> list:
    """Converte referências de categorias do item para strings normalizadas.
       Aceita strings ou dicts {'name':..., 'title':...} legados."""
    out = []
    for c in (lst or []):
        if isinstance(c, dict):
            out.append(_norm(c.get('name') or c.get('title') or ''))
        else:
            out.append(_norm(str(c)))
    return out

# ---------------------------------------------------------------------------------------
# Wrappers de ações por caminho (path→index) — usados pelo router/menus de contexto
# ---------------------------------------------------------------------------------------

def edit_program_by_path(item_path: str) -> None:
    idx = find_item_index_by_path(item_path)
    if idx < 0:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30000), xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    edit_program(idx)

def remove_program_by_path(item_path: str) -> None:
    idx = find_item_index_by_path(item_path)
    if idx < 0:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30000), xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    remove_program(idx)

def manage_item_categories_by_path(item_path: str) -> None:
    idx = find_item_index_by_path(item_path)
    if idx < 0:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30000), xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    manage_item_categories(idx)

def remove_from_category_by_path(item_path: str, cat: str) -> None:
    idx = find_item_index_by_path(item_path)
    if idx < 0:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30000), xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    remove_from_category(idx, cat)

# ---------------------------------------------------------------------------------------
# Funções de Backup
# ---------------------------------------------------------------------------------------
def _ensure_backups_dir() -> str:
    return get_backups_root()

# chaves de settings que vamos salvar/restaurar (RAW, sem translatePath)
SETTINGS_KEYS = [
    'programs_dir', 'posters_dir', 'banners_dir', 'fanarts_dir',
    'thumbs_dir', 'clearlogo_dir', 'nfos_dir', 'cat_assets_dir',
    'backups_dir', 
]

# ---------------------------------------------------------------------------------------
# Varreduras recursivas
# ---------------------------------------------------------------------------------------
def iter_files_recursive(root_dir: str) -> List[str]:
    out: List[str] = []
    if not root_dir:
        return out
    try:
        for r, _dirs, files in os.walk(root_dir):
            for name in files:
                out.append(os.path.join(r, name))
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30001, root_dir=root_dir, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 4000)
    return out

def build_art_index_recursive(art_root: str) -> Dict[str, str]:
    index: Dict[str, str] = {}
    if not art_root:
        return index
    try:
        for r, _dirs, files in os.walk(art_root):
            for name in files:
                if not name.lower().endswith(IMAGE_EXTS):
                    continue
                stem = os.path.splitext(name)[0].lower()
                full = os.path.join(r, name)
                if stem not in index:
                    index[stem] = full
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30002, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 4000)
    return index

def build_nfo_index_recursive(nfo_root: str) -> Dict[str, str]:
    index: Dict[str, str] = {}
    if not nfo_root:
        return index
    try:
        for r, _dirs, files in os.walk(nfo_root):
            for name in files:
                if not name.lower().endswith(NFO_EXTS):
                    continue
                stem = os.path.splitext(name)[0].lower()
                full = os.path.join(r, name)
                if stem not in index:
                    index[stem] = full
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30003, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 4000)
    return index

# ---------------------------------------------------------------------------------------
# UI: Helpers
# ---------------------------------------------------------------------------------------
def _get_program_label(item, use_name_fallback=False):
    if use_name_fallback:
        return (
            item.get('title')
            or item.get('name')
            or os.path.basename(item.get('path', ''))
            or L(30008)
        )
    return item.get('title') or os.path.basename(item.get('path', ''))

def _build_program_info(item, label, use_description_fallback=False, rating_mode='tryfloat'):
    plot = item.get('plot') or ''
    if use_description_fallback:
        plot = item.get('plot') or item.get('description', '') or ''

    info = {
        'title': label,
        'year': int(item.get('year')) if str(item.get('year')).isdigit() else 0,
        'plot': plot,
    }

    if item.get('genre'):
        info['genre'] = item['genre']

    if item.get('rating'):
        if rating_mode == 'safe':
            info['rating'] = safe_float(item['rating'])
        else:
            try:
                info['rating'] = float(item.get('rating'))
            except Exception:
                pass

    if item.get('developer'):
        info['studio'] = [item['developer']]

    return info

def _build_program_art(item):
    art = {}
    if item.get('thumb'):
        art['thumb'] = item['thumb']
    if item.get('poster'):
        art['poster'] = item['poster']
    if item.get('banner'):
        art['banner'] = item['banner']
    if item.get('fanart'):
        art['fanart'] = item['fanart']
    if item.get('clearlogo'):
        art['clearlogo'] = item['clearlogo']
    return art

def _apply_program_art_and_props(li, item, is_playable=None):
    art = _build_program_art(item)
    if art:
        li.setArt(art)

    if item.get('esrb'):
        li.setProperty('esrb', item['esrb'])
    if item.get('nplayers'):
        li.setProperty('nplayers', item['nplayers'])

    if is_playable is not None:
        li.setProperty('IsPlayable', 'true' if is_playable else 'false')

def _create_program_listitem(
    item,
    use_name_fallback=False,
    use_description_fallback=False,
    rating_mode='tryfloat',
    is_playable=None
):
    label = _get_program_label(item, use_name_fallback=use_name_fallback)
    li = xbmcgui.ListItem(label=label)
    li.setInfo(
        'video',
        _build_program_info(
            item,
            label,
            use_description_fallback=use_description_fallback,
            rating_mode=rating_mode
        )
    )
    _apply_program_art_and_props(li, item, is_playable=is_playable)
    path_q = urllib.parse.quote(item.get('path', ''))
    return li, path_q

def _finish_directory(content):
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_GENRE)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
    xbmcplugin.endOfDirectory(HANDLE)

def _add_uncategorized_items_to_categories_view(uncategorized, common_cm):
    """
    Adiciona itens sem categoria na tela principal.
    Mantém o comportamento atual (inclusive o Add Category duplicado no menu de contexto).
    """
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)

    for it in uncategorized:
        li, path_q = _create_program_listitem(
            it,
            use_name_fallback=True,
            use_description_fallback=True,
            rating_mode='tryfloat',
            is_playable=True
        )

        cm = [
            (L(30010), f'RunPlugin({build_url({"action":"manage_categories","path": path_q})})'),
            (L(30011), f'RunPlugin({build_url({"action":"edit","path": path_q})})'),
            (L(30012), f'RunPlugin({build_url({"action":"remove","path": path_q})})'),
            (L(30013), f'RunPlugin({build_url({"action":"add_category"})})'),
        ]

        # Mantido exatamente como no original:
        # common_cm já contém add_category, então continua duplicado aqui.
        li.addContextMenuItems(common_cm + cm, replaceItems=False)

        url = build_url({'action': 'launch', 'path': path_q})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

def _add_category_folder_item(category_data):
    label = category_data.get('title') or category_data['name']
    li = xbmcgui.ListItem(label=label)
    li.setInfo('video', {'title': label, 'plot': category_data.get('plot', '')})

    art = {}
    if category_data.get('icon'):
        art['icon'] = category_data['icon']
    if category_data.get('poster'):
        art['poster'] = category_data['poster']
    if category_data.get('fanart'):
        art['fanart'] = category_data['fanart']
    if category_data.get('clearlogo'):
        art['clearlogo'] = category_data['clearlogo']
    if art:
        li.setArt(art)

    hidden = bool(category_data.get('hide_from_widgets', False))
    toggle_label = L(30017) if hidden else L(30018)

    cm = [
        (L(30009), f'RunPlugin({build_url({"action":"update_from_settings"})})'),
        (L(30013), f'RunPlugin({build_url({"action":"add_category"})})'),
        (L(30014), f'RunPlugin({build_url({"action":"edit_category","name": category_data["name"]})})'),
        (L(30015), f'RunPlugin({build_url({"action":"rename_category","name": category_data["name"]})})'),
        (L(30016), f'RunPlugin({build_url({"action":"delete_category","name": category_data["name"]})})'),
        (toggle_label, f'RunPlugin({build_url({"action":"toggle_category_widget","name": category_data["name"]})})'),
        (L(30019), f'RunPlugin({build_url({"action":"backup_restore"})})'),
    ]
    li.addContextMenuItems(cm, replaceItems=False)

    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_url({'action': 'browse_category', 'cat': category_data['name']}),
        li,
        isFolder=True
    )

# ---------------------------------------------------------------------------------------
# UI: Listagens
# ---------------------------------------------------------------------------------------
def show_categories() -> None:
    """Tela inicial: lista categorias (com artes/metadados) e depois itens sem categoria (não agrupados)."""
    cats = sorted(load_categories(), key=lambda c: (c.get('title') or c['name']).lower())
    items_all = load_programs()

    uncategorized = [it for it in items_all if not (it.get('categories') and len(it.get('categories')) > 0)]
    has_uncategorized = len(uncategorized) > 0

    common_cm = [
        (L(30009), f'RunPlugin({build_url({"action":"update_from_settings"})})'),
        (L(30013), f'RunPlugin({build_url({"action":"add_category"})})'),
        (L(30019), f'RunPlugin({build_url({"action":"backup_restore"})})'),
    ]

    if not cats:
        if not has_uncategorized:
            li = xbmcgui.ListItem(label=L(30020))
            li.addContextMenuItems(common_cm, replaceItems=False)
            xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'noop'}), li, isFolder=False)
        else:
            _add_uncategorized_items_to_categories_view(uncategorized, common_cm)
    else:
        # 1) adiciona as pastas de categorias
        for c in cats:
            _add_category_folder_item(c)

        # 2) em seguida, adiciona os itens sem categoria (sem pasta)
        if has_uncategorized:
            _add_uncategorized_items_to_categories_view(uncategorized, common_cm)

    _finish_directory('videos')

def show_programs(category: str = '') -> None:
    items = load_programs()

    if category:
        # Mostra apenas itens que pertencem à categoria escolhida
        items = [it for it in items if any(category.lower() == c.lower() for c in (it.get('categories') or []))]
    else:
        # "Todos os Itens" (UI): SOMENTE itens sem categoria
        items = [it for it in items if not (it.get('categories') and len(it.get('categories')) > 0)]

    # Ordenação padrão: último executado primeiro
    items.sort(key=lambda x: int(x.get('lastplayed') or 0), reverse=True)

    common_cm = [
        (L(30009), f'RunPlugin({build_url({"action":"update_from_settings"})})'),
        (L(30019), f'RunPlugin({build_url({"action":"backup_restore"})})'),
    ]

    if not items:
        label = L(30021) if not category else LF(30022, category=category)
        li = xbmcgui.ListItem(label=label)
        li.addContextMenuItems(
            common_cm + [(L(30010), f'RunPlugin({build_url({"action":"noop"})})')],
            replaceItems=False
        )
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'noop'}), li, isFolder=False)
    else:
        for p in items:
            li, path_q = _create_program_listitem(
                p,
                use_name_fallback=False,
                use_description_fallback=False,
                rating_mode='safe',
                is_playable=True
            )

            cm = list(common_cm) + [
                (L(30010), f'RunPlugin({build_url({"action":"manage_categories","path": path_q})})'),
                (L(30011), f'RunPlugin({build_url({"action":"edit", "path": path_q})})'),
                (L(30012), f'RunPlugin({build_url({"action":"remove", "path": path_q})})'),
            ]

            if category and any(category.lower() == c.lower() for c in (p.get('categories') or [])):
                cm.append(
                    (L(30023), f'RunPlugin({build_url({"action":"remove_from_category","path": path_q, "cat": category})})')
                )

            li.addContextMenuItems(cm, replaceItems=False)

            url = build_url({'action': 'launch', 'path': path_q})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    _finish_directory('videos')

def show_all_items_widget() -> None:
    """Rota exclusiva para widgets: lista TODOS os itens (ignorando categorias),
       mas oculta itens que pertençam a categorias marcadas como 'hide_from_widgets'."""
    items = load_programs()

    cats = load_categories()
    hidden_names = {_norm(c.get('name')) for c in cats if c.get('name') and bool(c.get('hide_from_widgets', False))}
    hidden_titles = {_norm(c.get('title') or c.get('name')) for c in cats if bool(c.get('hide_from_widgets', False))}
    hidden_any = hidden_names | hidden_titles

    # Filtra itens: se QUALQUER referência do item bater (por name OU title), oculta
    def is_visible_in_widget(it: Dict) -> bool:
        refs = _iter_cat_refs(it.get('categories'))
        return not any(ref in hidden_any for ref in refs)

    items = [it for it in items if is_visible_in_widget(it)]

    # Widgets em ordem alfabética por título
    items.sort(key=_sort_key_title)

    if not items:
        li = xbmcgui.ListItem(label=L(30024))
        li.setProperty('IsPlayable', 'false')
        li.addContextMenuItems(
            [(L(30019), f'RunPlugin({build_url({"action":"backup_restore"})})')],
            replaceItems=True
        )
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'action': 'noop'}), li, isFolder=False)
    else:
        for p in items:
            li, path_q = _create_program_listitem(
                p,
                use_name_fallback=False,
                use_description_fallback=False,
                rating_mode='tryfloat',
                is_playable=True
            )

            cm = [
                (L(30010), f'RunPlugin({build_url({"action":"manage_categories","path": path_q})})'),
                (L(30011), f'RunPlugin({build_url({"action":"edit", "path": path_q})})'),
                (L(30012), f'RunPlugin({build_url({"action":"remove", "path": path_q})})'),
            ]
            li.addContextMenuItems(cm, replaceItems=True)

            url = build_url({'action': 'launch', 'path': path_q})
            xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)

    _finish_directory('files')

# ---------------------------------------------------------------------------------------
# CRUD de Itens
# ---------------------------------------------------------------------------------------

def edit_program(index: int) -> None:
    items = load_programs()
    if index < 0 or index >= len(items):
        return
    p = items[index]

    def _show(v: str) -> str:
        v = '' if v is None else str(v)
        return v if v.strip() else L(30007)

    def _img(v: str) -> str:
        return v if (v and os.path.isfile(v)) else 'DefaultAddonNone.png'

    # ----- submenus -----
    def edit_metadata_loop():
        IDX_TITLE     = 0
        IDX_EXEC      = 1
        IDX_YEAR      = 2
        IDX_PLOT      = 3
        IDX_DEV       = 4
        IDX_GENRE     = 5
        IDX_NPLAYERS  = 6
        IDX_ESRB      = 7
        IDX_RATING    = 8
        IDX_CATS      = 9
        IDX_SAVE_NFO  = 10
        IDX_BACK      = 11

        while True:
            nfo_path_label = _show(p.get('nfo_path',''))
            options_meta = [
                LF(30037, value=_show(p.get('title',''))),
                LF(30038, value=_show(p.get('path',''))),
                LF(30039, value=_show(p.get('year',''))),
                LF(30040, value=_show(p.get('plot',''))),
                LF(30041, value=_show(p.get('developer',''))),
                LF(30042, value=_show(p.get('genre',''))),
                LF(30043, value=_show(p.get('nplayers',''))),
                LF(30044, value=_show(p.get('esrb',''))),
                LF(30045, value=_show(p.get('rating',''))),
                LF(30046, value=_show(', '.join(p.get('categories') or []))),
                L(30035),
                LF(30036, path=nfo_path_label),
                L(30034)
            ]
            sel = xbmcgui.Dialog().select(L(30030), options_meta)
            if sel in (-1, IDX_BACK+1):  # +1 por conta da linha informativa do NFO
                break

            changed = False
            if sel == IDX_TITLE:
                val = keyboard_input(L(30047), default=p.get('title',''))
                if val: p['title'] = val; changed = True

            elif sel == IDX_EXEC:
                new_path = xbmcgui.Dialog().browse(1, L(30048), 'files', '|'.join(EXEC_EXTS), False, False, p.get('path',''))
                if new_path:
                    if is_allowed_exec(new_path):
                        p['path'] = new_path; changed = True
                    else:
                        xbmcgui.Dialog().notification(ADDON_NAME, L(30049), xbmcgui.NOTIFICATION_ERROR, 4500)

            elif sel == IDX_YEAR:
                # teclado numérico é mais prático pro ano
                val = xbmcgui.Dialog().numeric(0, L(30050), defaultt=str(p.get('year','') or ''))
                if val != '':
                    p['year'] = val
                    changed = True


            elif sel == IDX_PLOT:
                val = keyboard_input(L(30051), default=p.get('plot',''))
                if val is not None: p['plot'] = val; changed = True

            elif sel == IDX_DEV:
                val = keyboard_input(L(30052), default=p.get('developer',''))
                if val is not None: p['developer'] = val; changed = True

            elif sel == IDX_GENRE:
                val = keyboard_input(L(30053), default=p.get('genre',''))
                if val is not None: p['genre'] = val; changed = True

            elif sel == IDX_NPLAYERS:
                # Lista fixa para nº de jogadores
                NPLAYERS_OPTIONS = [
                    "1 Player",
                    "1-2 Players",
                    "1-4 Players",
                    "Multiplyer",
                    "Online",
                    "(Limpar)"
                ]
                pick = xbmcgui.Dialog().select(L(30054), NPLAYERS_OPTIONS)
                if pick == -1:
                    pass
                elif pick == len(NPLAYERS_OPTIONS) - 1:
                    p['nplayers'] = ''
                    changed = True
                else:
                    p['nplayers'] = NPLAYERS_OPTIONS[pick]
                    changed = True

            elif sel == IDX_ESRB:
                # Lista fixa de classificações ESRB
                ESRB_OPTIONS = [
                    ("E",    "Everyone"),
                    ("E10+", "Everyone 10+"),
                    ("T",    "Teen"),
                    ("M",    "Mature 17+"),
                    ("AO",   "Adults Only"),
                    ("RP",   "Rating Pending"),
                ]
                labels = [f"{c} ({t})" for c, t in ESRB_OPTIONS] + [L(30055)]

                pick = xbmcgui.Dialog().select(L(30056), labels)
                if pick == -1:
                    pass  # usuário cancelou
                elif pick == len(labels) - 1:
                    # limpar o campo
                    p['esrb'] = ''
                    changed = True
                else:
                    # salva como "CÓDIGO (Texto)" para ficar legível na UI
                    p['esrb'] = labels[pick]
                    changed = True

            elif sel == IDX_RATING:
                # Nota (rating) de 0 a 10
                RATING_OPTIONS = [str(i) for i in range(0, 11)] + [L(30055)]
                pick = xbmcgui.Dialog().select(L(30057), RATING_OPTIONS)
                if pick == -1:
                    pass
                elif pick == len(RATING_OPTIONS) - 1:
                    p['rating'] = ''
                    changed = True
                else:
                    p['rating'] = RATING_OPTIONS[pick]  # salva como string ("8")
                    changed = True

            elif sel == IDX_CATS:
                manage_item_categories(index)
                # re-carrega item que pode ter sido alterado
                items_new = load_programs()
                p.update(items_new[index])
                continue

            elif sel == IDX_SAVE_NFO:
                dest = save_item_nfo(p)
                if dest:
                    notify_ok(L(30058))

            if changed:
                items[index] = p
                save_programs(items)
                notify_ok(L(30059))

    def edit_artwork_loop():
        ART_FIELDS = [
            ('poster',   L(30095)),
            ('fanart',   L(30099)),
            ('thumb',    L(30140)),
            ('clearlogo',L(30098)),
            ('banner',   L(30096)),
        ]
        while True:
            listitems = []
            for key, label in ART_FIELDS:
                curr = p.get(key, '')
                li = xbmcgui.ListItem(label=LF(30026, label=label), label2=_show(curr))
                img = _img(curr)
                li.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
                li.setProperty('fanart_image', img)  # opcional
                listitems.append(li)

            sel = xbmcgui.Dialog().select(L(30031), listitems, useDetails=True)
            if sel in (-1, None):
                break

            key, label = ART_FIELDS[sel]
            img = ask_image(LF(30027, label=label), p.get(key,''))
            if img or img == '':
                p[key] = img
                items[index] = p
                save_programs(items)
                notify_ok(LF(30025, label=label))

    # ----- METADADOS APENAS (IGDB) -----
    def fetch_metadata_igdb():
        try:
            from .scraps import IGDBClient
        except Exception as e:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                LF(30060, error=str(e)),
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            return

        # termo padrão = título atual
        default_q = (p.get('title') or '').strip()
        q = xbmcgui.Dialog().input(
            L(30061),
            defaultt=default_q,
            type=xbmcgui.INPUT_ALPHANUM
        )
        if not q:
            return  # cancelado

        # busca na IGDB
        try:
            client = IGDBClient()
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                LF(30062, query=q),
                xbmcgui.NOTIFICATION_INFO,
                2000
            )
            results = client.search_games(q, limit=15)
        except Exception as e:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                LF(30063, error=str(e)),
                xbmcgui.NOTIFICATION_ERROR,
                6000
            )
            _log(ADDON_NAME, LF(30063, error=str(e)), xbmc.LOGERROR)
            return

        if not results:
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                LF(30064, query=q)
            )
            return

        # escolher jogo
        labels = []
        for r in results:
            title = r.get('title') or ''
            year  = r.get('year') or ''
            dev   = r.get('developer') or ''
            gen   = r.get('genre') or ''
            bits  = [title]
            if year: bits.append(f'({year})')
            if dev:  bits.append(f'· {dev}')
            if gen:  bits.append(f'· {gen}')
            labels.append(' '.join([b for b in bits if b]).strip() or (title or L(30066)))

        idx = xbmcgui.Dialog().select(LF(30065, query=q), labels)
        if idx < 0:
            return  # cancelado

        chosen = results[idx]

        # detalhes / pré-visualização
        details = []
        details.append(f"[B]{L(30072)}:[/B] {chosen.get('title','')}")
        details.append(f"[B]{L(30073)}:[/B] {chosen.get('year','') or '—'}")
        details.append(f"[B]{L(30074)}:[/B] {chosen.get('genre','') or '—'}")
        details.append(f"[B]{L(30075)}:[/B] {chosen.get('developer','') or '—'}")
        details.append(f"[B]{L(30076)}:[/B] {chosen.get('nplayers','') or '—'}")
        details.append(f"[B]{L(30077)}:[/B] {chosen.get('esrb','') or '—'}")
        details.append(f"[B]{L(30078)}:[/B] {chosen.get('rating','') or '—'}")
        plot = (chosen.get('plot') or '').strip()
        if plot:
            details.append('')
            details.append(f'[B]{L(30079)}[/B]')
            details.append(plot)

        xbmcgui.Dialog().textviewer(
            L(30067),
            '\n'.join(details)
        )

        # modo de aplicação
        mode = xbmcgui.Dialog().select(
            L(30068),
            [L(30069), L(30070)]
        )
        if mode == -1:
            return
        fill_only_empty = (mode == 0)

        # aplicar campos normalizados
        ESRB_LABELS = {
            'E':    'E (Everyone)',
            'E10+': 'E10+ (Everyone 10+)',
            'T':    'T (Teen)',
            'M':    'M (Mature 17+)',
            'AO':   'AO (Adults Only)',
            'RP':   'RP (Rating Pending)',
        }

        def _apply(field, value):
            nonlocal p
            if value is None:
                return
            value = str(value)
            if fill_only_empty and str(p.get(field, '')).strip():
                return
            p[field] = value

        _apply('title',     chosen.get('title', ''))
        _apply('year',      chosen.get('year', ''))
        _apply('plot',      chosen.get('plot', ''))
        _apply('genre',     chosen.get('genre', ''))
        _apply('developer', chosen.get('developer', ''))
        _apply('nplayers',  chosen.get('nplayers', ''))

        esrb_code = (chosen.get('esrb') or '').strip()
        esrb_lab  = ESRB_LABELS.get(esrb_code, esrb_code)
        _apply('esrb', esrb_lab)

        _apply('rating', chosen.get('rating', ''))

        items[index] = p
        save_programs(items)
        notify_ok(L(30071))
    
    # ----- ARTES APENAS (IGDB + SteamGridDB) -----
    def fetch_artwork_online():
        try:
            from .scraps import IGDBClient, SteamGridClient
        except Exception as e:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                LF(30080, error=str(e)),
                xbmcgui.NOTIFICATION_ERROR,
                5000
            )
            return

        from .utils import get_setting_path

        # termo padrão = título atual
        default_q = (p.get('title') or '').strip()
        q = xbmcgui.Dialog().input(
            L(30081),
            defaultt=default_q,
            type=xbmcgui.INPUT_ALPHANUM
        )
        if not q:
            return  # cancelado

        fanarts_dir   = get_setting_path('fanarts_dir')
        posters_dir   = get_setting_path("posters_dir")
        banners_dir   = get_setting_path("banners_dir")
        thumbs_dir    = get_setting_path("thumbs_dir")
        clearlogo_dir = get_setting_path("clearlogo_dir")

        exe_path  = p.get('path') or ''
        exe_stem  = os.path.splitext(os.path.basename(exe_path))[0] if exe_path else ''
        base_name = exe_stem or (p.get('title') or q or 'game')

        changed_img = False

        # ---------- 1) FANART pela IGDB (opcional) ----------
        chosen = None
        try:
            client_igdb = IGDBClient()
            results = client_igdb.search_games(q, limit=10)
        except Exception as e:
            results = []
            _log(ADDON_NAME, f'Falha na consulta IGDB (fanart): {e}', xbmc.LOGERROR)

        if results:
            labels = []
            for r in results:
                title = r.get('title') or ''
                year  = r.get('year') or ''
                bits  = [title]
                if year: bits.append(f'({year})')
                labels.append(' '.join([b for b in bits if b]).strip() or (title or L(30066)))

            idx = xbmcgui.Dialog().select(
                LF(30082, query=q),
                labels
            )
            if idx >= 0:
                chosen = results[idx]

        if chosen and fanarts_dir:
            fanart_candidates = chosen.get('fanart_urls') or []
            if not fanart_candidates:
                fallback = (
                    chosen.get('screenshot_url')
                    or chosen.get('artwork_url')
                    or ''
                )
                if fallback:
                    fanart_candidates = [fallback]

            if fanart_candidates:
                listitems = []
                for i, url in enumerate(fanart_candidates, 1):
                    li = xbmcgui.ListItem(label=f'Fanart #{i}', label2=url)
                    li.setArt({'icon': url, 'thumb': url})
                    listitems.append(li)

                sel = xbmcgui.Dialog().select(
                    L(30083),
                    listitems,
                    useDetails=True
                )
                if sel is not None and sel >= 0:
                    chosen_fanart = fanart_candidates[sel]
                    if yesno_compat(
                        ADDON_NAME,
                        L(30084),
                        L(30085)
                    ):
                        fanart_dst = os.path.join(fanarts_dir, f'{base_name}.jpg')
                        if client_igdb.download_url(chosen_fanart, fanart_dst):
                            p['fanart'] = fanart_dst
                            changed_img = True

        # ---------- 2) Artes do SteamGridDB ----------
        client_sg = SteamGridClient()

        # termo pro SteamGrid: título atual ou o que foi digitado
        sg_query = (p.get('title') or q or '').strip()

        sg_game_id = None
        if sg_query:
            sg_results = client_sg.search_games(sg_query)
            if sg_results:
                if len(sg_results) > 1:
                    labels_sg = [
                        f"{g.get('name', L(30066))} (ID {g.get('id')})"
                        for g in sg_results
                    ]
                    pick_g = xbmcgui.Dialog().select(
                        L(30086),
                        labels_sg
                    )
                    if pick_g >= 0:
                        sg_game_id = sg_results[pick_g].get('id')
                else:
                    sg_game_id = sg_results[0].get('id')

        def _pick_and_download_sg(art_type: str,
                                  nice_label: str,
                                  dest_dir: str,
                                  field_name: str,
                                  ext_default: str = ".png") -> bool:
            """
            art_type   -> 'grids', 'heroes', 'logos', 'icons'
            nice_label -> texto exibido no diálogo ("Poster", "Banner", etc.)
            dest_dir   -> diretório de destino
            field_name -> campo em p (poster, banner, thumb, clearlogo)
            """
            if not sg_game_id:
                xbmcgui.Dialog().notification(
                    ADDON_NAME,
                    L(30087),
                    xbmcgui.NOTIFICATION_INFO,
                    4000
                )
                return False

            if not dest_dir:
                xbmcgui.Dialog().ok(
                    ADDON_NAME,
                    LF(30088, label=nice_label)
                )
                return False

            arts = client_sg.get_art(sg_game_id, art_type)
            if not arts:
                xbmcgui.Dialog().notification(
                    ADDON_NAME,
                    LF(30089, label=nice_label),
                    xbmcgui.NOTIFICATION_INFO,
                    4000
                )
                return False

            listitems = []
            urls = []
            for i, art in enumerate(arts, 1):
                url = art.get('url') or art.get('thumb') or art.get('thumb_url')
                if not url:
                    continue
                urls.append(url)
                li = xbmcgui.ListItem(label=f'{nice_label} #{i}', label2=url)
                li.setArt({'icon': url, 'thumb': url})
                listitems.append(li)

            if not listitems:
                xbmcgui.Dialog().notification(
                    ADDON_NAME,
                    LF(30090, label=nice_label),
                    xbmcgui.NOTIFICATION_INFO,
                    4000
                )
                return False

            sel = xbmcgui.Dialog().select(
                LF(30091, label=nice_label),
                listitems,
                useDetails=True
            )
            if sel < 0:
                return False  # usuário cancelou

            url = urls[sel]

            # Mantém a extensão original da URL (jpg, png, ico, etc.)
            parsed = urllib.parse.urlparse(url)
            _, ext = os.path.splitext(parsed.path)
            if not ext:
                ext = ext_default

            dst = os.path.join(dest_dir, f'{base_name}{ext}')

            if client_sg.download_url(url, dst):
                p[field_name] = dst
                return True

            xbmcgui.Dialog().notification(
                ADDON_NAME,
                LF(30092, label=nice_label),
                xbmcgui.NOTIFICATION_ERROR,
                4000
            )
            return False

        # pergunta SEMPRE, mesmo se já existir arte
        if posters_dir:
            if _pick_and_download_sg('grids', L(30095), posters_dir, 'poster'):
                changed_img = True

        if banners_dir:
            if _pick_and_download_sg('heroes', L(30096), banners_dir, 'banner'):
                changed_img = True

        if thumbs_dir:
            if _pick_and_download_sg('icons', L(30097), thumbs_dir, 'thumb'):
                changed_img = True

        if clearlogo_dir:
            if _pick_and_download_sg('logos', L(30098), clearlogo_dir, 'clearlogo'):
                changed_img = True

        if changed_img:
            items[index] = p
            save_programs(items)
            notify_ok(L(30093))
        else:
            xbmcgui.Dialog().notification(
                ADDON_NAME,
                L(30094),
                xbmcgui.NOTIFICATION_INFO,
                4000
            )

    MAIN_META        = 0
    MAIN_FETCH_META  = 1  # Buscar metadados (IGDB)
    MAIN_FETCH_ART   = 2  # Baixar artes online (IGDB/SteamGrid)
    MAIN_ART_LOCAL   = 3  # Editar artes locais (browse de arquivos)
    MAIN_SAVE        = 4
    MAIN_DONE        = 5

    while True:
        main_opts = [
            L(30030),
            L(30100),
            L(30101),
            L(30102),
            L(30035),
            L(30033)
        ]
        ch = xbmcgui.Dialog().select(L(30032), main_opts)
        if ch in (-1, MAIN_DONE):
            break

        if ch == MAIN_META:
            edit_metadata_loop()

        elif ch == MAIN_FETCH_META:
            fetch_metadata_igdb()

        elif ch == MAIN_FETCH_ART:
            fetch_artwork_online()

        elif ch == MAIN_ART_LOCAL:
            edit_artwork_loop()

        elif ch == MAIN_SAVE:
            dest = save_item_nfo(p)
            if dest:
                notify_ok(L(30058))

    xbmc.executebuiltin('Container.Refresh')

def remove_program(index: int) -> None:
    items = load_programs()
    if index < 0 or index >= len(items):
        return
    p = items[index]
    if xbmcgui.Dialog().yesno(ADDON_NAME, LF(30110, title=p.get('title', L(30111)))):
        del items[index]
        save_programs(items)
        notify_ok(L(30112))
        xbmc.executebuiltin('Container.Refresh')

def remove_from_category(index: int, cat: str) -> None:
    items = load_programs()
    if index < 0 or index >= len(items) or not cat:
        return
    lst = items[index].get('categories') or []
    newlst = [x for x in lst if x.lower() != cat.lower()]
    items[index]['categories'] = newlst
    save_programs(items)
    notify_ok(L(30113))
    xbmc.executebuiltin('Container.Refresh')

def launch_program(path: str) -> None:
    if not path:
        return
    os_open(path)
    items = load_programs()
    now_ts = int(time.time())
    for it in items:
        if it.get('path') == path:
            it['lastplayed'] = now_ts
            save_programs(items)
            break

# ---------------------------------------------------------------------------------------
# Update (via configurações): Recursivo + Cleanup + NFO prioritário
# ---------------------------------------------------------------------------------------
def update_from_settings_dialog() -> None:
    programs_dir  = get_setting_path('programs_dir')
    posters_dir   = get_setting_path('posters_dir')
    banners_dir   = get_setting_path('banners_dir')
    fanarts_dir   = get_setting_path('fanarts_dir')
    thumbs_dir    = get_setting_path('thumbs_dir')
    clearlogo_dir = get_setting_path('clearlogo_dir')
    nfos_dir      = get_setting_path('nfos_dir')

    if not programs_dir:
        if xbmcgui.Dialog().yesno(
            ADDON_NAME,
            L(30120),
            nolabel=L(30121), yeslabel=L(30122)
        ):
            try:
                ADDON.openSettings()
            except Exception:
                xbmc.executebuiltin(f'Addon.OpenSettings({ADDON_ID})')
        return

    added, updated, removed, skipped = bulk_update_recursive_with_cleanup_and_nfo_priority(
        programs_dir, posters_dir, banners_dir, fanarts_dir, thumbs_dir, clearlogo_dir, nfos_dir
    )
    notify_ok(LF(30123, added=added, updated=updated, removed=removed, skipped=skipped), 6500)
    xbmc.executebuiltin('Container.Refresh')

def bulk_update_recursive_with_cleanup_and_nfo_priority(programs_dir: str,
                                                        posters_dir: str = '',
                                                        banners_dir: str = '',
                                                        fanarts_dir: str = '',
                                                        thumbs_dir: str = '',
                                                        clearlogo_dir: str = '',
                                                        nfos_dir: str = '') -> Tuple[int,int,int,int]:
    """
    Atualiza/limpa usando pastas configuradas (RECURSIVAS) + leitura de NFO com PRIORIDADE.
    - Considera somente arquivos com extensões EXEC_EXTS.
    - NFO PRIORITÁRIO: se um campo existir no NFO, ele sobrescreve o valor atual (inclusive título).
    - LIMPA: remove do JSON entradas cujo arquivo 'path' não existe mais e deduplica por 'path'.
    - Memoriza 'nfo_path' (origem) quando o NFO é encontrado.
    """
    items = load_programs()
    before = len(items)

    # --- raiz normalizada do diretório atual ---
    root_nc = _nc(programs_dir)

    # Remoção por inexistência
    items = [it for it in items if os.path.isfile(it.get('path',''))]
    removed_missing = before - len(items)

    # Remoção por estar FORA do programs_dir atual
    before_outside = len(items)
    items = [it for it in items if _nc(it.get('path','')).startswith(root_nc)]
    removed_outside = before_outside - len(items)

    # Deduplicação por path
    seen = set()
    deduped: List[Dict] = []
    removed_dupes = 0
    for it in items:
        pth = it.get('path','')
        if pth in seen:
            removed_dupes += 1
            continue
        seen.add(pth)
        deduped.append(it)
    items = deduped

    # Índices recursivos...
    idx_poster    = build_art_index_recursive(posters_dir)   if posters_dir   else {}
    idx_banner    = build_art_index_recursive(banners_dir)   if banners_dir   else {}
    idx_fanart    = build_art_index_recursive(fanarts_dir)   if fanarts_dir   else {}
    idx_thumb     = build_art_index_recursive(thumbs_dir)    if thumbs_dir    else {}
    idx_clearlogo = build_art_index_recursive(clearlogo_dir) if clearlogo_dir else {}
    idx_nfo       = build_nfo_index_recursive(nfos_dir)      if nfos_dir      else {}

    # Arquivos válidos sob a raiz atual
    files = iter_files_recursive(programs_dir)
    valid_execs = {f for f in files if is_allowed_exec(f) and os.path.isfile(f)}

    path_index = {it.get('path'): i for i, it in enumerate(items)}

    added = updated = skipped = 0

    for full in sorted(valid_execs):
        stem = os.path.splitext(os.path.basename(full))[0]
        key  = stem.lower()
        # artes...
        art_poster    = idx_poster.get(key, '')
        art_banner    = idx_banner.get(key, '')
        art_fanart    = idx_fanart.get(key, '')
        art_thumb     = idx_thumb.get(key, '')
        art_clearlogo = idx_clearlogo.get(key, '')
        # NFO
        nfo_data = {}
        nfo_path = idx_nfo.get(key, '')
        if nfo_path:
            nfo_data = parse_nfo(nfo_path)

        if full in path_index:
            idx = path_index[full]
            item = items[idx]
            changed = False
            # memoriza origem do NFO
            if nfo_path and item.get('nfo_path') != nfo_path:
                item['nfo_path'] = nfo_path; changed = True
            # título via NFO (prioridade)
            if nfo_data.get('title'):
                if item.get('title') != nfo_data['title']:
                    item['title'] = nfo_data['title']; changed = True
            else:
                if not item.get('title'):
                    item['title'] = stem; changed = True
            # demais campos do NFO sobrescrevem
            for fld in ('year','plot','developer','genre','nplayers','esrb','rating'):
                if nfo_data.get(fld) not in (None, '') and item.get(fld) != nfo_data.get(fld):
                    item[fld] = nfo_data[fld]; changed = True
            # artes
            if art_thumb     and item.get('thumb')     != art_thumb:     item['thumb']     = art_thumb;     changed = True
            if art_poster    and item.get('poster')    != art_poster:    item['poster']    = art_poster;    changed = True
            if art_banner    and item.get('banner')    != art_banner:    item['banner']    = art_banner;    changed = True
            if art_fanart    and item.get('fanart')    != art_fanart:    item['fanart']    = art_fanart;    changed = True
            if art_clearlogo and item.get('clearlogo') != art_clearlogo: item['clearlogo'] = art_clearlogo; changed = True

            if changed:
                items[idx] = item; updated += 1
            else:
                skipped += 1
        else:
            # novo item
            final_thumb = art_thumb or art_poster or ''
            items.append({
                'title': nfo_data.get('title') or stem,
                'path': full,
                'year': nfo_data.get('year',''),
                'plot': nfo_data.get('plot',''),
                'developer': nfo_data.get('developer',''),
                'genre': nfo_data.get('genre',''),
                'nplayers': nfo_data.get('nplayers',''),
                'esrb': nfo_data.get('esrb',''),
                'rating': nfo_data.get('rating',''),
                'thumb': final_thumb,
                'poster': art_poster or '',
                'banner': art_banner or '',
                'fanart': art_fanart or '',
                'clearlogo': art_clearlogo or '',
                'categories': [],
                'nfo_path': nfo_path or '',
                'lastplayed': 0
            })
            path_index[full] = len(items) - 1
            added += 1

    removed_total = removed_missing + removed_outside + removed_dupes
    save_programs(items)
    return (added, updated, removed_total, skipped)

# ---------------------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------------------
def router():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 and sys.argv[2].startswith('?') else {}
    action = params.get('action')

    if action == 'launch':
        # Para Jogos
        m_path = urllib.parse.unquote(params['path'])
        nome_arquivo = os.path.splitext(os.path.basename(m_path))[0]
        notify_ok(LF(30114, name=nome_arquivo))
        launch_program(param_to_path(params.get('path','')))
        
        # Para Imagens
        # m_path = urllib.parse.unquote(params['path'])
        # nome_arquivo = os.path.splitext(os.path.basename(m_path))[0]
        # m_path = os.path.dirname(m_path)
        # notify_ok('Abriu: {}'.format(nome_arquivo))
        # xbmc.executebuiltin('ActivateWindow(pictures,"{}",return)'.format(m_path))
    
    elif action == 'edit':
        p = params.get('path')
        if p:
            edit_program_by_path(param_to_path(p))
        else:
            idx = int(params.get('index','-1'))
            edit_program(idx)

    elif action == 'remove':
        p = params.get('path')
        if p:
            remove_program_by_path(param_to_path(p))
        else:
            idx = int(params.get('index','-1'))
            remove_program(idx)
            
    elif action == 'update_from_settings':
        update_from_settings_dialog()
    elif action == 'all':
        show_programs('')
    elif action == 'browse_category':
        show_programs(params.get('cat',''))
    elif action == 'add_category':
        add_category_dialog()
    elif action == 'rename_category':
        rename_category_dialog(params.get('name',''))
    elif action == 'delete_category':
        delete_category_dialog(params.get('name',''))
    elif action == 'edit_category':
        edit_category_dialog(params.get('name',''))
    elif action == 'manage_categories':
        p = params.get('path')
        if p:
            manage_item_categories_by_path(param_to_path(p))
        else:
            idx = int(params.get('index','-1'))
            manage_item_categories(idx)

    elif action == 'remove_from_category':
        p = params.get('path')
        cat = params.get('cat','')
        if p:
            remove_from_category_by_path(param_to_path(p), cat)
        else:
            idx = int(params.get('index','-1'))
            remove_from_category(idx, cat)
    
    elif action == 'toggle_category_widget':
        toggle_category_widget_visibility(params.get('name',''))
    
    elif action == 'update_all_nfos':
        update_all_nfos_dialog()
    
    # rota para widgets (não é exibida na UI do addon)
    elif action == 'all_items_widget':
        show_all_items_widget()
    
    elif action == 'backup_restore':
        from .backups import backup_restore_dialog
        backup_restore_dialog(update_all_nfos_func=update_all_nfos)
    
    elif action == 'igdb_test':
        try:
            from .scraps import IGDBClient
            ok, msg = IGDBClient().test_connection()
            icon = xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR
            xbmcgui.Dialog().notification(ADDON_NAME, msg, icon, 4000)
        except Exception as e:
            xbmcgui.Dialog().notification(ADDON_NAME, LF(30400, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)
        return
    
    elif action == 'igdb_search':
        try:
            from .scraps import IGDBClient
            # 1) Perguntar o termo de busca (ou usar ?q= na URL)
            q = params.get('q', '')
            if not q:
                q = xbmcgui.Dialog().input(L(30401), type=xbmcgui.INPUT_ALPHANUM)
            if not q:
                return  # usuário cancelou

            # 2) Consultar a IGDB
            client = IGDBClient()
            xbmcgui.Dialog().notification(ADDON_NAME, LF(30062, query=q), xbmcgui.NOTIFICATION_INFO, 2000)
            results = client.search_games(q, limit=15)

            if not results:
                xbmcgui.Dialog().ok(ADDON_NAME, LF(30064, query=q))
                return

            # 3) Montar a lista de opções
            labels = []
            for r in results:
                title = r.get('title') or ''
                year  = r.get('year') or ''
                dev   = r.get('developer') or ''
                gen   = r.get('genre') or ''
                bits  = [title]
                if year:
                    bits.append(f'({year})')
                if dev:
                    bits.append(f'· {dev}')
                if gen:
                    bits.append(f'· {gen}')
                label = ' '.join([b for b in bits if b]).strip()
                labels.append(label if label else (title or L(30066)))

            # 4) Deixar o usuário escolher
            idx = xbmcgui.Dialog().select(LF(30065, query=q), labels)
            if idx < 0:
                return  # cancelado

            chosen = results[idx]

            # 5) Mostrar os detalhes do escolhido
            details = []
            details.append(f"[B]{L(30072)}:[/B] {chosen.get('title','')}")
            details.append(f"[B]{L(30073)}:[/B] {chosen.get('year','')}")
            details.append(f"[B]{L(30074)}:[/B] {chosen.get('genre','')}")
            details.append(f"[B]{L(30075)}:[/B] {chosen.get('developer','')}")
            details.append(f"[B]{L(30076)}:[/B] {chosen.get('nplayers','') or '—'}")
            details.append(f"[B]{L(30077)}:[/B] {chosen.get('esrb','') or '—'}")
            details.append(f"[B]{L(30078)}:[/B] {chosen.get('rating','') or '—'}")
            plot = (chosen.get('plot') or '').strip()
            if plot:
                details.append('')
                details.append(f'[B]{L(30079)}[/B]')
                details.append(plot)

            xbmcgui.Dialog().textviewer(L(30067), '\n'.join(details))

            # 6) Perguntar se quer “usar” (por enquanto só loga; no Passo 4 vamos aplicar no Editor)
            if xbmcgui.Dialog().yesno(ADDON_NAME, L(30402)):

                import json
                xbmc.log(f'[{ADDON_ID}] IGDB selecionado: {json.dumps(chosen, ensure_ascii=False)}', xbmc.LOGINFO)
                xbmcgui.Dialog().notification(ADDON_NAME, L(30403), xbmcgui.NOTIFICATION_INFO, 3000)
            return

        except Exception as e:
            xbmcgui.Dialog().notification(ADDON_NAME, LF(30400, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmc.log(f'[{ADDON_NAME}] Falha: {e}', xbmc.LOGINFO)
            return

        
    else:
        # tela inicial: categorias
        show_categories()

# ---------------------------------------------------------------------------------------
# Loader class (chamada pelo addon.py raiz)
# ---------------------------------------------------------------------------------------
class Main:
    def run_plugin(self, argv):
        # argv: [base_url, handle, '?params']
        global HANDLE, BASE_URL
        try:
            BASE_URL = argv[0] if len(argv) > 0 else ''
            HANDLE   = int(argv[1]) if len(argv) > 1 else -1
        except Exception:
            BASE_URL = BASE_URL or ''
            HANDLE   = HANDLE if isinstance(HANDLE, int) else -1

        router()
