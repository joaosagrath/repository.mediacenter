# -*- coding: utf-8 -*-
"""
Categorias: autofill por pasta + UI (CRUD/gerenciamento)
Extraído de main.py para facilitar manutenção.
"""

from typing import List, Dict
import os
import xbmc
import xbmcgui
import xbmcvfs

# ---------------------------------------------------------------------------------------
# Utils (migrado para resources/utils.py)
# ---------------------------------------------------------------------------------------
from .utils import *

# NFO parser
from .nfo import parse_nfo

# ---------------------------------------------------------------------------------------
# Suporte local (constantes/ajudantes)
# ---------------------------------------------------------------------------------------
IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.gif', '.ico')

def _read_text_if_exists(path: str) -> str:
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            return fh.read().strip()
    except Exception:
        return ''

def _parse_plot_from_any_nfo_in(folder: str) -> str:
    # procura .nfo/.xml e lê <plot>
    try:
        for name in os.listdir(folder):
            low = name.lower()
            if low.endswith('.nfo') or low.endswith('.xml'):
                full = os.path.join(folder, name)
                data = parse_nfo(full)
                if data.get('plot'):
                    return data['plot']
    except Exception:
        pass
    return ''

def _find_first_by_stems(folder: str, stems: List[str]) -> str:
    """Retorna o primeiro arquivo em 'folder' cujo stem bate com qualquer item de 'stems'."""
    try:
        EXT_PRIORITY = ['.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif']
        candidates = []
        stems_lc = [s.lower() for s in stems]
        for fname in os.listdir(folder):
            fpath = os.path.join(folder, fname)
            if not os.path.isfile(fpath):
                continue
            ext = os.path.splitext(fname)[1].lower()
            if ext not in IMAGE_EXTS:
                continue
            stem = os.path.splitext(fname)[0].lower()
            if stem in stems_lc:
                score = EXT_PRIORITY.index(ext) if ext in EXT_PRIORITY else 999
                candidates.append((score, fpath))
        if candidates:
            candidates.sort(key=lambda x: x[0])
            return candidates[0][1]
    except Exception:
        pass
    return ''

# ---------------------------------------------------------------------------------------
# Categoria: Auto-preenchimento por pasta configurada
# ---------------------------------------------------------------------------------------
def autofill_category_from_assets(cat: Dict) -> bool:
    """
    Preenche automaticamente artes/metadados da categoria a partir da pasta:
      cat_assets_dir/<cat['name']>/
    - Artes: poster.*, fanart.*, icon.*, clearlogo.* (extensões IMAGE_EXTS)
    - Metadados: title.txt, plot.txt; fallback: <plot> em .nfo/.xml
    Retorna True se houve alterações.
    """
    root = get_setting_path('cat_assets_dir')
    if not root:
        return False
    cat_name = (cat.get('name') or '').strip()
    if not cat_name:
        return False

    folder = os.path.join(root, cat_name)
    if not os.path.isdir(folder):
        return False

    changed = False

    # Metadados
    title_txt = os.path.join(folder, 'title.txt')
    plot_txt  = os.path.join(folder, 'plot.txt')
    title_val = _read_text_if_exists(title_txt)
    plot_val  = _read_text_if_exists(plot_txt) or _parse_plot_from_any_nfo_in(folder)

    if title_val and cat.get('title') != title_val:
        cat['title'] = title_val
        changed = True
    if plot_val and cat.get('plot') != plot_val:
        cat['plot'] = plot_val
        changed = True

    # Artes
    poster    = _find_first_by_stems(folder, ['poster', 'folder'])
    fanart    = _find_first_by_stems(folder, ['fanart', 'background'])
    icon      = _find_first_by_stems(folder, ['icon', 'icone'])
    clearlogo = _find_first_by_stems(folder, ['clearlogo', 'logo'])

    if poster and cat.get('poster') != poster:
        cat['poster'] = poster; changed = True
    if fanart and cat.get('fanart') != fanart:
        cat['fanart'] = fanart; changed = True
    if icon and cat.get('icon') != icon:
        cat['icon'] = icon; changed = True
    if clearlogo and cat.get('clearlogo') != clearlogo:
        cat['clearlogo'] = clearlogo; changed = True

    return changed

# ---------------------------------------------------------------------------------------
# UI: Categorias (CRUD, edição, gerenciamento)
# ---------------------------------------------------------------------------------------
def add_category_dialog():
    cats = load_categories()
    name = keyboard_input(L(30300), '')
    if not name.strip():
        return
    if any(name.lower() == c['name'].lower() for c in cats):
        notify_ok(L(30301))
        return
    title = keyboard_input(L(30302), name)

    new_cat = {
        'name': name.strip(),
        'title': (title.strip() or name.strip()),
        'plot': '',
        'poster': '',
        'fanart': '',
        'icon': '',
        'clearlogo': ''
    }

    # AUTO: tenta preencher a partir de cat_assets_dir/<name>/
    if autofill_category_from_assets(new_cat):
        notify_ok(L(30303))

    cats.append(new_cat)
    save_categories(cats)
    xbmc.executebuiltin('Container.Refresh')

def rename_category_dialog(name: str):
    if not name:
        return
    cats = load_categories()
    cat = next((c for c in cats if c['name'].lower() == name.lower()), None)
    if not cat:
        notify_ok(L(30304))
        return
    new_name = keyboard_input(L(30305), default=name)
    if not new_name.strip():
        return
    if any(new_name.lower() == c['name'].lower() for c in cats if c is not cat):
        notify_ok(L(30306))
        return
    # se title == name antigo, acompanha a troca
    if cat.get('title','').strip().lower() == cat['name'].strip().lower():
        cat['title'] = new_name.strip()
    old_name = cat['name']
    cat['name'] = new_name.strip()
    save_categories(cats)

    # atualiza itens (categories guarda 'name')
    items = load_programs()
    changed = False
    for it in items:
        lst = it.get('categories') or []
        newlst = [new_name if x.lower() == old_name.lower() else x for x in lst]
        if newlst != lst:
            it['categories'] = newlst
            changed = True
    if changed:
        save_programs(items)
    notify_ok(L(30307))
    xbmc.executebuiltin('Container.Refresh')

def delete_category_dialog(name: str):
    if not name:
        return
    if not xbmcgui.Dialog().yesno(ADDON_NAME, LF(30308, name=name)):
        return
    cats = [c for c in load_categories() if c['name'].lower() != name.lower()]
    save_categories(cats)

    items = load_programs()
    changed = False
    for it in items:
        lst = it.get('categories') or []
        newlst = [x for x in lst if x.lower() != name.lower()]
        if newlst != lst:
            it['categories'] = newlst
            changed = True
    if changed:
        save_programs(items)
    notify_ok(L(30309))
    xbmc.executebuiltin('Container.Refresh')

def edit_category_dialog(name: str):
    cats = load_categories()
    cat = next((c for c in cats if c['name'].lower() == name.lower()), None)
    if not cat:
        notify_ok(L(30304))
        return

    def _show(v: str) -> str:
        v = '' if v is None else str(v)
        return v if v.strip() else L(30007)

    def _img(v: str) -> str:
        """
        Retorna um caminho que o Kodi consegue renderizar na UI.
        Aceita http/https, caminhos locais e VFS (special://, smb://, etc.).
        """
        try:
            if not v:
                return 'DefaultAddonNone.png'
            v = str(v).strip()
            if v.lower().startswith(('http://','https://','file://')):
                return v
            # Normaliza barras no Windows e testa com VFS
            v_norm = v.replace('\\', '/')
            if xbmcvfs.exists(v_norm):
                return v_norm
            # Fallback para caminhos locais puros
            if os.path.exists(v):
                return v
        except Exception:
            pass
        return 'DefaultAddonNone.png'

    def edit_meta():
        while True:
            hidden = bool(cat.get('hide_from_widgets', False))
            status = L(30331) if hidden else L(30332)
            opts = [
                LF(30311, value=_show(cat.get('title',''))),
                LF(30312, value=_show(cat.get('plot',''))),
                LF(30313, status=status),
                L(30314),
                L(30034)
            ]
            sel = xbmcgui.Dialog().select(L(30310), opts)
            if sel in (-1, 4):
                break
            if sel == 0:
                val = keyboard_input(L(30323), default=cat.get('title',''))
                if val is not None:
                    cat['title'] = val
                    save_categories(cats)
                    notify_ok(L(30315))
            elif sel == 1:
                val = keyboard_input(L(30335), default=cat.get('plot',''))
                if val is not None:
                    cat['plot'] = val
                    save_categories(cats)
                    notify_ok(L(30316))
            elif sel == 2:
                cat['hide_from_widgets'] = not hidden
                save_categories(cats)
                notify_ok(L(30317))
            elif sel == 3:
                if autofill_category_from_assets(cat):
                    save_categories(cats)
                    notify_ok(L(30318))

    def edit_art():
        FIELDS = [
            ('poster',    'Poster'),
            ('fanart',    'Fanart'),
            ('icon',      'Ícone'),
            ('clearlogo', 'Clearlogo'),
        ]
        while True:
            lis = []
            for key, lab in FIELDS:
                curr = cat.get(key,'')
                li = xbmcgui.ListItem(label=LF(30026, label=lab), label2=_show(curr))
                li.setArt({'icon': _img(curr)})
                lis.append(li)
            sel = xbmcgui.Dialog().select(L(30319), lis, useDetails=True)
            if sel in (-1, None):
                break
            key, lab = FIELDS[sel]
            img = ask_image(LF(30027, label=lab), cat.get(key,''))
            if img or img == '':
                cat[key] = img
                save_categories(cats)
                notify_ok(LF(30025, label=lab))

    while True:
        main = xbmcgui.Dialog().select(L(30320), [
            L(30030),
            L(30031),
            L(30033)
        ])
        if main in (-1, 2):
            break
        if main == 0:
            edit_meta()
        elif main == 1:
            edit_art()

    xbmc.executebuiltin('Container.Refresh')

def manage_item_categories(index: int):
    items = load_programs()
    if index < 0 or index >= len(items):
        return
    item = items[index]
    cats = load_categories()

    def rebuild_menu():
        current = set([c.lower() for c in (item.get('categories') or [])])  # names
        opts = []
        for c in cats:
            mark = 'X' if c['name'].lower() in current else ' '
            opts.append(f"[{mark}] {c.get('title') or c['name']}")
        opts += ['+ Nova categoria', 'Limpar todas', L(30033)]
        return opts

    while True:
        options = rebuild_menu()
        sel = xbmcgui.Dialog().select(L(30010), options)
        if sel < 0 or options[sel] == L(30033):
            break

        if options[sel] == L(30013):
            name = keyboard_input(L(30322), '')
            if not name.strip():
                continue
            if not any(name.lower() == c['name'].lower() for c in cats):
                title = keyboard_input(L(30323), name)
                cats.append({'name': name.strip(), 'title': title.strip() or name.strip(),
                             'plot':'','poster':'','fanart':'','icon':'','clearlogo':''})
                # auto-fill a partir da pasta configurada
                if autofill_category_from_assets(cats[-1]):
                    notify_ok(L(30303))
                save_categories(cats)
            lst = item.get('categories') or []
            if not any(name.lower() == x.lower() for x in lst):
                lst.append(name.strip())
                item['categories'] = lst
                save_programs(items)
                notify_ok(L(30324))
            continue

        if options[sel] == L(30321):
            item['categories'] = []
            save_programs(items)
            notify_ok(L(30325))
            continue

        # toggle
        idx = sel
        if 0 <= idx < len(cats):
            cname = cats[idx]['name']
            lst = item.get('categories') or []
            if any(cname.lower() == x.lower() for x in lst):
                lst = [x for x in lst if x.lower() != cname.lower()]
                notify_ok(L(30326))
            else:
                lst.append(cname)
                notify_ok(L(30327))
            item['categories'] = lst
            save_programs(items)

def toggle_category_widget_visibility(name: str) -> None:
    if not name:
        return
    cats = load_categories()
    cat = next((c for c in cats if c.get('name','').lower() == name.lower()), None)
    if not cat:
        notify_ok(L(30304))
        return

    current = bool(cat.get('hide_from_widgets', False))
    cat['hide_from_widgets'] = not current
    save_categories(cats)

    status = L(30329) if cat['hide_from_widgets'] else L(30330)
    notify_ok(LF(30328, status=status))

    xbmc.executebuiltin('Container.Refresh')
