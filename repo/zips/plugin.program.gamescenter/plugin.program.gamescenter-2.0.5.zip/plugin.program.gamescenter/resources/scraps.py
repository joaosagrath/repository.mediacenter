# -*- coding: utf-8 -*-
# Games Center - Online metadata fetchers (IGDB client)
# GPL-2.0-only
from typing import Dict, List, Tuple, Optional
import os, json, time, urllib.request, urllib.parse, datetime, urllib.error

import xbmc, xbmcgui, xbmcaddon, xbmcvfs

ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
PROFILE    = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
TOKEN_JSON = os.path.join(PROFILE, 'igdb_token.json')
SG_API_KEY = ADDON.getSetting('steamgriddb_api_key')

def _log(msg: str, level=xbmc.LOGINFO):
    try:
        xbmc.log(f'[{ADDON_ID}][IGDB] {msg}', level=level)
    except Exception:
        pass

def _read_file(path: str) -> Optional[str]:
    try:
        f = xbmcvfs.File(path, 'r')
        try:
            data = f.read()
        finally:
            f.close()
        return data
    except Exception:
        return None

def _write_file(path: str, data: str) -> bool:
    try:
        # garante a pasta
        base = os.path.dirname(path)
        if base and not xbmcvfs.exists(base):
            xbmcvfs.mkdirs(base)
        f = xbmcvfs.File(path, 'w')
        try:
            f.write(data)
        finally:
            f.close()
        return True
    except Exception as e:
        _log(f'Falha ao gravar {path}: {e}', xbmc.LOGERROR)
        return False

# --- Mapeamento simplificado de ESRB (códigos do IGDB -> string) ---
# Categoria 1 = ESRB, rating:
# 6=RP, 7=EC, 8=E, 9=E10, 10=T, 11=M, 12=AO (conforme docs do IGDB)
ESRB_CODES = {
    6: 'RP',
    7: 'EC',
    8: 'E',
    9: 'E10+',
    10: 'T',
    11: 'M',
    12: 'AO',
}

# --- Helpers de imagem IGDB ---
IMG_BASE = 'https://images.igdb.com/igdb/image/upload/'

def _igdb_img_url(image_id: str, size: str, ext: str = 'jpg') -> str:
    return f'{IMG_BASE}{size}/{image_id}.{ext}'

class IGDBClient:
    TOKEN_URL = 'https://id.twitch.tv/oauth2/token'
    BASE_URL  = 'https://api.igdb.com/v4'

    def __init__(self):
        # settings names provisionadas no settings.xml
        self.client_id     = (ADDON.getSetting('igdb_client_id') or '').strip()
        self.client_secret = (ADDON.getSetting('igdb_client_secret') or '').strip()

    # ---------------- Token ----------------
    def _load_cached_token(self) -> Optional[Dict]:
        try:
            raw = _read_file(TOKEN_JSON)
            if not raw:
                return None
            data = json.loads(raw)
            if time.time() < float(data.get('expires_at', 0)) and data.get('access_token'):
                return data
        except Exception:
            return None
        return None

    def _save_cached_token(self, token: str, expires_in: int) -> None:
        payload = {
            'access_token': token,
            'expires_at': time.time() + float(expires_in) - 60.0,  # margem de 60s
        }
        _write_file(TOKEN_JSON, json.dumps(payload))

    def _request_new_token(self) -> Dict:
        if not self.client_id or not self.client_secret:
            raise RuntimeError('Configure o Client ID e Secret do IGDB/Twitch nas configurações.')
        params = {
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'grant_type': 'client_credentials',
        }
        data = urllib.parse.urlencode(params).encode('utf-8')
        req  = urllib.request.Request(self.TOKEN_URL, data=data, method='POST')
        req.add_header('Content-Type', 'application/x-www-form-urlencoded')
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                res = json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            raise RuntimeError(f'Erro ao obter token no Twitch: {e}')
        token = res.get('access_token')
        expires_in = int(res.get('expires_in', 0))
        if not token:
            raise RuntimeError('Token não retornado pelo Twitch.')
        self._save_cached_token(token, expires_in)
        return {'access_token': token, 'expires_at': time.time() + expires_in - 60.0}

    def get_token(self, force: bool=False) -> str:
        if not force:
            cached = self._load_cached_token()
            if cached and cached.get('access_token'):
                return cached['access_token']
        newtok = self._request_new_token()
        return newtok['access_token']

    def test_connection(self) -> Tuple[bool, str]:
        try:
            tok = self.get_token(force=True)
            _log('Token obtido com sucesso.')
            return True, 'IGDB conectado com sucesso.'
        except Exception as e:
            _log(f'Falha no teste: {e}', xbmc.LOGERROR)
            return False, str(e)

    # ---------------- Busca ----------------
    def search_games(self, query: str, limit: int=15) -> List[Dict]:
        """
        Retorna uma lista de dicionários normalizados:
        {title, year, plot, genre, developer, nplayers, esrb, rating}
        """
        token = self.get_token()
        url   = f'{self.BASE_URL}/games'
        # Query: campos essenciais; 'search "texto"' foca no nome
        body = (
            'fields name, first_release_date, summary, '
            'genres.name, '
            'involved_companies.company.name, '
            'involved_companies.developer, involved_companies.publisher, '
            'involved_companies.porting, involved_companies.supporting, '
            'age_ratings.organization.name, age_ratings.rating_category.rating, '
            'age_ratings.rating, age_ratings.category, '
            'aggregated_rating, rating, '
            'cover.image_id, screenshots.image_id, artworks.image_id, '
            'game_modes.name, '
            'multiplayer_modes.campaigncoop, multiplayer_modes.lancoop, '
            'multiplayer_modes.offlinecoop, multiplayer_modes.onlinecoop, '
            'multiplayer_modes.splitscreen, multiplayer_modes.splitscreenonline, '
            'multiplayer_modes.offlinemax, multiplayer_modes.onlinemax; '
            f'search "{query}"; '
            f'limit {limit};'
        )


        data = body.encode('utf-8')
        req  = urllib.request.Request(url, data=data, method='POST')
        req.add_header('Client-ID', self.client_id)
        req.add_header('Authorization', f'Bearer {token}')
        req.add_header('Accept', 'application/json')
        req.add_header('Content-Type', 'text/plain')

        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read().decode('utf-8', 'ignore')
                arr = json.loads(raw)

        except urllib.error.HTTPError as e:
            # Lê o corpo do erro para facilitar o debug (ex.: campo inválido na query)
            try:
                err = e.read().decode('utf-8', 'ignore')
            except Exception:
                err = str(e)
            _log(f'IGDB HTTPError {e.code}: {err}', xbmc.LOGERROR)
            raise RuntimeError(f'IGDB retornou HTTP {e.code}')

        except urllib.error.URLError as e:
            _log(f'IGDB URLError: {getattr(e, "reason", e)}', xbmc.LOGERROR)
            raise RuntimeError(f'Falha de conexão com IGDB: {getattr(e, "reason", e)}')

        except Exception as e:
            _log(f'IGDB erro inesperado: {e}', xbmc.LOGERROR)
            raise RuntimeError(f'Erro ao consultar IGDB: {e}')

        out: List[Dict] = []
        for g in arr or []:
            out.append(self._normalize_game(g))
        return out

    def _to_int(self, v):
        try:
            if v is None: return 0
            return int(v)
        except Exception:
            try:
                return int(float(v))
            except Exception:
                return 0

    def _infer_nplayers(self, g: dict) -> str:
        """
        Mapeia dados de game_modes/multiplayer_modes para os rótulos usados no editor:
        "1 Player", "1-2 Players", "1-4 Players", "Multiplyer", "Online".
        """
        # Game modes (nomes em minúsculo)
        modes = []
        for m in g.get('game_modes') or []:
            if isinstance(m, dict) and m.get('name'):
                modes.append(str(m['name']).strip().lower())

        # Multiplayer aggregate
        mp = g.get('multiplayer_modes') or []
        onlinemax  = 0
        offlinemax = 0
        onlinecoop = False
        for m in mp:
            if not isinstance(m, dict):
                continue
            onlinemax  = max(onlinemax,  self._to_int(m.get('onlinemax')))
            offlinemax = max(offlinemax, self._to_int(m.get('offlinemax')))
            if bool(m.get('onlinecoop')):
                onlinecoop = True

        maxp = max(onlinemax, offlinemax)

        single = ('single player' in modes)
        multi  = ('multiplayer' in modes) or maxp >= 2
        mmo    = ('massively multiplayer online (mmo)' in modes)

        # Prioridades:
        # 1) Se somente single-player (sem sinais de multi): "1 Player"
        if single and not multi and not mmo:
            return '1 Player'

        # 2) Se há online/co-op explícito ou MMO: "Online"
        if onlinecoop or onlinemax >= 2 or mmo:
            return 'Online'

        # 3) Se temos máximo de jogadores (offline/online) -> faixas
        if 2 <= maxp <= 2:
            return '1-2 Players'
        if 3 <= maxp <= 4:
            return '1-4 Players'

        # 4) Se há multiplayer genérico, mas sem detalhe -> "Multiplyer" (mantém rótulo existente)
        if multi:
            return 'Multiplyer'

        # Sem informação confiável
        return ''

    # ---------------- Normalização ----------------
    def _normalize_game(self, g: Dict) -> Dict:
        # title
        title = (g.get('name') or '').strip()

        # year
        year = ''
        fr = g.get('first_release_date')
        if isinstance(fr, (int, float)) and fr > 0:
            try:
                year = str(datetime.datetime.utcfromtimestamp(fr).year)
            except Exception:
                year = ''

        # plot
        plot = (g.get('summary') or '').strip()

        # genres
        genres = []
        for gg in g.get('genres', []) or []:
            if isinstance(gg, dict) and gg.get('name'):
                genres.append(str(gg['name']).strip())
        genre = ', '.join(genres)

                # ---------- Main Developers (apenas desenvolvedor principal) ----------
        def _dedup(seq):
            out, seen = [], set()
            for x in seq:
                if not x:
                    continue
                xl = x.lower()
                if xl in seen:
                    continue
                seen.add(xl)
                out.append(x)
            return out

        main_devs = []
        other_devs = []  # devs que não são 'main' (porting/supporting), só para fallback

        for ic in g.get('involved_companies', []) or []:
            if not isinstance(ic, dict):
                continue
            comp = ic.get('company')
            name = (comp.get('name') or '').strip() if isinstance(comp, dict) else ''
            if not name:
                continue

            is_dev  = bool(ic.get('developer'))
            is_pub  = bool(ic.get('publisher'))
            is_port = bool(ic.get('porting'))
            is_sup  = bool(ic.get('supporting'))

            # Main Developer = developer == True e NÃO porting, NÃO supporting, (publisher irrelevante mas normalmente False)
            if is_dev and not is_port and not is_sup:
                main_devs.append(name)
            elif is_dev:
                # guardamos developers que são porting/supporting como fallback
                other_devs.append(name)

        main_devs = _dedup(main_devs)
        other_devs = _dedup(other_devs)

        if main_devs:
            developer = ', '.join(main_devs[:3])
        elif other_devs:
            # fallback: mostrou algum dev (ex.: só porting)
            developer = ', '.join(other_devs[:3])
        else:
            developer = ''


        # ---------- ESRB (U.S. & CA) ----------
        # Mapas auxiliares
        ESRB_TEXT = {
            'RP': 'Rating Pending',
            'EC': 'Early Childhood',
            'E':  'Everyone',
            'E10':'Everyone 10+',
            'T':  'Teen',
            'M':  'Mature 17+',
            'AO': 'Adults Only',
        }
        OLD_NUM_TO_CODE = {6:'RP', 7:'EC', 8:'E', 9:'E10', 10:'T', 11:'M', 12:'AO'}  # fallback p/ campos deprecados

        def _mk_esrb_label(code: str) -> str:
            # padroniza E10 -> E10+ na UI
            disp = 'E10+' if code == 'E10' else code
            txt  = ESRB_TEXT.get(code, '')
            return f'{disp} ({txt})' if txt else disp

        esrb = ''
        try:
            for ar in g.get('age_ratings') or []:
                if not isinstance(ar, dict):
                    continue

                # Novo modelo: organization.name == 'ESRB' e rating_category.rating == 'E','T','M',...
                org_name = ''
                rc_code  = ''

                org = ar.get('organization')
                if isinstance(org, dict):
                    org_name = (org.get('name') or '').strip()

                rc = ar.get('rating_category')
                if isinstance(rc, dict):
                    rc_code = (rc.get('rating') or '').strip().upper()

                # Se já veio no novo formato e é ESRB, fechou:
                if org_name == 'ESRB' and rc_code:
                    esrb = _mk_esrb_label(rc_code)
                    break

                # Fallback (campos deprecados): category==1 (ESRB) e rating numérico mapeado
                cat = ar.get('category')  # int (DEPRECATED)
                old = ar.get('rating')    # int (DEPRECATED)
                if (cat == 1 or str(cat) == '1') and isinstance(old, (int, float)):
                    code = OLD_NUM_TO_CODE.get(int(old))
                    if code:
                        esrb = _mk_esrb_label(code)
                        break
        except Exception:
            esrb = esrb or ''

        # rating (0-10)
        # IGDB fornece 'rating' (user score 0-100) e 'aggregated_rating' (metascore 0-100)
        base_rating = None
        for key in ('aggregated_rating', 'rating'):
            val = g.get(key)
            if isinstance(val, (int, float)):
                base_rating = float(val)
                break
        rating = ''
        if base_rating is not None:
            try:
                rating = str(round(base_rating / 10.0, 1))  # escala 0-10 com 1 casa
            except Exception:
                rating = ''

        # nplayers não é direto no IGDB (exige ler multiplayer_modes/game_modes).
        nplayers = self._infer_nplayers(g)

        # ---------- IMAGENS ----------
        # cover
        cover_id = ''
        cov = g.get('cover')
        if isinstance(cov, dict):
            cover_id = (cov.get('image_id') or '').strip()
        cover_url = _igdb_img_url(cover_id, 't_cover_big') if cover_id else ''

        # screenshots (todos)
        screenshot_ids = []
        for ss in g.get('screenshots', []) or []:
            if isinstance(ss, dict) and ss.get('image_id'):
                screenshot_ids.append(str(ss['image_id']).strip())
        screenshot_urls = [_igdb_img_url(i, 't_screenshot_huge') for i in screenshot_ids]

        # artworks (todos)
        artwork_ids = []
        for aw in g.get('artworks', []) or []:
            if isinstance(aw, dict) and aw.get('image_id'):
                artwork_ids.append(str(aw['image_id']).strip())
        artwork_urls = [_igdb_img_url(i, 't_1080p') for i in artwork_ids]

        # fanart "principal" (mantém compat com versões anteriores)
        screenshot_url = screenshot_urls[0] if screenshot_urls else ''
        artwork_url = artwork_urls[0] if artwork_urls else ''

        # candidato de fanart = screenshots primeiro, depois artworks
        fanart_urls = screenshot_urls + artwork_urls


        return {
            'title': title,
            'year': year,
            'plot': plot,
            'genre': genre,
            'developer': developer,
            'nplayers': nplayers,
            'esrb': esrb,
            'rating': rating,
            'cover_image_id': cover_id,
            'cover_url': cover_url,

            'screenshot_image_ids': screenshot_ids,
            'screenshot_urls': screenshot_urls,
            'screenshot_url': screenshot_url,  # (legado)
            'artwork_image_ids': artwork_ids,
            'artwork_urls': artwork_urls,
            'artwork_url': artwork_url,        # (legado)
            'fanart_urls': fanart_urls,        # lista combinada (screenshots + artworks)
        }

    def _download(self, url: str, dst_path: str) -> bool:
        try:
            base = os.path.dirname(dst_path)
            if base and not xbmcvfs.exists(base):
                xbmcvfs.mkdirs(base)
            with urllib.request.urlopen(url, timeout=25) as resp:
                data = resp.read()
            f = xbmcvfs.File(dst_path, 'w')
            try:
                f.write(data)
            finally:
                f.close()
            _log(f'Imagem salva: {dst_path}')
            return True
        except Exception as e:
            _log(f'Falha ao baixar {url} -> {dst_path}: {e}', xbmc.LOGERROR)
            return False

    def download_game_images123(self, info: dict, base_name: str,
                             posters_dir: str, thumbs_dir: str, fanarts_dir: str) -> dict:
        """
        Baixa apenas a fanart (via screenshot), se existir.
        Retorna dict com caminhos salvos: {'poster': '', 'thumb': '', 'fanart': ...}
        """

        saved = {'poster': '', 'thumb': '', 'fanart': ''}

        # usar exatamente o stem do executável (sem trocar espaços/hífens)
        safe = (base_name or 'game').strip()

        # Fanart a partir do 1º screenshot
        ss_id = (info.get('screenshot_image_id') or '').strip()
        if ss_id and fanarts_dir:
            fanart_url = _igdb_img_url(ss_id, 't_screenshot_huge')
            fanart_dst = os.path.join(fanarts_dir, f'{safe}.jpg')
            if self._download(fanart_url, fanart_dst):
                saved['fanart'] = fanart_dst

        return saved

    def build_img_url(self, image_id: str, size: str) -> str:
        return _igdb_img_url(image_id, size)

    def download_url(self, url: str, dst_path: str) -> bool:
        return self._download(url, dst_path)

class SteamGridClient:
    API_BASE = "https://www.steamgriddb.com/api/v2"

    def __init__(self, api_key: str = None):
        self.api_key = api_key or SG_API_KEY
        if not self.api_key:
            raise RuntimeError("Chave da API SteamGridDB não configurada.")
        self.include_nsfw = (
            str(ADDON.getSetting('steamgriddb_include_nsfw') or '').lower()
            in ('true', '1', 'yes', 'on')
        )
        self.api_headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9,pt-BR;q=0.8,pt;q=0.7",
            "Origin": "https://www.steamgriddb.com",
            "Referer": "https://www.steamgriddb.com/",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/133.0.0.0 Safari/537.36 "
                "GamesCenterKodi/2.0.5"
            ),
        }
        self.download_headers = {
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
            "Accept-Language": self.api_headers["Accept-Language"],
            "Origin": self.api_headers["Origin"],
            "Referer": self.api_headers["Referer"],
            "User-Agent": self.api_headers["User-Agent"],
        }

    def _request(self, path: str, params: dict = None) -> dict:
        url = f"{self.API_BASE}{path}"
        if params:
            query = urllib.parse.urlencode(params)
            url = f"{url}?{query}"

        req = urllib.request.Request(url, headers=self.api_headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as e:
            body = ''
            try:
                body = e.read().decode("utf-8", errors="replace")
            except Exception:
                body = ''
            _log(
                f"SteamGridDB HTTP {e.code} em {path}: {body[:300] or e.reason}",
                xbmc.LOGERROR if e.code >= 500 else xbmc.LOGWARNING
            )
            return {"success": False, "data": []}
        except urllib.error.URLError as e:
            _log(f"SteamGridDB erro de rede em {path}: {e}", xbmc.LOGWARNING)
            return {"success": False, "data": []}
        except Exception as e:
            _log(f"SteamGridDB falha inesperada em {path}: {e}", xbmc.LOGERROR)
            return {"success": False, "data": []}

        try:
            # SteamGrid sempre responde JSON
            return json.loads(raw.decode("utf-8"))
        except Exception as e:
            _log(f"SteamGridDB retornou JSON inválido em {path}: {e}", xbmc.LOGERROR)
            return {"success": False, "data": []}

    def search_games(self, name: str):
        """
        Busca jogos por nome usando o endpoint de autocomplete do SteamGridDB.
        Retorna uma lista de dicts (cada um é um jogo).
        """
        name = (name or '').strip()
        if not name:
            return []
        encoded = urllib.parse.quote(name)
        data = self._request(f"/search/autocomplete/{encoded}")
        return data.get("data") or []

    def get_art(self, game_id: int, art_type: str, page_size: int = 50, max_pages: int = 0):
        """
        Retorna todas as artes de um tipo específico para um game_id.

        A API do SteamGridDB pagina as respostas de artes em lotes de até
        50 itens; por isso percorremos todas as páginas disponíveis para que
        jogos com muitas imagens não fiquem limitados ao primeiro lote.

        art_type pode ser: 'grids', 'heroes', 'logos', 'icons'
        """
        if not game_id:
            return []

        page_size = max(1, min(int(page_size or 50), 50))
        max_pages = max(0, int(max_pages or 0))

        all_items = []
        seen = set()
        total = None
        page = 0

        while True:
            if max_pages and page >= max_pages:
                _log(
                    f"SteamGridDB atingiu o limite de {max_pages} páginas para {art_type}/game/{game_id}.",
                    xbmc.LOGWARNING
                )
                break

            data = self._request(
                f"/{art_type}/game/{game_id}",
                {
                    "page": page,
                    "limit": page_size,
                    "nsfw": "any" if self.include_nsfw else "false",
                }
            )
            items = data.get("data") or []
            if not items:
                break

            new_items = 0
            for item in items:
                if not isinstance(item, dict):
                    continue
                key = item.get("id") or item.get("url") or item.get("thumb") or item.get("thumb_url")
                if key is None:
                    key = json.dumps(item, sort_keys=True)
                if key in seen:
                    continue
                seen.add(key)
                all_items.append(item)
                new_items += 1

            try:
                total = int(data.get("total"))
            except Exception:
                pass

            if total is not None and len(all_items) >= total:
                break
            if len(items) < page_size:
                break
            if new_items == 0:
                break

            page += 1

        return all_items

    def download_url(self, url: str, dest_path: str) -> bool:
        """
        Faz download de uma imagem a partir de uma URL e salva em dest_path.
        Cria o diretório se não existir.
        """
        if not url or not dest_path:
            return False

        os.makedirs(os.path.dirname(dest_path), exist_ok=True)

        req = urllib.request.Request(url, headers=self.download_headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp, open(dest_path, "wb") as f:
                # lê em blocos
                while True:
                    chunk = resp.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
            return True
        except urllib.error.HTTPError as e:
            _log(f"SteamGridDB falhou ao baixar imagem ({e.code}) {url}: {e.reason}", xbmc.LOGWARNING)
        except urllib.error.URLError as e:
            _log(f"SteamGridDB erro de rede ao baixar imagem {url}: {e}", xbmc.LOGWARNING)
        except Exception as e:
            _log(f"SteamGridDB falha inesperada ao baixar imagem {url}: {e}", xbmc.LOGERROR)
        return False
    
if __name__ == '__main__':
    # Permite um teste rápido via RunScript(..., test=1, q=Zelda)
    import sys
    params = {}
    if len(sys.argv) > 1:
        # args como "key=value" separados por vírgula ou "&"
        for chunk in ('&'.join(sys.argv[1:])).split('&'):
            if '=' in chunk:
                k, v = chunk.split('=', 1)
                params[k.strip()] = v.strip()
    client = IGDBClient()
    if params.get('test'):
        ok, msg = client.test_connection()
        xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO if ok else xbmcgui.NOTIFICATION_ERROR, 4000)
    if params.get('q'):
        try:
            out = client.search_games(params['q'])
            xbmc.log(f'[{ADDON_ID}] Resultado IGDB: {json.dumps(out)[:800]}', xbmc.LOGINFO)
            xbmcgui.Dialog().ok(ADDON_NAME, f'Foram retornados {len(out)} resultados para "{params["q"]}". Consulte o log para detalhes.')
        except Exception as e:
            xbmcgui.Dialog().notification(ADDON_NAME, f'Erro: {e}', xbmcgui.NOTIFICATION_ERROR, 5000)
