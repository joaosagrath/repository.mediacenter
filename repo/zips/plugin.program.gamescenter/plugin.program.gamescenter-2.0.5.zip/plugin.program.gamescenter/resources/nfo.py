# -*- coding: utf-8 -*-
# Games Center - NFO Read/Write (ler, gerar e atualizar NFOs)
# GPL-2.0-only
from typing import Dict, Optional, Tuple, List
import os
import time
import xml.etree.ElementTree as ET
import xbmc, xbmcgui, xbmcaddon, xbmcvfs

# Contexto local (evita dependência do main.py)
ADDON      = xbmcaddon.Addon()
ADDON_ID   = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

# Utilitários já existentes no utils.py
from .utils import (
    load_programs, save_programs,
    get_setting_path, notify_ok, L, LF
)

# ---------------------------------------------------------------------------------------
# NFO Read/Write
# ---------------------------------------------------------------------------------------
def parse_nfo(nfo_path: str) -> Dict[str, str]:
    data = {'title':'','year':'','plot':'','developer':'','genre':'','nplayers':'','esrb':'','rating':''}
    try:
        tree = ET.parse(nfo_path)
        root = tree.getroot()
        def txt(tag):
            el = root.find('.//' + tag)
            return (el.text or '').strip() if el is not None else ''
        data['title']     = txt('title')
        data['year']      = txt('year')
        data['genre']     = txt('genre')
        data['developer'] = txt('developer')
        data['nplayers']  = txt('nplayers')
        data['esrb']      = txt('esrb')
        data['rating']    = txt('rating')
        data['plot']      = txt('plot')
    except Exception as e:
        xbmc.log(f"[{ADDON_ID}] parse_nfo error {nfo_path}: {e}", xbmc.LOGWARNING)
    return data

def _xml_indent(elem, level: int = 0) -> None:
    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        for e in elem:
            _xml_indent(e, level + 1)
        if not e.tail or not e.tail.strip():
            e.tail = i
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = i

def nfo_target_path(exec_path: str, programs_dir: str, nfos_dir: str) -> str:
    stem = os.path.splitext(os.path.basename(exec_path))[0]
    try:
        rel = os.path.relpath(exec_path, programs_dir)
        rel_dir = os.path.dirname(rel)
        target_dir = os.path.join(nfos_dir, rel_dir) if rel_dir and rel_dir != os.curdir else nfos_dir
    except Exception:
        target_dir = nfos_dir
    try:
        os.makedirs(target_dir, exist_ok=True)
    except Exception:
        pass
    return os.path.join(target_dir, stem + '.nfo')

def save_item_nfo(item: Dict[str, str]) -> Optional[str]:
    """
    Salva (ou cria) o NFO do item.
    Preferência:
      1) Pasta de origem do NFO (item['nfo_path']), mantendo extensão original (.nfo/.xml)
         e nomeando pelo basename do executável.
      2) Fallback: espelhar subpasta relativa a programs_dir dentro de nfos_dir (nfo_target_path).
    Atualiza item['nfo_path'] persistente ao concluir.
    """
    programs_dir = get_setting_path('programs_dir')
    nfos_dir     = get_setting_path('nfos_dir')
    if not nfos_dir:
        if xbmcgui.Dialog().yesno(ADDON_NAME, L(30130), nolabel=L(30121), yeslabel=L(30122)):
            try:
                ADDON.openSettings()
            except Exception:
                xbmc.executebuiltin(f'Addon.OpenSettings({ADDON_ID})')
        return None

    exec_path = item.get('path', '')
    if not exec_path:
        xbmcgui.Dialog().notification(ADDON_NAME, L(30131), xbmcgui.NOTIFICATION_ERROR, 4000)
        return None

    stem_exec = os.path.splitext(os.path.basename(exec_path))[0]

    # 1) Tenta pasta de origem do NFO (se conhecida)
    dest = ''
    existing_nfo_path = (item.get('nfo_path') or '').strip()
    if existing_nfo_path:
        dest_dir = os.path.dirname(existing_nfo_path)
        ext = os.path.splitext(existing_nfo_path)[1] or '.nfo'
        try:
            os.makedirs(dest_dir, exist_ok=True)
            dest = os.path.join(dest_dir, stem_exec + ext)
        except Exception:
            dest = ''  # fallback

    # 2) Fallback: estrutura espelhada sob nfos_dir
    if not dest:
        dest = nfo_target_path(exec_path, programs_dir, nfos_dir)

    # constrói XML
    root = ET.Element('game')
    def add(tag, text):
        el = ET.SubElement(root, tag); el.text = str(text or '').strip()

    add('title',     item.get('title',''))
    add('year',      item.get('year',''))
    add('genre',     item.get('genre',''))
    add('developer', item.get('developer',''))
    add('nplayers',  item.get('nplayers',''))
    add('esrb',      item.get('esrb',''))
    add('rating',    item.get('rating',''))
    add('plot',      item.get('plot',''))

    _xml_indent(root)
    tree = ET.ElementTree(root)
    try:
        # gravando direto no filesystem (caminho local)
        tree.write(dest, encoding='utf-8', xml_declaration=True)
    except Exception as e:
        xbmcgui.Dialog().notification(ADDON_NAME, LF(30132, error=str(e)), xbmcgui.NOTIFICATION_ERROR, 5000)
        return None

    # Persiste nfo_path no JSON
    items_all = load_programs()
    changed = False
    for i, it in enumerate(items_all):
        if it.get('path') == exec_path:
            if it.get('nfo_path') != dest:
                items_all[i]['nfo_path'] = dest
                changed = True
            break
    if changed:
        save_programs(items_all)

    item['nfo_path'] = dest  # atualiza cache em memória
    return dest

def update_all_nfos(show_progress: bool = True):
    """
    Atualiza/salva NFO de todos os itens.
    Retorna: (total, salvos_ok, falhas, cancelado, lista_falhas)
    """
    items = load_programs()
    total = len(items)
    ok = fail = 0
    failed_titles: List[str] = []
    canceled = False

    dlg = None
    if show_progress:
        dlg = xbmcgui.DialogProgress()
        dlg.create(ADDON_NAME, L(30133))

    for i, it in enumerate(items, 1):
        if show_progress and dlg and dlg.iscanceled():
            canceled = True
            break

        title = it.get('title') or os.path.basename(it.get('path', ''))
        if show_progress and dlg:
            pct = int((i-1) * 100 / max(1, total))
            dlg.update(pct, f"[{i}/{total}] {title}")

        dest = save_item_nfo(it)
        if dest:
            ok += 1
        else:
            fail += 1
            failed_titles.append(title)

    if show_progress and dlg:
        dlg.update(100)
        dlg.close()

    return total, ok, fail, canceled, failed_titles

def update_all_nfos_dialog():
    total, ok, fail, canceled, failed_titles = update_all_nfos(show_progress=True)
    msg = [LF(30134, total=total), LF(30135, ok=ok), LF(30136, fail=fail)]
    if canceled:
        msg.append(L(30137))
    if fail and failed_titles:
        preview = "\n".join(f"- {t}" for t in failed_titles[:10])
        if len(failed_titles) > 10:
            preview += f"\n(+ {len(failed_titles)-10} restantes)"
        msg.append("\n" + LF(30138, preview=preview))
    xbmcgui.Dialog().ok(ADDON_NAME, "\n".join(msg))
