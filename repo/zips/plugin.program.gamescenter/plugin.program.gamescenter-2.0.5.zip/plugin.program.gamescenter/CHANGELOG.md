# Changelog
Formato baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/).

## [2.0.4] - 2026-03-23
### Alterado
- README reescrito completamente com linguagem voltada ao público geral, explicando proposta, recursos, configuração e benefícios do addon de forma mais clara para novos usuários.

## [2.0.3] - 2026-03-23
### Corrigido
- Downloads de imagens do SteamGridDB agora usam headers específicos para o CDN, sem reenviar o header `Authorization: Bearer ...` nas URLs `cdn*.steamgriddb.com`, evitando falhas `401 Unauthorized` ao salvar artes.

## [2.0.2] - 2026-03-23
### Corrigido
- Requisições ao SteamGridDB agora enviam headers de cliente compatíveis com navegador (`User-Agent`, `Accept`, `Accept-Language`, `Origin` e `Referer`) para evitar bloqueios `403`/Cloudflare `1010` durante a busca de jogos e download de artes.

## [2.0.1] - 2026-03-23
### Corrigido
- Tratamento de erro na integração com o SteamGridDB durante atualização de artes: respostas HTTP como `403 Forbidden`, falhas de rede e JSON inválido agora são registradas no log sem interromper o fluxo de edição do jogo.

## [2.0.0] - 2025-10-21
### Adicionado
- **Estrutura de projeto**: código principal movido para `resources/main.py` e loader em `addon.py` (classe `Main().run_plugin(argv)`).
- **Categorias**: CRUD completo, UI dedicada, e **artes/metadados automáticos** a partir de pasta configurada (`cat_assets_dir`). Suporta `poster/fanart/icon/clearlogo` (png/jpg/jpeg/webp/bmp/gif), além de `title.txt` e `plot.txt` (ou `<plot>` em `.nfo/.xml`).
- **Menu de Edição (itens)**: submenus “Metadados” e “Artes” com miniaturas; opções diretas para `Salvar/Atualizar NFO` e `Gerenciar Categorias`.
- **Editor de Metadados**:
  - **ESRB** com lista fixa: `E, E10+, T, M, AO, RP`.
  - **Rating** com lista de `0…10`.
  - **Nº de Jogadores** com lista fixa: `1 Player, 1-2 Players, 1-4 Players, Multiplyer, Online`.
  - **Ano** via teclado numérico.
- **NFO**:
  - Leitura **prioritária** dos campos do NFO (title/year/plot/developer/genre/nplayers/esrb/rating).
  - **Salvar no local de origem** do NFO quando conhecido (`item['nfo_path']`); fallback para pasta de NFOs espelhando estrutura.
  - Ação global: **Atualizar NFOs dos Jogos** (com progresso e resumo).
- **Rota de Widgets**: `?action=all_items_widget` lista todos os itens, **filtra** itens de categorias com “Ocultar nos widgets”.
- **Ocultar categoria nos widgets**:
  - Toggle em **Editar Metadados** e atalho direto no **menu de contexto** da categoria.
- **Refresh automático de widgets**:
  - Configuração: `widgets_refresh_mode` (`Desativado | Recarregar skin | Sinalizar Skin Helper`) e `widgets_helper_property`.
  - Suporte a `reload=$INFO[Window(Home).Property(<ADDON_ID>.WidgetReload)]` no URL do widget.
- **Backup/Restaurar**:
  - Diálogo com “Fazer backup agora / Restaurar… / Abrir pasta de backups”.
  - **Antes do backup**: atualiza todos os NFOs (progresso + resumo).
  - Inclui categorias + **caminhos configurados** (settings) no arquivo `.json`.
  - **Pasta de Backups** configurável (`backups_dir`) com fallback para `profile/backups`.
  - Restore com **Substituir** ou **Mesclar** (merge por `name`, preservando `hide_from_widgets`).
- **Artes do item “Todos os Itens”**: usa tema de `media/theme/` (`_Fanart.jpg`, `all_clearlogo.png`, `all_icon.png`, `all_poster.png`).

### Alterado
- **“Todos os Itens”** (na UI do addon) agora mostra **somente itens sem categoria** e **só aparece** se houver itens sem categoria.
- **Context menu padrão de vídeo removido** dos itens: uso de `replaceItems=True`, `IsPlayable=false` e `setContent('files')`.
- **Ordenações** preservadas (título, gênero, ano) com `addSortMethod`.
- **Atualização via Configurações**:
  - Varredura **recursiva** de programas (.exe/.url/.lnk/.bat), artes e NFOs.
  - **Cleanup** automático (remove itens cujo executável foi apagado + dedup por caminho).
  - **Prioridade** para os dados vindos do NFO.
- **Seleção de item por caminho** (em vez de índice) para ações de editar/remover/gerenciar categorias, evitando inconsistências após filtros/remoções.

### Corrigido
- Bug onde editar um item na lista “Todos os Itens” podia abrir dados de outro item após mudanças — agora as ações usam o **path** único.
- Persistência do campo `hide_from_widgets` em `load_categories()`/`save_categories()` para refletir corretamente no editor e nos widgets.

### Notas de Atualização
- **Novos campos**:
  - `programs.json`: `nfo_path`, `lastplayed`, `categories` (lista).
  - `categories.json`: `poster`, `fanart`, `icon`, `clearlogo`, `plot`, `hide_from_widgets`.
- **Widgets (Skin Helper)**: adicione `&reload=$INFO[Window(Home).Property(plugin.program.gamescenter.WidgetReload)]` ao URL do widget,
  e selecione o modo “Sinalizar Skin Helper” nas configurações — o addon atualizará a property automaticamente.
- **Compatibilidade**: a migração de categorias antigas (lista de strings) é automática. O comportamento de “Todos os Itens” mudou conforme descrito acima.

## [1.x] - histórico anterior
- Versões iniciais com lançadores, varredura básica e NFO simples.
