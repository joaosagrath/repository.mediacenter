import sys
import xbmc
import xbmcgui
import xbmcplugin
from urllib import parse  # Adicione esta linha

class AlphabetService:
    @staticmethod
    def alphabet():
        all_letters = []
        if xbmc.getInfoLabel("Container.NumItems"):
            for i in range(int(xbmc.getInfoLabel("Container.NumItems"))):
                all_letters.append(xbmc.getInfoLabel("Listitem(%s).SortLetter" % i).upper())
            start_number = ""
            for number in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
                if number in all_letters:
                    start_number = number
                    break
            for letter in [start_number] + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
                label = "#" if letter == start_number else letter
                listitem = xbmcgui.ListItem(label=label)

                if letter not in all_letters:
                    listitem.setProperty("NotAvailable", "true")
                else:
                    lipath = f"plugin://script.alphabet.service/?action=alphabetletter&letter={letter}"
                    xbmcplugin.addDirectoryItem(int(sys.argv[1]), lipath, listitem, isFolder=False)

        xbmcplugin.endOfDirectory(handle=int(sys.argv[1]))

    def alphabetletter(self):
        '''Used with the alphabet scrollbar to jump to a letter'''
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=False, listitem=xbmcgui.ListItem())
        letter = self.params.get("letter", "").upper()
        
        xbmc.log(f"Alphabet letter selected: {letter}", level=xbmc.LOGDEBUG)
        
        jumpcmd = ""
        if letter in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
            jumpcmd = "firstpage"
        elif letter in ["A", "B", "C"]:
            jumpcmd = "jumpsms2"
        elif letter in ["D", "E", "F"]:
            jumpcmd = "jumpsms3"
        elif letter in ["G", "H", "I"]:
            jumpcmd = "jumpsms4"
        elif letter in ["J", "K", "L"]:
            jumpcmd = "jumpsms5"
        elif letter in ["M", "N", "O"]:
            jumpcmd = "jumpsms6"
        elif letter in ["P", "Q", "R", "S"]:
            jumpcmd = "jumpsms7"
        elif letter in ["T", "U", "V"]:
            jumpcmd = "jumpsms8"
        elif letter in ["W", "X", "Y", "Z"]:
            jumpcmd = "jumpsms9"
        if jumpcmd:
            xbmc.executebuiltin("SetFocus(50)")
            for i in range(40):
                xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.ExecuteAction",\
                    "params": { "action": "%s" }, "id": 1 }' % (jumpcmd))
                xbmc.sleep(50)
                if xbmc.getInfoLabel("ListItem.Sortletter").upper() == letter:
                    break


if __name__ == '__main__':
    service = AlphabetService()
    params = dict(parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}  # Altere aqui
    service.params = params

    action = params.get("action", "")
    if action == "alphabet":
        service.alphabet()
    elif action == "alphabetletter":
        service.alphabetletter()
