import xbmc
import xbmcgui
import xbmcaddon
import time

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')

class Monitor(xbmc.Monitor):
    def __init__(self):
        self.is_library_song = False
        self.focus_set_602 = False  # indicador para controlar se o foco no ID 602 foi definido
        self.focus_set_9000 = False  # indicador para controlar se o foco no ID 9000 foi definido
        self.is_home = False  # indicador para controlar se a janela atual é a HOME
        pass
        
    def status_check(self):
        # Realiza a verificação de status do monitor
        pass
    
    def onPlayBackStarted(self):        
        self.is_library_song = True
        if not self.focus_set_602 and self.is_home_window():  # Verifica se o foco ainda não foi definido e estamos na HOME
            xbmc.executebuiltin('Control.SetFocus(602)')
            self.focus_set_602 = True  # Define o indicador para True após a mudança de foco
            self.focus_set_9000 = False # Define o indicador para False após a mudança de foco
    
    def onPlayBackStopped(self):
        self.is_library_song = False
        self.is_home = self.is_home_window()
        self.focus_set_602 = False  # Redefine o indicador para False quando a reprodução é interrompida
        
        if not self.focus_set_9000 and self.is_home_window():
            xbmc.executebuiltin('Control.SetFocus(9000)')
            self.focus_set_9000 = True # Redefine o indicador para True quando a reprodução é interrompida
        
        # xbmc.executebuiltin('Notification({0}, Janela é a HOME: {1}, 2000)'.format(addon_name, self.is_home))

    def is_home_window(self):
        # Verifica se a janela atual do Kodi é a HOME
        return xbmc.getCondVisibility('Window.IsVisible(Home)')
    
    def is_playing(self):
        return xbmc.Player().isPlayingAudio()

monitor = Monitor()

while not monitor.abortRequested():
    try:
        while True:
            if xbmc.Player().isPlayingAudio():
                monitor.onPlayBackStarted()
                # xbmc.executebuiltin('Notification({0}, Is Playing: {1}, 2000)'.format(addon_name, monitor.is_playing()))

            
            else:
                monitor.onPlayBackStopped()
            
            monitor.status_check()
            
            if monitor.waitForAbort(1): 
                break                  
    
    except Exception as e:
        xbmc.log("Erro: {}".format(e))
