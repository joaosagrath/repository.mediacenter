import xbmc
import xbmcgui
import sys
import os
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

path   = sys.argv[2]
folder = sys.argv[3]
name   = sys.argv[4]


def make_issue_file():

    if not os.path.exists(path + folder + '.issue'):
        with open(path + folder + '.issue', 'w') as f:
            f.write('this is a album file!')
            xbmcgui.Dialog().notification('MediaCenter', 'Issue "{}" created on "{}"'.format(folder, path), xbmcgui.NOTIFICATION_INFO, 5)
    else: 
        xbmcgui.Dialog().notification('MediaCenter', 'Issue "{}" already saved on "{}"'.format(folder, path), xbmcgui.NOTIFICATION_WARNING, 5)  
        
def make_issue_folder():

    # xbmcgui.Dialog().ok('MediaCenter', path + name + '\\' + name + '.issue')

    if not os.path.exists(path + name + '\\' + name + '.issue'):
        with open(path + name + '\\' + name + '.issue', 'w') as f:
            f.write('this is a album file!')
            xbmcgui.Dialog().notification('MediaCenter', 'Issue "{}" created on "{}"'.format(name, path), xbmcgui.NOTIFICATION_INFO, 5)
    else: 
        xbmcgui.Dialog().notification('MediaCenter', 'Issue "{}" already saved on "{}"'.format(name, path), xbmcgui.NOTIFICATION_WARNING, 5) 

def make_all_folder():    
    count = 0
    folder_dir = (next(os.walk(path))[1])    
    folder_count = len(folder_dir)
    
    progress = xbmcgui.DialogProgress()    
    
    for issues in folder_dir: 
        folder_name = os.path.basename(issues) 
        filename = folder_name + '.issue'
        
        progress.create('MediaCenter', '')
        
        if not os.path.exists(path + folder_name + '\\' + filename):
             
            if progress.iscanceled():
                break   
            if folder_name == '':
                continue
            if os.path.exists(path + folder_name + '\\' + 'folder.jpg'):
                with open(path + folder_name + '\\' + filename, "w") as f:
                    f.write('this is a album file!')
                    count += 1
                    step_count = int(100 / folder_count * count)
                    progress.update(step_count, 'Making "{}" an Issue'.format(folder_name))
                
    progress.close()
    xbmcgui.Dialog().notification('MediaCenter', '{} folders were defined as albums.'.format(count), xbmcgui.NOTIFICATION_WARNING, 5)
    
def save_folder():
    
    cover = path
    big_image = Image.open(cover)
    big_image.thumbnail((1000, 1500))
    big_image.save(folder + 'folder.jpg')
    
    xbmcgui.Dialog().notification('MediaCenter', 'Folder.jpg Saved!', xbmcgui.NOTIFICATION_INFO, 5)
    
def save_fanart():
    
    cover = path
    big_image = Image.open(cover)
    big_image.thumbnail((1920, 1080))
    big_image.save(folder + 'fanart.jpg')
    
    xbmcgui.Dialog().notification('MediaCenter', 'Fanart.jpg Saved!', xbmcgui.NOTIFICATION_INFO, 5)    

def save_icon():
    
    cover = path
    big_image = Image.open(cover)
    big_image.thumbnail((1000, 1500))
    big_image.save(folder + 'icon.jpg')
    
    xbmcgui.Dialog().notification('MediaCenter', 'Icon.jpg Saved!', xbmcgui.NOTIFICATION_INFO, 5)    

def make_folder_cover(): 

    if not os.path.exists(folder + 'folder.jpg'):    
        save_folder()
    else:
        ret = xbmcgui.Dialog().yesno('MediaCenter', 'Folder image already saved on "{}". Do you want to replace?'.format(name))
        if not ret:
            return        
        save_folder()

def make_fanart(): 

    if not os.path.exists(folder + 'fanart.jpg'):    
        cover = path
        big_image = Image.open(cover)
        big_image.thumbnail((1920, 1080))
        big_image.save(folder + 'fanart.jpg')
        
        xbmcgui.Dialog().notification('MediaCenter', 'Fanart.jpg Saved!', xbmcgui.NOTIFICATION_INFO, 5)
        return 
    else:
        ret = xbmcgui.Dialog().yesno('MediaCenter', 'Fanart image already saved on "{}". Do you want to replace?'.format(name))
        if not ret:
            return
        save_fanart()
        
def make_icon(): 

    if not os.path.exists(folder + 'icon.jpg'):    
        cover = path
        big_image = Image.open(cover)
        big_image.thumbnail((1000, 1500))
        big_image.save(folder + 'icon.jpg')
        
        xbmcgui.Dialog().notification('MediaCenter', 'icon.jpg Saved!', xbmcgui.NOTIFICATION_INFO, 5)
        return 
    else:
        ret = xbmcgui.Dialog().yesno('MediaCenter', 'icon image already saved on "{}". Do you want to replace?'.format(name))
        if not ret:
            return
        save_icon()        

# --- Script Entry Point ---#
if ( __name__ == "__main__" ):
    if len(sys.argv[ 1 ]) > 0:
        if sys.argv[1] == "issue_file":
            make_issue_file()
        elif sys.argv[1] == "issue_folder":
            make_issue_folder()    
        elif sys.argv[1] == "all_folder":
            make_all_folder() 
        elif sys.argv[1] == "make_folder_cover":
            make_folder_cover() 
        elif sys.argv[1] == "make_fanart":
            make_fanart()
        elif sys.argv[1] == "make_icon":
            make_icon()              