import os
import sys

import xbmcgui
from PIL import Image


TITLE = "MediaCenter"
ISSUE_FILE_CONTENT = "this is a album file!"


def notify(message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(TITLE, message, icon, 5000)


def get_arg(index, default=""):
    return sys.argv[index] if len(sys.argv) > index else default


def ensure_directory(directory_path):
    if directory_path:
        os.makedirs(directory_path, exist_ok=True)


def ensure_issue_file(issue_path, issue_name, base_path_for_message):
    try:
        ensure_directory(os.path.dirname(issue_path))

        if not os.path.exists(issue_path):
            with open(issue_path, "w", encoding="utf-8") as file_handle:
                file_handle.write(ISSUE_FILE_CONTENT)

            notify('Issue "{}" created on "{}"'.format(issue_name, base_path_for_message))
            return True

        notify(
            'Issue "{}" already saved on "{}"'.format(issue_name, base_path_for_message),
            xbmcgui.NOTIFICATION_WARNING,
        )
        return False
    except Exception as exc:
        notify(
            'Error creating issue "{}": {}'.format(issue_name, exc),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return False


def confirm_replace(file_label, destination_image_path):
    return xbmcgui.Dialog().yesno(
        TITLE,
        '"{}" already exists on:\n{}\n\nDo you want to replace?'.format(
            file_label,
            destination_image_path,
        ),
    )


def choose_destination_image_path(base_folder, filename):
    current_folder = os.path.normpath(base_folder)
    parent_folder = os.path.dirname(current_folder)

    selected = xbmcgui.Dialog().select(
        TITLE,
        [
            'Salvar {} nessa pasta'.format(filename),
            'Salvar {} na pasta anterior'.format(filename),
        ],
    )

    if selected == -1:
        notify('Save canceled.', xbmcgui.NOTIFICATION_WARNING)
        return None

    if selected == 1:
        if not parent_folder or parent_folder == current_folder:
            notify(
                'Previous folder not available. Saving in current folder.',
                xbmcgui.NOTIFICATION_WARNING,
            )
            target_folder = current_folder
        else:
            target_folder = parent_folder
    else:
        target_folder = current_folder

    return os.path.join(target_folder, filename)


def save_resized_image(source_image_path, base_folder, filename, max_size, success_message):
    try:
        if not source_image_path:
            raise ValueError("Source image path was not provided.")

        if not os.path.exists(source_image_path):
            raise FileNotFoundError('Source image not found: "{}"'.format(source_image_path))

        destination_image_path = choose_destination_image_path(base_folder, filename)
        if not destination_image_path:
            return False

        if os.path.exists(destination_image_path):
            if not confirm_replace(filename, destination_image_path):
                notify(
                    'Save canceled for "{}".'.format(filename),
                    xbmcgui.NOTIFICATION_WARNING,
                )
                return False

        ensure_directory(os.path.dirname(destination_image_path))

        with Image.open(source_image_path) as big_image:
            big_image.thumbnail(max_size)
            big_image.save(destination_image_path)

        notify('{}\n{}'.format(success_message, destination_image_path))
        return True
    except Exception as exc:
        notify(
            'Error saving "{}": {}'.format(filename, exc),
            xbmcgui.NOTIFICATION_ERROR,
        )
        return False


def make_issue_file(path, folder):
    if not path or not folder:
        notify('Missing parameters for "issue_file".', xbmcgui.NOTIFICATION_ERROR)
        return

    issue_path = os.path.join(path, "{}.issue".format(folder))
    ensure_issue_file(issue_path, folder, path)


def make_issue_folder(path, name):
    if not path or not name:
        notify('Missing parameters for "issue_folder".', xbmcgui.NOTIFICATION_ERROR)
        return

    issue_path = os.path.join(path, name, "{}.issue".format(name))
    ensure_issue_file(issue_path, name, path)


def make_all_folder(path):
    if not path:
        notify('Missing path for "all_folder".', xbmcgui.NOTIFICATION_ERROR)
        return

    if not os.path.isdir(path):
        notify('Invalid folder path: "{}"'.format(path), xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        folder_dir = next(os.walk(path))[1]
    except Exception as exc:
        notify('Error reading folders: {}'.format(exc), xbmcgui.NOTIFICATION_ERROR)
        return

    if not folder_dir:
        notify('No folders found on "{}".'.format(path), xbmcgui.NOTIFICATION_WARNING)
        return

    count = 0
    folder_count = len(folder_dir)
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Scanning folders...")

    try:
        for index, issue_folder_name in enumerate(folder_dir, start=1):
            if progress.iscanceled():
                break

            if not issue_folder_name:
                continue

            folder_path = os.path.join(path, issue_folder_name)
            issue_path = os.path.join(folder_path, "{}.issue".format(issue_folder_name))
            folder_cover_path = os.path.join(folder_path, "folder.jpg")

            step_count = int((index / float(folder_count)) * 100)
            progress.update(step_count, 'Checking "{}"'.format(issue_folder_name))

            if os.path.exists(issue_path):
                continue

            if not os.path.exists(folder_cover_path):
                continue

            with open(issue_path, "w", encoding="utf-8") as file_handle:
                file_handle.write(ISSUE_FILE_CONTENT)

            count += 1
            progress.update(step_count, 'Making "{}" an Issue'.format(issue_folder_name))
    except Exception as exc:
        notify('Error while processing folders: {}'.format(exc), xbmcgui.NOTIFICATION_ERROR)
    finally:
        progress.close()

    notify(
        "{} folders were defined as albums.".format(count),
        xbmcgui.NOTIFICATION_WARNING,
    )


def save_folder(path, folder):
    return save_resized_image(
        source_image_path=path,
        base_folder=folder,
        filename="folder.jpg",
        max_size=(1000, 1500),
        success_message="Folder.jpg Saved!",
    )


def save_fanart(path, folder):
    return save_resized_image(
        source_image_path=path,
        base_folder=folder,
        filename="fanart.jpg",
        max_size=(1920, 1080),
        success_message="Fanart.jpg Saved!",
    )


def save_icon(path, folder):
    return save_resized_image(
        source_image_path=path,
        base_folder=folder,
        filename="icon.jpg",
        max_size=(1000, 1500),
        success_message="Icon.jpg Saved!",
    )


def make_folder_cover(path, folder, name):
    if not path or not folder:
        notify('Missing parameters for "make_folder_cover".', xbmcgui.NOTIFICATION_ERROR)
        return

    save_folder(path, folder)


def make_fanart(path, folder, name):
    if not path or not folder:
        notify('Missing parameters for "make_fanart".', xbmcgui.NOTIFICATION_ERROR)
        return

    save_fanart(path, folder)


def make_icon(path, folder, name):
    if not path or not folder:
        notify('Missing parameters for "make_icon".', xbmcgui.NOTIFICATION_ERROR)
        return

    save_icon(path, folder)


def main():
    action = get_arg(1)
    path = get_arg(2)
    folder = get_arg(3)
    name = get_arg(4)

    if not action:
        notify("No action informed.", xbmcgui.NOTIFICATION_ERROR)
        return

    if action == "issue_file":
        make_issue_file(path, folder)
    elif action == "issue_folder":
        make_issue_folder(path, name)
    elif action == "all_folder":
        make_all_folder(path)
    elif action == "make_folder_cover":
        make_folder_cover(path, folder, name)
    elif action == "make_fanart":
        make_fanart(path, folder, name)
    elif action == "make_icon":
        make_icon(path, folder, name)
    else:
        notify('Unknown action: "{}"'.format(action), xbmcgui.NOTIFICATION_ERROR)


if __name__ == "__main__":
    main()