# Photo Sets

Addon para Kodi para catalogar e navegar por coleções locais de fotos organizadas em álbuns, modelos e categorias.

Kodi addon for cataloging and browsing local photo collections organized by albums, models, and categories.

---

## Português Brasil

### Visão geral

**Photo Sets** é um addon de programa para Kodi que escaneia uma pasta local de fotos, lê metadados e artes de cada conjunto, cria bancos JSON no perfil do addon e exibe a coleção em uma navegação integrada ao Kodi.

O addon cria duas entradas principais:

- **Álbuns**: navegação por álbuns/conjuntos encontrados na pasta configurada.
- **Sets**: navegação por modelos, agrupando itens a partir dos campos de metadados `m_model` e `m_others`.

Também há suporte a **categorias**, permitindo agrupar álbuns manualmente para organizar melhor a listagem principal.

### Requisitos

- Kodi com suporte a `xbmc.python` 3.0.0 ou superior.
- Uma biblioteca local de fotos em pastas.
- Arquivos `.issue` para identificar os diretórios que devem ser tratados como itens da coleção.
- Opcionalmente, arquivos `.nfo` e artes locais para enriquecer os metadados.

### Estrutura esperada da biblioteca

A estrutura abaixo ilustra um exemplo de organização:

```text
Fotos/
└── Nome do Álbum/
    ├── Nome do Álbum.nfo
    ├── folder.jpg
    ├── fanart.jpg
    └── Nome do Set/
        ├── Nome do Set.issue
        ├── Nome do Set.nfo
        ├── folder.jpg
        ├── fanart.jpg
        ├── banner.jpg
        ├── icon.jpg
        └── clearlogo.png
```

Arquivos de arte reconhecidos durante o scan:

- `banner.jpg`
- `fanart.jpg`
- `folder.jpg`
- `icon.jpg`
- `clearlogo.png`

### Metadados usados pelo addon

Os arquivos `.nfo` podem conter campos como:

- `m_number`: número do item.
- `m_title`: título do item.
- `m_album`: álbum ao qual o item pertence.
- `m_model`: modelo principal.
- `m_others`: outros nomes/modelos, separados por vírgula.
- `m_date`: data do item.
- `m_year`: ano.
- `m_tags`: tags.
- `m_plot`: descrição/sinopse.

Quando `m_album` não é informado, o item é agrupado em **[Not Set]**.

### Configuração

Nas configurações do addon é possível definir:

- Caminho principal dos álbuns.
- Diretório de pôsteres das Sets.
- Diretório de banners compartilhados.
- Diretório de fanarts compartilhados.
- Opção de log detalhado para atualizações em lote.
- Ações para atualizar NFOs de todos os issues e de todos os álbuns.

### Como usar

1. Instale o addon no Kodi.
2. Abra as configurações do addon.
3. Defina o caminho da biblioteca de fotos em **Albums Path**.
4. Opcionalmente, configure os diretórios de artes compartilhadas.
5. Na raiz do addon, abra o menu de contexto em **Álbuns** e execute **Scan Albums**.
6. Após o scan, navegue por **Álbuns**, **Sets** ou organize seus álbuns em categorias.

### Funcionalidades principais

- Scan de álbuns a partir de diretórios com arquivos `.issue`.
- Leitura de metadados de arquivos `.nfo`.
- Geração de banco local JSON em `albuns_db`.
- Geração de banco por modelo em `sets_db`.
- Criação, edição, renomeação e exclusão de categorias.
- Associação e remoção de álbuns em categorias.
- Edição de metadados e artes de álbuns e issues.
- Exportação/atualização de NFOs em lote.
- Navegação por itens relacionados ao mesmo modelo.

### Observações para desenvolvimento

O ponto de entrada do addon é `main.py`, que delega a execução para `resources/main.py`. A classe principal combina mixins responsáveis por rotas, categorias, exibição, edição e scan.

Arquivos principais:

- `addon.xml`: manifesto do addon.
- `main.py`: entrada executada pelo Kodi.
- `resources/main.py`: composição da classe principal.
- `resources/router_mixin.py`: roteamento de ações e navegação.
- `resources/scanner_mixin.py`: leitura da biblioteca e geração dos bancos JSON.
- `resources/display_mixin.py`: montagem das listagens no Kodi.
- `resources/cat_mixin.py`: gerenciamento de categorias.
- `resources/editor_mixin.py`: edição de metadados, artes e NFOs.
- `resources/utils.py`: utilidades de diálogo, localização e integração com Kodi.

---

## English

### Overview

**Photo Sets** is a Kodi program addon that scans a local photo folder, reads metadata and artwork for each set, creates JSON databases in the addon profile, and displays the collection through Kodi-native navigation.

The addon creates two main entries:

- **Albums**: browse albums/sets found in the configured folder.
- **Sets**: browse by model, grouping items from the `m_model` and `m_others` metadata fields.

It also supports **categories**, allowing albums to be manually grouped for a cleaner main listing.

### Requirements

- Kodi with `xbmc.python` 3.0.0 or newer.
- A local photo library organized in folders.
- `.issue` files to identify directories that should be treated as collection items.
- Optional `.nfo` files and local artwork to enrich metadata.

### Expected library structure

The structure below shows an example organization:

```text
Photos/
└── Album Name/
    ├── Album Name.nfo
    ├── folder.jpg
    ├── fanart.jpg
    └── Set Name/
        ├── Set Name.issue
        ├── Set Name.nfo
        ├── folder.jpg
        ├── fanart.jpg
        ├── banner.jpg
        ├── icon.jpg
        └── clearlogo.png
```

Artwork files recognized during scanning:

- `banner.jpg`
- `fanart.jpg`
- `folder.jpg`
- `icon.jpg`
- `clearlogo.png`

### Metadata used by the addon

`.nfo` files may contain fields such as:

- `m_number`: item number.
- `m_title`: item title.
- `m_album`: album the item belongs to.
- `m_model`: primary model.
- `m_others`: other names/models, comma-separated.
- `m_date`: item date.
- `m_year`: year.
- `m_tags`: tags.
- `m_plot`: description/plot.

When `m_album` is not provided, the item is grouped under **[Not Set]**.

### Configuration

The addon settings allow you to define:

- Main albums path.
- Sets poster directory.
- Shared banners directory.
- Shared fanarts directory.
- Detailed log option for batch updates.
- Actions to update NFOs for all issues and all albums.

### How to use

1. Install the addon in Kodi.
2. Open the addon settings.
3. Set the photo library path in **Albums Path**.
4. Optionally configure shared artwork directories.
5. In the addon root, open the context menu on **Albums** and run **Scan Albums**.
6. After scanning, browse through **Albums**, **Sets**, or organize albums into categories.

### Main features

- Scan albums from directories containing `.issue` files.
- Read metadata from `.nfo` files.
- Generate a local JSON database in `albuns_db`.
- Generate a model-based database in `sets_db`.
- Create, edit, rename, and delete categories.
- Assign and remove albums from categories.
- Edit album and issue metadata/artwork.
- Batch export/update NFO files.
- Browse items related to the same model.

### Development notes

The addon entry point is `main.py`, which delegates execution to `resources/main.py`. The main class combines mixins responsible for routing, categories, display, editing, and scanning.

Main files:

- `addon.xml`: addon manifest.
- `main.py`: entry point executed by Kodi.
- `resources/main.py`: main class composition.
- `resources/router_mixin.py`: action routing and navigation.
- `resources/scanner_mixin.py`: library scanning and JSON database generation.
- `resources/display_mixin.py`: Kodi listing rendering.
- `resources/cat_mixin.py`: category management.
- `resources/editor_mixin.py`: metadata, artwork, and NFO editing.
- `resources/utils.py`: dialog, localization, and Kodi integration utilities.
