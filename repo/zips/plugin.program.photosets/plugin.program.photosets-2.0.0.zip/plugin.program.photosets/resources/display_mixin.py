# -*- coding: utf-8 -*-
# Listagens e navegação de conteúdo (álbuns, sets, modelos)

import os
import json
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

# --- Utilitários do addon ---
from .utils import *

ALBUNS_DIRNAME   = 'albuns_db'
SETS_DIRNAME  = 'sets_db'

class DisplayMixin:
    def _loc(self, string_id, fallback=''):
        return kodi_localize(string_id, fallback)

    """
    Responsável por:
      - display_album_sets(handle)
      - _add_album_header_item(handle)
      - display_album_items(handle, set_name)
      - display_all_sets(handle)
      - display_all_albums(handle)
      - display_model_sets(handle)
      - display_model_items(handle, model_name)
    """

    # -----------------------
    # paths auxiliares
    # -----------------------
    def _profile_path(self):
        return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    def _albums_db_root(self):
        return os.path.join(self._profile_path(), ALBUNS_DIRNAME)

    def _sets_db_root(self):
        return os.path.join(self._profile_path(), SETS_DIRNAME)

    def _split_models(self, issue_info):
        """
        Regra para determinar as modelos de um issue:
        - m_others preenchido: usa os nomes em m_others
        - m_others vazio: usa somente m_model
        """
        issue_info = issue_info or {}
        others = (issue_info.get('m_others') or '').strip()
        if others:
            return [name.strip() for name in others.split(',') if name.strip()]

        model = (issue_info.get('m_model') or '').strip()
        return [model] if model else []

    def _get_issue_from_album(self, set_name, issue_key):
        album_path = os.path.join(self._albums_db_root(), f'{set_name}.json')
        payload = self._safe_load_json(album_path) or {}
        issue = payload.get(issue_key)
        return issue if isinstance(issue, dict) else None

    # -----------------------
    # ITENS de um álbum
    # -----------------------
    def display_issues_from_same_models(self, handle, set_name, issue_key):
        xbmc.log(f"[photosets] display_issues_from_same_models start handle={handle} set={set_name} issue={issue_key}", xbmc.LOGINFO)
        source_issue = self._get_issue_from_album(set_name, issue_key)
        if not source_issue:
            xbmc.log(f"[photosets] source issue not found set={set_name} issue={issue_key}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(self._loc(30047, 'All from model'), self._loc(30048, 'Base issue not found'), xbmcgui.NOTIFICATION_ERROR, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        selected_models = self._split_models(source_issue)
        if not selected_models:
            xbmc.log(f"[photosets] source issue has no model data set={set_name} issue={issue_key}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(self._loc(30047, 'All from model'), self._loc(30049, 'Model not found in selected issue'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        xbmc.log(f"[photosets] selected models={selected_models}", xbmc.LOGINFO)
        selected_models_for_filter = list(selected_models)

        # Etapa intermediária: quando houver mais de uma modelo,
        # permite escolher uma específica ou manter "todas".
        if len(selected_models) > 1:
            options = ['Todas as Modelos'] + selected_models
            selected_idx = xbmcgui.Dialog().select(self._loc(30047, 'All from model'), options)

            if selected_idx == -1:
                xbmc.log(
                    f"[photosets] all_from_model selection cancelled set={set_name} issue={issue_key}",
                    xbmc.LOGINFO
                )
                xbmcplugin.endOfDirectory(handle)
                return

            if selected_idx > 0:
                selected_models_for_filter = [selected_models[selected_idx - 1]]

        selected_lookup = {name.casefold() for name in selected_models_for_filter}
        title_models = ', '.join(selected_models_for_filter)

        xbmcplugin.setPluginCategory(handle, self._loc(30073, 'All from {name}').format(name=title_models))
        xbmcplugin.setContent(handle, 'images')

        theme = 'special://home/addons/plugin.program.photosets/media/theme/'
        root = self._albums_db_root()
        metadata_keys = {"m_album", "m_tags", "m_year", "m_plot", "m_path", "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"}
        found = 0

        for filename in sorted([f for f in os.listdir(root) if f.endswith('.json') and not f.startswith('_')], key=str.lower):
            current_set = os.path.splitext(filename)[0]
            payload = self._safe_load_json(os.path.join(root, filename)) or {}
            album_tags = payload.get('m_tags', '')
            album_year = str(payload.get('m_year', '')).strip()
            album_plot = payload.get('m_plot', '')

            for current_issue_key, current_issue in payload.items():
                if current_issue_key in metadata_keys or not isinstance(current_issue, dict):
                    continue

                issue_models = self._split_models(current_issue)
                issue_lookup = {name.casefold() for name in issue_models}
                if not issue_lookup.intersection(selected_lookup):
                    continue

                found += 1
                title = current_issue.get('m_title') or current_issue_key
                label = f'{title}  [{current_set}]'

                li = xbmcgui.ListItem(label=label)
                li.setArt({
                    'icon': current_issue.get('s_icon') or f'{theme}Not_Set_icon.png',
                    'poster': current_issue.get('s_poster') or f'{theme}Not_Set_poster.png',
                    'fanart': current_issue.get('s_fanart') or f'{theme}_fanart.jpg',
                })

                # propriedades extras (consumidas por skins/overlays)
                li.setProperty('m_number', str(current_issue.get('m_number', '')))
                li.setProperty('m_title', current_issue.get('m_title', ''))
                li.setProperty('m_model', current_issue.get('m_model', ''))
                li.setProperty('m_others', current_issue.get('m_others', ''))
                li.setProperty('m_album', current_issue.get('m_album', current_set))
                li.setProperty('m_tags', current_issue.get('m_tags', album_tags))
                li.setProperty('m_date', current_issue.get('m_date', ''))
                li.setProperty('m_plot', current_issue.get('m_plot', album_plot))
                li.setProperty('m_path', current_issue.get('m_path', ''))

                tag = li.getVideoInfoTag()
                tag.setTitle(title or '')
                plot_parts = []
                if current_issue.get('m_model'):
                    plot_parts.append(f"Model: {current_issue.get('m_model')}")
                if current_issue.get('m_others'):
                    plot_parts.append(f"Others: {current_issue.get('m_others')}")
                if current_issue.get('m_date'):
                    plot_parts.append(f"Date: {current_issue.get('m_date')}")
                if current_issue.get('m_plot'):
                    plot_parts.append(current_issue.get('m_plot'))
                elif album_plot:
                    plot_parts.append(album_plot)
                tag.setPlot('\n'.join([p for p in plot_parts if p]) or '')

                number = str(current_issue.get('m_number', '')).strip()
                if number.isdigit():
                    try:
                        tag.setEpisode(int(number))
                        tag.setMediaType('episode')
                    except Exception:
                        pass

                issue_date = (current_issue.get('m_date') or '').strip()
                if issue_date:
                    try:
                        tag.setFirstAired(issue_date)
                    except Exception:
                        pass

                issue_tags = current_issue.get('m_tags') or album_tags
                if issue_tags:
                    genres = [t.strip() for t in issue_tags.split(',') if t.strip()]
                    if genres:
                        try:
                            tag.setGenres(genres)
                        except Exception:
                            pass

                if album_year.isdigit():
                    try:
                        tag.setYear(int(album_year))
                    except Exception:
                        pass

                li.addContextMenuItems([
                    ('Edit Issue', f'RunPlugin(plugin://plugin.program.photosets?action=edit_issue&set={urllib.parse.quote(current_set)}&album={urllib.parse.quote(current_issue_key)})'),
                    (self._loc(30073, 'All from {name}').format(name=title_models), f'Container.Update(plugin://plugin.program.photosets?action=all_from_model&set={urllib.parse.quote(current_set)}&album={urllib.parse.quote(current_issue_key)})'),
                    ('Open in Pictures', f'RunPlugin(plugin://plugin.program.photosets?action=open_pictures&set={urllib.parse.quote(current_set)}&path={urllib.parse.quote(current_issue.get("m_path",""))})'),
                ])

                url = f'plugin://plugin.program.photosets?action=open_pictures&set={urllib.parse.quote(current_set)}&path={urllib.parse.quote(current_issue.get("m_path",""))}'
                xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

        xbmc.log(f"[photosets] display_issues_from_same_models found={found} models={selected_models}", xbmc.LOGINFO)
        if found == 0:
            xbmcgui.Dialog().notification(self._loc(30047, 'All from model'), self._loc(30050, 'No issue found for selected models'), xbmcgui.NOTIFICATION_WARNING, 5000)

        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(handle)

    def _add_album_header(self, list_handle, album_info, set_name):
        """
        Item de cabeçalho do álbum com ações rápidas.
        """
        label = album_info.get('m_album', set_name)
        li = xbmcgui.ListItem(f'[{label}]')
        theme = 'special://home/addons/plugin.program.photosets/media/theme/'

        li.setArt({
            'icon': album_info.get('s_icon') or f'{theme}Not_Set_icon.png',
            'poster': album_info.get('s_poster') or f'{theme}Not_Set_poster.png',
            'fanart': album_info.get('s_fanart') or f'{theme}_fanart.jpg',
        })

        li.addContextMenuItems([
            (self._loc(30056, 'Update Album'), f'RunPlugin(plugin://plugin.program.photosets?action=update_album&set={urllib.parse.quote(set_name)})'),
            (self._loc(30072, 'Edit Album'), f'RunPlugin(plugin://plugin.program.photosets?action=edit_album&set={urllib.parse.quote(set_name)})'),
            ('Assign to Category', f'RunPlugin(plugin://plugin.program.photosets?action=assign_album_to_category&album={urllib.parse.quote(set_name)})'),
            ('Scan Models', 'RunPlugin(plugin://plugin.program.photosets?action=scan_sets)'),
        ])

        # Item informativo, não é pasta
        xbmcplugin.addDirectoryItem(handle=list_handle, url='', listitem=li, isFolder=False)

    # -----------------------
    # HELPERS internos
    # -----------------------
    def _safe_load_json(self, path):
        try:
            # Prefer open() aqui por performance/local FS; use xbmcvfs.File se precisar de fonte remota
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None

    def _iter_dir_files(self, directory, suffix=None):
        try:
            for entry in os.listdir(directory):
                if suffix and not entry.lower().endswith(suffix.lower()):
                    continue
                yield entry
        except Exception:
            return

    def _collect_models_from_albums(self):
        """
        Varre álbuns e coleta nomes de modelos (campo m_model).
        Retorna um set de strings.
        """
        models = set()
        root = self._albums_db_root()
        if not xbmcvfs.exists(root):
            return models

        not_keys = {
            "m_album","m_tags","m_year","m_plot","m_path",
            "s_icon","s_poster","s_clearlogo","s_fanart","s_banner"
        }

        for fname in self._iter_dir_files(root, suffix='.json'):
            if fname.startswith('_'):
                continue
            payload = self._safe_load_json(os.path.join(root, fname))
            if not payload:
                continue
            for k, v in payload.items():
                if k in not_keys:
                    continue
                model = (v or {}).get('m_model') or ''
                if model:
                    # pode haver múltiplos separados por vírgula
                    parts = [p.strip() for p in model.split(',') if p.strip()]
                    for p in parts:
                        models.add(p)
        return models

    def _collect_items_for_model_from_albums(self, model_name):
        """
        Busca issues cujos 'm_model' contenham o model_name.
        """
        items = []
        root = self._albums_db_root()
        if not xbmcvfs.exists(root):
            return items

        not_keys = {
            "m_album","m_tags","m_year","m_plot","m_path",
            "s_icon","s_poster","s_clearlogo","s_fanart","s_banner"
        }

        for fname in self._iter_dir_files(root, suffix='.json'):
            if fname.startswith('_'):
                continue
            set_name = fname[:-5]
            payload = self._safe_load_json(os.path.join(root, fname))
            if not payload:
                continue

            for issue_key, issue in payload.items():
                if issue_key in not_keys:
                    continue
                issue = issue or {}
                model_field = issue.get('m_model') or ''
                if not model_field:
                    continue

                # match simples: contem o nome (case-insensitive)
                if model_name.lower() in model_field.lower():
                    # gravar um item “rico”
                    items.append({
                        'key': issue_key,
                        'm_title': issue.get('m_title'),
                        'm_model': model_field,
                        'm_others': issue.get('m_others',''),
                        'm_date': issue.get('m_date',''),
                        'm_path': issue.get('m_path',''),
                        's_icon': issue.get('s_icon',''),
                        's_poster': issue.get('s_poster',''),
                        's_fanart': issue.get('s_fanart',''),
                        'set': set_name,
                        'album': issue_key,
                    })
        return items

    def display_album_items(self, handle, set_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'albuns_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification(self._loc(30052, 'Show Albums'), self._loc(30053, 'No albums found'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        # Ignorar as chaves de metadados principais
        album_metadata_keys = {"m_album", "m_tags", "m_year", "m_plot", "m_path", "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"}
        album_items = {k: v for k, v in albums_dict.items() if k not in album_metadata_keys}

        # Ordenar os itens alfabeticamente por m_model
        sorted_items = sorted(album_items.items(), key=lambda item: item[1].get('m_model', '').lower())

        for album_key, album_info in sorted_items:
            
            # Defina o label como m_model
            label = album_info.get('m_model', 'Unknown Model')
            li = xbmcgui.ListItem(label=label)
            
            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })

            # Setar informações adicionais como propriedades
            li.setProperty('m_number', album_info.get('m_number', ''))
            li.setProperty('m_title', album_info.get('m_title', ''))
            li.setProperty('m_model', album_info.get('m_model', ''))
            li.setProperty('m_others', album_info.get('m_others', ''))
            li.setProperty('m_album', album_info.get('m_album', ''))
            li.setProperty('m_tags', album_info.get('m_tags', ''))
            li.setProperty('m_date', album_info.get('m_date', ''))
            li.setProperty('m_plot', album_info.get('m_plot', ''))
            li.setProperty('m_path', album_info.get('m_path', ''))

            li.setLabel(album_info.get('m_model', '') or album_info.get('m_title', ''))

            tag = li.getVideoInfoTag()
            tag.setTitle(album_info.get('m_title', '') or '')

            num = album_info.get('m_number')
            if num not in (None, ''):
                try:
                    tag.setEpisode(int(num))
                    tag.setMediaType('episode')
                except ValueError:
                    pass

            date = (album_info.get('m_date') or '').strip()  # ideal: "YYYY-MM-DD"
            if date:
                if num not in (None, ''):
                    tag.setFirstAired(date)
                else:
                    tag.setPremiered(date)

            models = [n.strip() for n in (album_info.get('m_model') or '').split(',') if n.strip()]
            
            album_name = album_info.get('m_album')
            
            # Adicionar o menu de contexto "Edit Issues"
            if not album_name:
                context_menu = [
                    (self._loc(30054, "Edit Issue"), f"RunPlugin(plugin://plugin.program.photosets?action=edit_issue&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (self._loc(30073, "All from {name}").format(name=album_info.get('m_model', 'model')), f"Container.Update(plugin://plugin.program.photosets?action=all_from_model&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (self._loc(30055, 'Update Sets Database'), f'RunPlugin(plugin://plugin.program.photosets?action=scan_sets)'),
                    
                ]
            else:    
                context_menu = [
                    (self._loc(30054, "Edit Issue"), f"RunPlugin(plugin://plugin.program.photosets?action=edit_issue&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (self._loc(30073, "All from {name}").format(name=album_info.get('m_model', 'model')), f"Container.Update(plugin://plugin.program.photosets?action=all_from_model&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                    (self._loc(30056, 'Update Album'), f'RunPlugin(plugin://plugin.program.photosets?action=update_album&set={urllib.parse.quote(set_name)})'),
                    (self._loc(30055, 'Update Sets Database'), f'RunPlugin(plugin://plugin.program.photosets?action=scan_sets)'),
                    (self._loc(30025, 'Scan Albums'), f'RunPlugin(plugin://plugin.program.photosets?action=scan_albums)'),
                ]
            li.addContextMenuItems(context_menu)
                
            # URL para abrir a janela de imagens
            url = f'plugin://plugin.program.photosets?action=open_pictures&set={urllib.parse.quote(set_name)}&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por label (m_model)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_TITLE)  # Ordenar por título (se aplicável)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)   # Ordenar por data (se aplicável)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_EPISODE) # Ordenar por episódio (se aplicável)

        xbmcplugin.endOfDirectory(handle)

    def display_all_sets(self, handle):
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        # Forçar atualização sempre que entrar no diretório
        xbmc.executebuiltin('Container.Refresh')

        json_files = [filename for filename in os.listdir(albums_db_path) if filename.endswith('.json')]

        if not json_files:
            xbmcgui.Dialog().notification(self._loc(30052, 'Show Albums'), self._loc(30053, 'No albums found'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # Lista para armazenar todos os issues (de todos os sets)
        all_issues = []

        # Iterar sobre todos os arquivos JSON
        for filename in json_files:
            if filename == '_scan_timestamp.json':
                continue

            set_name = filename[:-5]
            albums_json_path = os.path.join(albums_db_path, filename)

            with open(albums_json_path, 'r', encoding='utf-8') as json_file:
                albums_dict = json.load(json_file)

            # Ignorar arquivos JSON sem conjuntos específicos
            for album_key, album_info in albums_dict.items():
                # Pula as chaves do cabeçalho como 'm_album', 's_icon', etc.
                if isinstance(album_info, dict) and 'm_title' in album_info:
                    all_issues.append((set_name, album_key, album_info))

        if not all_issues:
            xbmcgui.Dialog().notification(self._loc(30052, 'Show Albums'), self._loc(30053, 'No albums found'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        # Ordenar os issues por título
        all_issues_sorted = sorted(all_issues, key=lambda item: (item[2].get('m_title') or self._loc(30057, '[No Title]')).lower())

        for set_name, album_key, album_info in all_issues_sorted:
            li = xbmcgui.ListItem(label=album_info.get('m_title', self._loc(30057, '[No Title]')))

            theme = 'special://home/addons/plugin.program.photosets/media/theme/'

            icon_art = album_info.get('s_icon')     if album_info.get('s_icon')   else f'{theme}Not_Set_icon.png'
            poster_art = album_info.get('s_poster') if album_info.get('s_poster') else f'{theme}Not_Set_poster.png'
            fanart_art = album_info.get('s_fanart') if album_info.get('s_fanart') else f'{theme}_fanart.jpg'

            li.setArt({
                'icon': icon_art,
                'poster': poster_art,
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': fanart_art,
                'banner': album_info.get('s_banner', '')
            })

            # Verificar se os metadados existem
            m_number = album_info.get('m_number', '')
            m_model = album_info.get('m_model', '')
            m_title = album_info.get('m_title', '')
            m_album = album_info.get('m_album', '')
            m_tags = album_info.get('m_tags', '')
            m_year = album_info.get('m_year', '')
            m_plot = album_info.get('m_plot', '')

            # Definir as propriedades para o item da lista
            li.setProperty('m_number', m_number)
            li.setProperty('m_model', m_model)
            li.setProperty('m_title', m_title)
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', m_tags)
            li.setProperty('m_year', m_year)
            li.setProperty('m_plot', m_plot)

            li.setInfo(type='pictures', infoLabels={
                'title': album_info.get('m_title', self._loc(30057, '[No Title]'))
            })

            
            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                (self._loc(30056, "Update Album"), f"RunPlugin(plugin://plugin.program.photosets?action=update_album&set={urllib.parse.quote(set_name)})"),
                (self._loc(30072, "Edit Album"), f"RunPlugin(plugin://plugin.program.photosets?action=edit_album&set={urllib.parse.quote(set_name)})"),
                (self._loc(30054, "Edit Issue"), f"RunPlugin(plugin://plugin.program.photosets?action=edit_issue&set={urllib.parse.quote(set_name)}&album={urllib.parse.quote(album_key)})"),
                (self._loc(30025, 'Scan Albums'), f'RunPlugin(plugin://plugin.program.photosets?action=scan_albums)'),
            ]
            li.addContextMenuItems(context_menu)

            # Clique abre o issue nas imagens
            url = f'plugin://plugin.program.photosets?action=open_pictures&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por data
        
        # Finaliza a listagem e garante que o conteúdo seja atualizado
        xbmcplugin.endOfDirectory(handle)
    
    def display_model_sets(self, handle):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        sets_db_path = os.path.join(addon_data_path, 'sets_db')
        albums_db_path = os.path.join(addon_data_path, 'albuns_db')

        sets_timestamp_file = os.path.join(sets_db_path, '_scan_timestamp.json')
        albums_timestamp_file = os.path.join(albums_db_path, '_scan_timestamp.json')

        # Verificar se os arquivos de timestamp existem
        if xbmcvfs.exists(sets_timestamp_file) and xbmcvfs.exists(albums_timestamp_file):
            try:
                # Ler os arquivos de timestamp
                with open(sets_timestamp_file, 'r', encoding='utf-8') as f:
                    sets_data = json.load(f)
                with open(albums_timestamp_file, 'r', encoding='utf-8') as f:
                    albums_data = json.load(f)

                # Obter os timestamps
                sets_timestamp = sets_data.get('last_scan')
                albums_timestamp = albums_data.get('last_scan')

                # Verificar se ambos os timestamps foram encontrados e são válidos
                if sets_timestamp is None or albums_timestamp is None:
                    raise ValueError('Timestamp missing in one of the JSON files')

                # Comparar os timestamps Unix diretamente
                if sets_timestamp < albums_timestamp:
                    xbmcgui.Dialog().notification(self._loc(30058, 'Updating Sets'), self._loc(30059, 'Model data is outdated. Updating now...'), xbmcgui.NOTIFICATION_INFO, 5000)
                    self.scan_sets()

            except (ValueError, TypeError, json.JSONDecodeError, Exception) as e:
                xbmc.log(f"Error comparing timestamps: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().notification(self._loc(30060, 'Error'), self._loc(30061, 'Failed to compare timestamps'), xbmcgui.NOTIFICATION_ERROR, 5000)
                return

        else:
            # Se algum dos arquivos de timestamp não existir, chamar scan_sets
            xbmcgui.Dialog().notification(self._loc(30058, 'Updating Sets'), self._loc(30062, 'Timestamp not found. Updating sets...'), xbmcgui.NOTIFICATION_INFO, 5000)
            self.scan_sets()

        # Continuar com a exibição dos conjuntos de modelos
        json_files = [filename for filename in os.listdir(sets_db_path) if filename.endswith('.json') and filename != '_scan_timestamp.json']

        if not json_files:
            xbmcgui.Dialog().notification(self._loc(30052, 'Show Albums'), self._loc(30053, 'No albums found'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        album_sets = [filename.replace('.json', '') for filename in json_files]

        # Ordenar os conjuntos alfabeticamente
        sorted_sets = sorted(album_sets)

        # Mover [Not Set] para o início, se existir
        if "[Not Set]" in sorted_sets:
            sorted_sets.remove("[Not Set]")
            sorted_sets.insert(0, "[Not Set]")

        for set_name in sorted_sets:
            albums_json_path = os.path.join(sets_db_path, f"{set_name}.json")

            with open(albums_json_path, 'r', encoding='utf-8') as json_file:
                albums_dict = json.load(json_file)
            
            album_info = albums_dict
            
            # Contar o número de sets (volumes) presentes no JSON
            not_count = ["m_model", "m_type", "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"]

            # Contar o número de sets (volumes) ignorando as propriedades gerais
            set_count = sum(1 for key in albums_dict if key not in not_count)

            li = xbmcgui.ListItem(label=set_name)
            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })

            # Verificar se os metadados existem
            m_title = album_info.get('m_title', self._loc(30057, '[No Title]'))
            m_album = album_info.get('m_album', '')
            m_tags = album_info.get('m_tags', '')
            m_year = album_info.get('m_year', '')
            m_plot = album_info.get('m_plot', '')
            m_model = album_info.get('m_model', '[No Model]')
            
            # Adicionar a frase "m_model possui X sets" ao início do m_plot
            m_plot = f"{m_model} possui {set_count} sets\n{m_plot}"

            # Definir as propriedades para o item da lista
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', m_tags)
            li.setProperty('m_year', m_year)
            li.setProperty('m_plot', m_plot)

            li.setLabel(album_info.get('m_model', '') or album_info.get('m_title', '') or set_name)

            tag = li.getVideoInfoTag()
            tag.setTitle(album_info.get('m_title', '') or '')

            # plot já montado acima como m_plot com "X sets" — aproveitamos no InfoTag
            tag.setPlot(m_plot or '')

            num = album_info.get('m_number')
            if num not in (None, ''):
                try:
                    tag.setEpisode(int(num))
                    tag.setMediaType('episode')
                except ValueError:
                    pass

            date = (album_info.get('m_date') or '').strip()  # ideal: YYYY-MM-DD
            if date:
                if num not in (None, ''):
                    tag.setFirstAired(date)
                else:
                    tag.setPremiered(date)

            
            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                (f'Update Sets', f'RunPlugin(plugin://plugin.program.photosets?action=scan_sets)'),
            ]
            li.addContextMenuItems(context_menu)

            # URL para abrir o conjunto de álbuns
            url = f"plugin://plugin.program.photosets/?folder=Sets&set={urllib.parse.quote(set_name)}"

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)

        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por nome
        
        xbmcplugin.endOfDirectory(handle)

    def display_model_items(self, handle, set_name):
        
        addon_data_path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        albums_json_path = os.path.join(addon_data_path, f'sets_db/{set_name}.json')
        
        if not xbmcvfs.exists(albums_json_path):
            xbmcgui.Dialog().notification(self._loc(30052, 'Show Albums'), self._loc(30053, 'No albums found'), xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(handle)
            return

        with open(albums_json_path, 'r', encoding='utf-8') as json_file:
            albums_dict = json.load(json_file)

        # Ignorar as chaves de metadados principais
        album_metadata_keys = {"m_model", "m_type", "s_icon", "s_poster", "s_clearlogo", "s_fanart", "s_banner"}
        album_items = {k: v for k, v in albums_dict.items() if k not in album_metadata_keys}

        # Ordenar os itens alfabeticamente
        sorted_items = sorted(album_items.items())

        for album_key, album_info in sorted_items:
            li = xbmcgui.ListItem(label=album_info.get("m_title", self._loc(30063, "Unknown Title")))

            # Set the art properties for the list item
            li.setArt({
                'icon': album_info.get('s_icon', ''),
                'poster': album_info.get('s_poster', ''),
                'clearlogo': album_info.get('s_clearlogo', ''),
                'fanart': album_info.get('s_fanart', ''),
                'banner': album_info.get('s_banner', '')
            })
            
            m_album = album_info.get('m_album', '')
            if not m_album:
                m_album = '[Not Set]'

            # Setar informações adicionais como propriedades
            li.setProperty('m_number', album_info.get('m_number', ''))
            li.setProperty('m_title', album_info.get('m_title', ''))
            li.setProperty('m_model', album_info.get('m_model', ''))
            li.setProperty('m_others', album_info.get('m_others', ''))
            li.setProperty('m_album', m_album)
            li.setProperty('m_tags', album_info.get('m_tags', ''))
            li.setProperty('m_date', album_info.get('m_date', ''))
            li.setProperty('m_plot', album_info.get('m_plot', ''))
            li.setProperty('m_path', album_info.get('m_path', ''))

            li.setLabel(album_info.get('m_model', '') or album_info.get('m_title', '') or self._loc(30063, 'Unknown Title'))

            tag = li.getVideoInfoTag()
            tag.setTitle(album_info.get('m_title', '') or '')

            num = album_info.get('m_number')
            if num not in (None, ''):
                try:
                    tag.setEpisode(int(num))
                    tag.setMediaType('episode')
                except ValueError:
                    pass

            date = (album_info.get('m_date') or '').strip()  # ideal: YYYY-MM-DD
            if date:
                if num not in (None, ''):
                    tag.setFirstAired(date)
                else:
                    tag.setPremiered(date)

            # (opcional) enriquecer com elenco/modelos se houver
            _models = [n.strip() for n in (album_info.get('m_model') or '').split(',') if n.strip()]
            # if _models:
                # try:
                    # tag.setCast([{'name': n} for n in _models])
                # except AttributeError:
                    # pass

            
            # Adicionar o menu de contexto "Edit Issues"
            context_menu = [
                (self._loc(30054, "Edit Issue"), f"RunPlugin(plugin://plugin.program.photosets?action=edit_issue&set={urllib.parse.quote(m_album)}&album={urllib.parse.quote(album_key)})"),
                (self._loc(30073, "All from {name}").format(name=album_info.get('m_model', 'model')), f"Container.Update(plugin://plugin.program.photosets?action=all_from_model&set={urllib.parse.quote(m_album)}&album={urllib.parse.quote(album_key)})"),
                (f'Update Sets', f'RunPlugin(plugin://plugin.program.photosets?action=scan_sets)'),
            ]
            li.addContextMenuItems(context_menu)

            # URL para abrir a janela de imagens
            url = f'plugin://plugin.program.photosets?action=open_pictures&set={urllib.parse.quote(m_album)}&path={urllib.parse.quote(album_info.get("m_path", ""))}'

            # Adicionar o item ao diretório
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
        
        # Adicionar método de ordenação
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)  # Ordenar por nome
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_DATE)  # Ordenar por nome
        
        xbmcplugin.endOfDirectory(handle)
