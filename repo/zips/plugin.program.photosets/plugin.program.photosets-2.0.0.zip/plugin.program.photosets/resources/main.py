# -*- coding: utf-8 -*-
"""
main.py — classe composta que junta todos os mixins
Mantém o mesmo comportamento do seu main original, apenas com o código dividido.
"""

import sys

from .utils import *

# Suporte a import relativo (pacote) e absoluto (mesma pasta)
try:
    from .router_mixin import RouterMixin
    from .cat_mixin import CatMixin
    from .display_mixin import DisplayMixin
    from .editor_mixin import EditorMixin
    from .scanner_mixin import ScannerMixin
except Exception:  # fallback para execução direta fora de pacote
    from router_mixin import RouterMixin
    from cat_mixin import CatMixin
    from display_mixin import DisplayMixin
    from editor_mixin import EditorMixin
    from scanner_mixin import ScannerMixin


class Main(RouterMixin, CatMixin, DisplayMixin, EditorMixin, ScannerMixin):
    """Classe principal composta. Os métodos continuam iguais, apenas organizados por mixins."""
    pass


if __name__ == '__main__':
    # Entrada esperada pelo Kodi (sys.argv)
    Main().run_plugin(sys.argv)
