# script.song.autorating
 A script to rating the songs while it's playing
