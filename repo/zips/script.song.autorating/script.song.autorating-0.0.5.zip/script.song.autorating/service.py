# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import json
import traceback
import time

# Notificações mais seguras (evita quebrar com caracteres especiais)
try:
    import xbmcgui  # Kodi GUI API
except Exception:
    xbmcgui = None

addon = xbmcaddon.Addon()
ADDON_NAME = addon.getAddonInfo("name")

def get_bool_setting(key: str) -> bool:
    # Compatível com versões que não têm getSettingBool
    try:
        return addon.getSettingBool(key)  # Kodi 19+
    except Exception:
        return addon.getSetting(key) == "true"

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME}] {msg}", level)

def jsonrpc(method: str, params: dict = None) -> dict:
    """Chama JSON-RPC com segurança e retorna dict (ou {})."""
    payload = {"jsonrpc": "2.0", "method": method, "id": 1}
    if params:
        payload["params"] = params
    try:
        res = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(res)
        if isinstance(data, dict):
            return data
    except Exception:
        log(f"JSONRPC error on {method}: {traceback.format_exc()}", xbmc.LOGERROR)
    return {}

def get_current_item() -> dict:
    """Pega item atual do player de áudio."""
    data = jsonrpc("Player.GetItem", {
        "playerid": 0,  # áudio
        "properties": ["userrating", "title"]
    })
    try:
        return data["result"]["item"]
    except Exception:
        return {}

def clamp_rating(x: int) -> int:
    if x < 0:
        return 0
    if x > 10:
        return 10
    return x

def notify(msg: str, ms: int = 2000):
    """Notifica sem quebrar em casos de caracteres especiais."""
    try:
        if xbmcgui is not None:
            xbmcgui.Dialog().notification(ADDON_NAME, str(msg), time=int(ms))
        else:
            # fallback: tenta builtin (pode falhar com caracteres especiais)
            safe = str(msg).replace(",", " ").replace(")", " ").replace("(", " ")
            xbmc.executebuiltin(f"Notification({ADDON_NAME}, {safe}, time={int(ms)})")
    except Exception:
        pass

class State:
    """Estado da faixa atual e da anterior (para commitar nota certa ao pular)."""
    def __init__(self):
        self.current_song_id = None         # int
        self.current_title = ""             # str
        self.current_userrating = 0         # int (0–10)
        self.last_computed_rating = 0       # int (0–10) - atualiza a cada tick
        self.last_committed_id = None       # evita commits repetidos

        # melhorias (não alteram a função padrão)
        self.current_started_ts = None      # time.time() quando capturou a música
        self.last_player_time = 0           # último tempo (segundos) visto no player
        self.last_notified_rating = None    # para evitar spam em notificação em tempo real

    def reset_current(self):
        self.current_song_id = None
        self.current_title = ""
        self.current_userrating = 0
        self.last_computed_rating = 0
        self.current_started_ts = None
        self.last_player_time = 0
        self.last_notified_rating = None

STATE = State()

class PlayerEvents(xbmc.Player):
    """Player com callbacks de evento para commitar nota no timing certo."""

    def onPlayBackStarted(self):
        # Tocou algo novo → antes de configurar o novo, finalize o anterior (se houver)
        self._commit_previous_if_pending()
        self._capture_current()

    def onAVStarted(self):
        # Em alguns sistemas, onAVStarted sinaliza metadados prontos
        self._capture_current()

    def onPlayBackStopped(self):
        # Usuário parou / pulou → commitar última nota calculada
        self._commit_current("stopped")

    def onPlayBackEnded(self):
        # Fim natural da faixa → commitar
        self._commit_current("ended")

    def _capture_current(self):
        try:
            item = get_current_item()
            song_id = item.get("id", None)
            title = item.get("title", "") or xbmc.getInfoLabel("MusicPlayer.Title") or ""
            userrating = item.get("userrating", 0) or 0

            if song_id in (None, -1):
                # Itens fora da biblioteca não suportam SetSongDetails
                STATE.reset_current()
                log("Item sem song_id válido (fora da biblioteca). Não será avaliado.")
                return

            # Novo item detectado → configurar estado atual
            STATE.current_song_id = int(song_id)
            STATE.current_title = str(title)
            STATE.current_userrating = int(userrating)
            STATE.last_computed_rating = 0
            STATE.current_started_ts = time.time()
            STATE.last_player_time = 0
            STATE.last_notified_rating = None

            log(f"Now playing: id={STATE.current_song_id} | title='{STATE.current_title}' | userrating={STATE.current_userrating}")
        except Exception:
            log(f"_capture_current error: {traceback.format_exc()}", xbmc.LOGERROR)

    def _commit_previous_if_pending(self):
        # Se havia uma música anterior em progresso e não foi committed, commita agora
        if STATE.current_song_id and STATE.current_song_id != STATE.last_committed_id:
            self._commit_current("switched")

    def _commit_current(self, reason: str):
        """Grava a nota da faixa atual se possível."""
        try:
            song_id = STATE.current_song_id
            if not song_id or song_id == -1:
                return

            # usar a última nota calculada pelo loop (tick)
            new_rating = clamp_rating(int(STATE.last_computed_rating))
            old_rating = int(STATE.current_userrating or 0)

            # PROTEÇÃO: não sobrescrever rating existente (>0) com 0 por acidente
            # (ex.: pulo rápido antes do primeiro tick ou metadados sem duração)
            if new_rating == 0 and old_rating > 0:
                log(f"Proteção anti-zero: mantendo rating antigo ({old_rating}) para id={song_id} ({reason}).")
                STATE.last_committed_id = song_id  # marca como tratado para evitar tentativas repetidas
                return

            # Idempotência: se já está igual, não precisa regravar
            if new_rating == old_rating:
                STATE.last_committed_id = song_id
                log(f"Sem mudança de rating (id={song_id}). Skip commit.")
                return

            # Grava
            params = {"songid": song_id, "userrating": new_rating}
            resp = jsonrpc("AudioLibrary.SetSongDetails", params)

            if "result" in resp:
                STATE.last_committed_id = song_id
                STATE.current_userrating = new_rating
                log(f"Rating salvo ({reason}): id={song_id} → {new_rating}")

                # Mantém compatibilidade com o comportamento atual (notificar se qualquer um estiver ativo)
                if get_bool_setting("show_notification") or get_bool_setting("real_show_notification"):
                    notify(f"{STATE.current_title} rated to {new_rating}")
                    try:
                        xbmc.executebuiltin("Container.Refresh")
                    except Exception:
                        pass
            else:
                log(f"Falha ao salvar rating ({reason}) para id={song_id}: {resp}", xbmc.LOGERROR)

        except Exception:
            log(f"_commit_current error: {traceback.format_exc()}", xbmc.LOGERROR)

class SettingsMonitor(xbmc.Monitor):
    def onSettingsChanged(self):
        log("Configurações do add-on alteradas.")

def compute_progress_rating(player: xbmc.Player) -> int:
    """
    Converte progresso em uma nota 0–10 usando 11 'partes' da duração.
    Defensivo contra durações pequenas e sem duração.
    """
    try:
        if not player.isPlayingAudio():
            return 0

        total = int(player.getTotalTime())  # segundos
        cur = int(player.getTime())

        # guarda último tempo visto (ajuda em commits e diagnóstico)
        STATE.last_player_time = max(0, cur)

        if total <= 0:
            return 0

        parts = max(1, total // 11)  # nunca 0
        calc = cur // parts          # 0..10 (clamp garante)
        return clamp_rating(int(calc))
    except Exception:
        return 0

def main_loop():
    monitor = SettingsMonitor()
    player = PlayerEvents()

    # Primeira captura (se algo já estiver tocando ao iniciar o script)
    if player.isPlayingAudio():
        player._capture_current()

    while not monitor.abortRequested():
        try:
            if player.isPlayingAudio() and STATE.current_song_id:
                # Atualiza nota a cada tick
                progress_rating = compute_progress_rating(player)

                # Mantém o comportamento atual: se usuário já tinha nota > 0, faz média com progresso
                if STATE.current_userrating > 0:
                    new_rating = (STATE.current_userrating + progress_rating) // 2
                else:
                    new_rating = progress_rating

                STATE.last_computed_rating = clamp_rating(int(new_rating))

                # Notificação “ao vivo” (opcional) – sem spam: só quando muda a nota
                if get_bool_setting("real_show_notification"):
                    if STATE.last_notified_rating != STATE.last_computed_rating:
                        STATE.last_notified_rating = STATE.last_computed_rating
                        notify(f"{STATE.current_title} rated to {STATE.last_computed_rating}", ms=1500)

            # dorme 1s (sairá cedo se o usuário encerrar o Kodi)
            if monitor.waitForAbort(1):
                break

        except Exception:
            log(f"Loop error: {traceback.format_exc()}", xbmc.LOGERROR)

    # Saída do Kodi / término do script → commitar se houver pendências
    try:
        if STATE.current_song_id and STATE.current_song_id != STATE.last_committed_id:
            PlayerEvents()._commit_current("shutdown")
    except Exception:
        pass

if __name__ == "__main__":
    main_loop()
